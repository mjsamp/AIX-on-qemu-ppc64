#!/bin/ksh
if [ -d /usr/ios ]; then  # vios
	exit
fi
time=${1:-5} # seconds to run
count=${2:-0} # num stacks to print before exiting (0 means unlimited until time expires)
stackdepth=${3:-20}
let timems=time*1000
cat<<EOF > threadwaitlock.e
@@BEGIN
{
        int thread_waitlock_(long long *addr);
        int thread_waitlock(long long *addr);
        int c;
        int count;
        count=$count;
        printf("%A: Probevue has completed instrumenting\n", timestamp());
}
@@syscallx:*:thread_waitlock_:entry
{

        printf("ENTER thread_waitlock_: %llx  by pname %s, pid %ld, tid %ld \n",__arg1, __pname, __pid,__tid);
        stktrace(PRINT_SYMBOLS | GET_USER_TRACE, $stackdepth);
        printf("=======================================");
        if ( count != 0 )
        {
                c++;
                if ( c > $count )
                        exit();
        }
}
@@syscallx:*:thread_waitlock:entry
{

        printf("ENTER thread_waitlock: %llx  by pname %s, pid %ld, tid %ld \n",__arg1, __pname, __pid,__tid);
        stktrace(PRINT_SYMBOLS | GET_USER_TRACE, $stackdepth);
        printf("=======================================");
        if ( count != 0 )
        {
                c++;
                if ( c > $count )
                        exit();
        }
}
@@interval:*:clock:$timems
{
        printf("%A: Probevue is exiting\n", timestamp());
        exit();
}
EOF
FILEOUT=probe_tw.out
echo "Starting probevue at `/bin/date`"  > $FILEOUT
nice -n -20 /usr/bin/probevue -u   threadwaitlock.e >> $FILEOUT  2> probe.err
echo "Exiting probevue script at `/bin/date`"  >> $FILEOUT
