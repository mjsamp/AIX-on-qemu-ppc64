#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: 27
#
# (C) COPYRIGHT International Business Machines Corp.  2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# 24x7count.sh
#
# invoke hpmstat before/during/after measurement period and generate reports
#
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
COUNTTOOL_P8=24x7count
COUNTTOOL_P9=24x7count
COUNTTOOL_P8_old=24x7count_P8
COUNTTOOL_P10=24x7countP10
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
setpri_val=58

OSLEVEL=`$BIN/oslevel|$BIN/awk '{print substr($1,1,3);}'`
typeset -i TL
TL=`$BIN/lslpp -qLc bos.mp64|$BIN/awk -F. '{print $5}'`
if [ "$OSLEVEL" = "6.1" ]; then
	COUNTTOOL_P8=$COUNTTOOL_P8_old
fi

if [ "$OSLEVEL" = "7.1" ]; then
	if [ "$TL" -lt 5 ]; then
		COUNTTOOL_P8=$COUNTTOOL_P8_old
	fi
fi
if [ "$OSLEVEL" = "7.2" ]; then
	if [ "$TL" -lt 2 ]; then
		COUNTTOOL_P8=$COUNTTOOL_P8_old
	fi
fi
if [ "$OSLEVEL" = "7.3" ]; then
	:
fi

TOTTIME=$1
if [ "$TOTTIME" = "" ]; then
	echo "Must specify total time in seconds to monitor"
	exit
fi

# determine INTERVAL and COUNT
if [ -n "$PERFPMR_MONITOR_INTVLTIME" ]; then
        INTERVAL=$PERFPMR_MONITOR_INTVLTIME
else
        if [ "$TOTTIME" -le 10 ]; then
		INTERVAL=1
        elif [ "$TOTTIME" -le 120 ]; then
		INTERVAL=10
        elif [ "$TOTTIME" -le 300 ]; then
		INTERVAL=25
        elif [ "$TOTTIME" -le 600 ]; then
		INTERVAL=50
        elif [ "$TOTTIME" -le 1200 ]; then
		INTERVAL=100
        elif [ "$TOTTIME" -le 3600 ]; then
		INTERVAL=300
        elif [ "$TOTTIME" -le 7200 ]; then
		INTERVAL=600
        else
                INTERVAL=900
        fi

fi
let COUNT=$1/$INTERVAL

echo "\n\nTime before run :  " `$BIN/date` > 24x7count.int

echo "    24x7count: Starting Hardware Performance Monitor Statistics Collector (24x7count -c -i $COUNT -I $INTERVAL)" >> 24x7count.int
trap 'kill -9 $!' 1 2 3 24
if [ "$OSLEVEL" = "6.1" ]; then
	HW=`$PERFPMRDIR/lsc61 -m| $BIN/awk '/^implementation/ { print $2}'`
else
	#HW=`$PERFPMRDIR/lsc -m| $BIN/awk '/^implementation/ { print $2}'`
	HW=`$PERFPMRDIR/lsc -m| $BIN/awk '/^physimplmntation/ { print $2}'`
fi
if [ "$HW" = "Power9" -o "$HW" = "P9" ]
then
	#countprogram=24x7count_P9_v31
	#countprogram=24x7count.v34
	countprogram=$COUNTTOOL_P9
elif [ "$HW" = "Power10" -o "$HW" = "P10" ]; then
	countprogram=$COUNTTOOL_P10
else
	#countprogram=24x7count_P8
	#countprogram=24x7count.v34
	countprogram=$COUNTTOOL_P8
fi
notsupported=0
case "$HW" in
	Power4) notsupported=1;;
	Power5) notsupported=1;;
	Power6) notsupported=1;;
	Power7) notsupported=1;;
esac


if [ "$notsupported" = 1 ]; then
	echo "24x7count is not supported on $HW"
	echo "24x7count is not supported on $HW" >> 24x7count.int
	exit
else
	#$PERFPMRDIR/$countprogram -c -i $COUNT -I $INTERVAL > 24x7count.csv &
	$PERFPMRDIR/setpri -p $setpri_val $$
	LDR_CNTRL=MAXDATA=0x80000000 $PERFPMRDIR/$countprogram -c -i $COUNT -I $INTERVAL > 24x7count.csv 2> 24x7count.err &
fi

# wait required interval
echo "    24x7count: Waiting for measurement period to end...."
wait

# save time after run
echo "\n\nTime after run :  " `$BIN/date` >> 24x7count.int

echo "    24x7count: Interval report is in file 24x7count.csv"
