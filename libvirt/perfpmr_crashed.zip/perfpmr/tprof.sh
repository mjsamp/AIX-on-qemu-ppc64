#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: 27
#
# (C) COPYRIGHT International Business Machines Corp.  2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# tprof.sh
#
# invoke tprof to collect data for specified interval and again to produce report
#
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
TPROF_DATADIR=tprof_data
GETEVARS_TOOL=getevars

do_timestamp()
{
        if [ "$2" = "nonewline" ]; then
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
        else
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
        fi
}

show_usage()
{
	echo "Usage: tprof.sh [-o][-u][-S path][-p program][-D][-E] [-f samp_freq] time_in_seconds"
 	echo "          time is total time to measure"
 	echo "          -p program is optional executable to be profiled,"
 	echo "          which, if specified, must reside in current directory"
	echo "          -E specifies that it uses hardware counters for sampling"
	echo "          -D specifies that the -D option is passed into tprof for detailed offset data"
	echo "          -f specifies sampling frequency for hardware counters (default 10ms)"
	echo "          -S path  specifies list of paths to search for binaries"
	echo "          -u   force -u flag to be used on tprof during postprocessing"
    echo "          -o   do postprocessing of oracle symbols by creating symlink of oracle binary"
	exit 0
}
check_for_fixes()
{
    aixv=`$BIN/uname -v`
    if [ "$aixv" = 6 ]; then
	GETEVARS_TOOL=getevars.61
        kernel_tl_level=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -1|$BIN/awk '{print $2}'|$BIN/cut -c5`
        if [ "$kernel_tl_level" = 6 ]; then
                $SBIN/instfix -ik IZ84729 >/dev/null 2>&1
                if [ $? != 0 ]; then
                        $SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                        if [ $? != 0 ]; then
                          echo "TRACE.SH:  REQUIRED APAR IZ84729 or IZ85204 is not installed"
                          if [ -z "$force_trace" ]; then
                                echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
                                exit 0
                          fi
                       fi
                fi
        fi
        if [ "$kernel_tl_level" = 7 ]; then
                $SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                if [ $? != 0 ]; then
                        echo "TRACE.SH:  REQUIRED APAR IZ85204 is not installed"
                        if [ -z "$force_trace" ]; then
                                echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
                                exit 0
                        fi
                fi
        fi
   fi  # uname
}


no_ora=0
mk_oracle_link()
{
pname=ora_dbw0
file=pstmp.out
$BIN/ps -Nef > $file
count=$($BIN/grep $pname $file| $BIN/wc -l|$BIN/sed 's/ //g')
if [ "$count" = 1 ]; then
        ora_pid=$($BIN/grep $pname $file | $BIN/awk '{print $2}')
	no_ora=0
elif [ "$count" = 0 ]; then
        no_ora=1
	ora_pid=""
else # find the one that has used the most cpu
	no_ora=0
        $BIN/grep $pname $file | $BIN/awk '{print $2,$(NF-1)}' | while read pid cputime; do
                min=$(echo $cputime|$BIN/cut -f1 -d:)
                sec=$(echo $cputime|$BIN/cut -f2 -d:)
                let totsec=min*60+sec
                echo "$pid $totsec"
        done | $BIN/sort -rn +1 | $BIN/head -1 |$BIN/awk '{print $1}' | read ora_pid
fi
if [ "$no_ora" = 0 ]; then
	if [ -x $PERFPMRDIR/$GETEVARS_TOOL ]; then
	  $PERFPMRDIR/$GETEVARS_TOOL -l $ora_pid > getevars.oracle.$pname
	  oradir=$($BIN/grep "^ORACLE_HOME" getevars.oracle.$pname|$BIN/awk -F'ORACLE_HOME=' '{print $2}')
	  if [ "$oradir" != "" ]; then
		orasid=$($BIN/grep "^ORACLE_SID" getevars.oracle.$pname|$BIN/awk -F'ORACLE_SID=' '{print $2}')
		orabin=$oradir/bin/oracle; oralinkfile=oracle$orasid
		if [ $PWD != "$oradir" ]; then
			$BIN/ln -s $orabin  $oralinkfile
			rc=$?
		fi
		return $rc
	  else
		return 1
	  fi
    else
        return 1
    fi
else
	return 1
fi
}



if [ $# -eq 0 ]; then
	show_usage
fi


# exit if tprof executable is not installed
if [ ! -x /usr/bin/tprof ]; then
  echo "     TPROF: /usr/bin/tprof command is not installed"
  echo "     TPROF:   This command is part of the optional"
  echo "                'bos.perf.tools' fileset."
  exit 1
fi

PGM=tprof
TPROFDFLAG=""
TPROFEFLAG=""
TPROFUFLAG=""	# set this to -u by default to use -u flag on tprof postprocessing (taken out due to defect 1025251)
do_ora=0
while getopts ouS:f:p:EDW flag 2>/dev/null; do
	case $flag in
	    o) do_ora=1;;
	    u) TPROFUFLAG="-u";;
		S) spath="-S $OPTARG";;
		f) samp_frequency="-f $OPTARG";;
		p) PGM=$OPTARG;;
		E) TPROFEFLAG="-E";;
		D) TPROFDFLAG="-D";;
		W) WPAR="-@ ALL";;
		\?) show_usage;;
	esac
done
shift OPTIND-1
SLEEP=$@

ulimit -d 8388608  # set to 8GB in case we need that much for gensyms
                   # but not unlimited just to be safe


# collect raw data
do_purr()
{
if  /usr/sbin/smtctl >/dev/null 2>&1; then
        KERTYPE=`$SBIN/bootinfo -K`
        if [ "$KERTYPE" = 32 ]; then
                PURR=""
        else
                PURR="-R"
        fi
else
        PURR=""
fi
}

#PURR=""   # running with PURR again
do_purr

if [  "$TPROFEFLAG" != "-E" ]; then
	samp_frequency=""
fi

check_for_fixes

echo "\n     TPROF: Starting tprof for $1 seconds...."
#file /usr/bin/tprof | $BIN/grep "64-bit" >/dev/null || export LDR_CNTRL=MAXDATA=0x80000000
#export LDR_CNTRL=MAXDATA=0x80000000   # do it anyway due to out of memory errors on symbols
if $BIN/id | $BIN/grep root >/dev/null; then
	do_timestamp "Running tprof -v $spath $TPROFDFLAG $WPAR $TPROFEFLAG $samp_frequency $PURR -T 20000000 -l -r tprof -F  -A all -x $BIN/sleep $SLEEP " nonewline; cursec=$SECONDS
	$BIN/tprof -v $spath $TPROFDFLAG $WPAR $TPROFEFLAG $samp_frequency $PURR -T 20000000 -l -r tprof -F  -A all -x $BIN/sleep $SLEEP >tprof.out 2>&1
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	echo "\n     TPROF: Starting tprof with no PURR for $1 seconds...."
	do_timestamp "Running tprof -v $spath $TPROFDFLAG $WPAR $TPROFEFLAG $samp_frequency -T 20000000 -l -r tprof_nopurr -F  -A all -x $BIN/sleep $SLEEP " nonewline; cursec=$SECONDS
	$BIN/tprof -v $spath $TPROFDFLAG $WPAR $TPROFEFLAG $samp_frequency -T 20000000 -l -r tprof_nopurr -F  -A all -x $BIN/sleep $SLEEP >tprof_nopurr.out 2>&1
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"

else
	do_timestamp "tprof $spath $PURR -l -r tprof -F  -A all -x $BIN/sleep $SLEEP" nonewline; cursec=$SECONDS
	$BIN/tprof $spath $PURR -l -r tprof -F  -A all -x $BIN/sleep $SLEEP >tprof.out 2>&1
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
fi
echo "     TPROF: Sample data collected...."


# reduce data
#echo "     TPROF: Generating reports in background (renice -n 20)"
#PID=$$
#$BIN/renice -n 10 -p $PID

if [ "$do_ora" = 1 ]; then
	oralinkfile=""	# initialize it and it gets set in mk_oracle_link
	mk_oracle_link || { no_ora=0;oralinkfile=""; }
fi

# -u flag taken out for now (defect 1025251) - fixed in 7.1.5.0, 7.2.2 and later
if [ $PGM = "tprof" ]
then
 do_timestamp "tprof $TPROFDFLAG $TPROFUFLAG $spath $PURR $WPAR -l -r tprof -skej" nonewline; cursec=$SECONDS
 $BIN/tprof $TPROFDFLAG $TPROFUFLAG $spath $PURR $WPAR -l -r tprof -skej >> tprof.out 2>&1
 let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
 do_timestamp "tprof  $TPROFUFLAG $spath $WPAR -l -r tprof_nopurr -zskej"  nonewline; cursec=$SECONDS
 $BIN/tprof  $TPROFUFLAG $spath $WPAR -l -r tprof_nopurr -zskej >> tprof_nopurr.out 2>&1
 let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
else
 do_timestamp "tprof $TPROFUFLAG $spath $PURR -l -p $PGM -r tprof -ksej"  nonewline; cursec=$SECONDS # -u removed for now
 $BIN/tprof $TPROFUFLAG $spath $PURR -l -p $PGM -r tprof -ksej >> tprof.out 2>&1
 let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
fi

if [ -f tprof.prof ]; then
    $BIN/mv tprof.prof tprof.sum
fi


if [ "$do_ora" = 1 ]; then
	if [ "$no_ora" = 0 ]; then
   		if [ "$oralinkfile" != "" ]; then
			if [ -h "$oralinkfile" ]; then
	    		echo "removing symlink file $oralinkfile"
				$BIN/rm  $oralinkfile
			fi
   		fi
	fi
fi
if [ ! -d $TPROF_DATADIR ]; then
        mkdir $TPROF_DATADIR
fi
$BIN/mv tprof.trc* $TPROF_DATADIR
$BIN/mv tprof_nopurr.trc* $TPROF_DATADIR
$BIN/mv tprof.syms $TPROF_DATADIR
$BIN/mv tprof_nopurr.syms $TPROF_DATADIR
echo "     TPROF: tprof trc and syms files are in $TPROF_DATADIR"
do_timestamp "tprof collection completed"
echo "     TPROF: Tprof report is in tprof.sum and tprof_nopurr.prof"
