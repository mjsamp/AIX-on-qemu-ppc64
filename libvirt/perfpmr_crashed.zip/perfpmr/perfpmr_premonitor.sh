#!/bin/ksh

# The reason for the long name of this script with the word perfpmr
# in it is so that monitor.sh doesn't unintentionally kill something unrelated to perfpmr

BIN=/usr/bin
SBIN=/usr/sbin
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`

cleanup()
{
	echo "In perfpmr_premonitor cleanup"
	if [ "$pflag" = 1 ]; then
		$BIN/ps -fp $perfstat_pid | $BIN/grep "perfstat_trigger" >/dev/null && kill $perfstat_pid
	fi
	if [ "$tflag" = 1 ]; then
		$BIN/ps -fp $tcpstat_pid | $BIN/grep "tcpstat" >/dev/null && kill $tcpstat_pid
	fi
	if [ "$iflag" = 1 ]; then
		$BIN/ps -fp $iostat_pid | $BIN/grep "iostat" && kill $iostat_pid
	fi
	if [ "$vflag" = 1 ]; then
		$BIN/ps -fp $vmstat_pid | $BIN/grep "vmstat" && kill $vmstat_pid
	fi
	if [ "$hflag" = 1 ]; then
		$BIN/ps -fp $lparstath_pid | $BIN/grep "lparstat" && kill $lparstath_pid
	fi
	if [ "$Hflag" = 1 ]; then
		$BIN/ps -fp $lparstatH_pid | $BIN/grep "lparstat" && kill $lparstatH_pid
	fi
}

run_programs()
{
	trap "cleanup" 2 30
	# All programs in this function should run in the background
	if [ "$pflag" = 1 ]; then
		echo "Starting perfstat_trigger at $(/bin/date)"
		$PERFPMRDIR/perfstat_trigger -M -v -t $perfstat_time 86400 > perfstat_trigger.premonitor.out &
		perfstat_pid=$!
	fi
	if [ "$tflag" = 1 ]; then
		echo "Starting tcpstat at $(/bin/date)"
		$PERFPMRDIR/tcpstat -U  $tcpstat_time 86400 > tcpstat.out &
		tcpstat_pid=$!
	fi
	if [ "$iflag" = 1 ]; then
		/usr/bin/iostat -RDTVl  $iostat_time > iostat.premonitor.out &
		iostat_pid=$!
	fi
	if [ "$vflag" = 1 ]; then
		/usr/bin/vmstat -IWwt  $vmstat_time > vmstat.premonitor.out &
		vmstat_pid=$!
	fi
	if [ "$hflag" = 1 ]; then
		/usr/bin/lparstat -t -h $lparstath_time > lparstath.premonitor.out &
		lparstath_pid=$!
	fi
	if [ "$Hflag" = 1 ]; then
		/usr/bin/lparstat -t -H $lparstatH_time > lparstatH.premonitor.out &
		lparstatH_pid=$!
	fi
	wait
}

unset pflag vflag hflag Hflag iflag
while getopts t:p:v:h:H:i: flag 2>/dev/null; do
        case $flag in
           t) tflag=1;tcpstat_time=$OPTARG;;
           p) pflag=1;perfstat_time=$OPTARG;;
           v) vflag=1;vmstat_time=$OPTARG;;
           h) hflag=1;lparstath_time=$OPTARG;;
           H) Hflag=1;lparstatH_time=$OPTARG;;
           i) iflag=1;iostat_time=$OPTARG;;
	esac
done

 
run_programs &
# now exit and let programs run in the background
exit 0
