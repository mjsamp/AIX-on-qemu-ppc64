#!/bin/ksh

show_usage()
{
	prog=$1
	echo "Usage: $prog [-A | -d dev  -d dev ...] [-E | -p -f -k -n][-S sec][-N samples]"
	echo "       -A      get stats on all fcs devices in Available state" 
	echo "       -d dev  get stats on all specified device"
	echo "       -E      get stats from all sources: procfs, fcstat, kdb, ioscli_fcstat"
	echo "       -p      get stats from procfs"
	echo "       -f      get stats from fcstat"
	echo "       -k      get stats from kdb"
	echo "       -n      get stats from ioscli_fcstat"
	echo "       -S sec  collect stats with -S seconds in between each sample"
	echo "       -N num  collect num samples if -S specified (defaults to 2 samples)"
	exit 0
}

get_procfs()
{
	dev=$1
	if [ ! -d /proc/sys/adapter/fc/$dev ];  then
		return
	fi
	/bin/cat /proc/sys/adapter/fc/$dev/stats | awk '
		BEGIN { sum_dma=0;sum_io=0;printf("%8s  %12s  %12s  %12s\n","WQ_IDX", "IO_COUNT", "NO_DMA_RSRC", "NO_ADAP_ELEM"); }
		/domain scsi/ { found_scsi=1; wqid="SCSI";}
		/wq idx/ { found_scsi=0;found=1;wqid=$3; }
		/no_dma_rsc/ {
			if ( found_scsi == 1 )
				nodma=$2;
			if ( found==1)
			{
				nodma=$2;
				sum_nodma+=nodma;
			}
		}
		/no_adap_elems/ {
			if ( found_scsi == 1 )
				noadapelm=$2;
		}
		/io_cnt/ {
			if ( found_scsi == 1 )
				iocnt=$2;
			else
				noadapelm="-"
			if ( found==1 || found_scsi == 1)
			{
				iocnt=$2;
				printf("%8s  %12d  %12d  %12s\n", wqid, iocnt, nodma, noadapelm);
				if ( found == 1 )
					sum_io+=iocnt;
				found=0;
			}
		}
		END {printf("%8s  %12d  %12d  %12s\n", "WQ_TOTAL", sum_io, sum_nodma, noadapelm);}'
}

get_procfs_stats()
{
	# get work queues from procfs
	echo "STATS FROM /proc :"
	integer i=0
	while [ $i -lt $numdevs ]
	do
		echo "Device: ${devs[$i]}"
		get_procfs ${devs[$i]}
		echo
		i=i+1
	done
	echo
}

parse_kdb_stats()
{
	/bin/cat | awk '
BEGIN { sum_inpreqs=0; sum_outreqs=0; sum_reqs=0;sum_wqreqs=0;
	printf("%18s  %12s  %12s  %12s  %12s\n","WORK_QUEUE_ADDR", "KTHREAD_ID", "INPUT_REQS", "OUTPUT_REQS", "TOTAL_REQS"); }
/emfc_wq_proto / { wq=$3; printf("%18s  ",wq);}
/long long kt_tid/ { ktid=$5; printf("%12d  ",ktid);}
/long long inp_reqs/ { 
	inpreqs=$5; sum_inpreqs+=inpreqs;sum_reqs+=inpreqs;sum_wqreqs+=inpreqs; printf("%12d  ",inpreqs); }
/long long out_reqs/ { outreqs=$5; sum_outreqs+=outreqs;sum_reqs+=outreqs;sum_wqreqs+=outreqs; 
			printf("%12d  %12d\n",outreqs, sum_wqreqs);
			sum_wqreqs=0; }
END { printf("%18s  %12s  %12d  %12d  %12d\n","TOTAL_FOR_ALL_IOQs", "----------", sum_inpreqs, sum_outreqs, sum_reqs); }'
}

get_addrs()
{
	fc=$1
	echo "emfcprtwq -s $fc" | /usr/sbin/kdb | awk '
			/ADDRESS/ { found=1;getline; }
			/^0x/ { if (found == 1) printf("emfcprtwq -d %s\n",$1); }'
}
get_kdbstats()
{
	echo "STATS FROM KDB :"
	integer i=0
	while [ $i -lt $numdevs ] 
	do
		echo "Device: ${devs[$i]}"
		if lsattr -El ${devs[$i]} -a num_io_queues >/dev/null 2>&1 ; then  # supports work queues
			get_addrs ${devs[$i]}  | /usr/sbin/kdb | parse_kdb_stats
			echo
		fi
		i=i+1
	done
	echo
}


get_fcstat()
{
	fcstat -D $1 | awk '
BEGIN {
	printf("%12s  %12s  %12s  %16s  %16s  %12s  %12s  %12s\n",
		"INPUT_REQS", "OUTPUT_REQS", "CONTROL_REQS", "INPUT_BYTES", "OUTPUT_BYTES", "NO_DMA_RSRC", "NO_ADAP_ELEM", "NO_CMD_RSRC");
}
/No DMA Resrouce Count/ { nodmarc=$5; }
/No Adapter Elements Count/ { noaec=$5; }
/No Command Resource Count/ { nocrc=$5; }
/FC SCSI Traffic Statistics/ { foundt=1; }
/Input Requests/ { if (foundt==1) inreq=$3; }
/Output Requests/ { if (foundt==1) outreq=$3; }
/Control Requests/ { if (foundt==1) ctlreq=$3; }
/Input Bytes/ { if (foundt==1) inbytes=$3; }
/Output Bytes/ { if (foundt==1) outbytes=$3; 
	printf("%12d  %12d  %12d  %16d  %16d  %12d  %12d  %12d\n",
		inreq,outreq,ctlreq,inbytes,outbytes,nodmarc,noaec,nocrc);
}'
}

get_fcstat_stats()
{
	# get stats from fcstat -D
	echo "STATS FROM fcstat -D :"
	integer i=0
	while [ $i -lt $numdevs ]
	do
		echo "Device: ${devs[$i]}"
		get_fcstat ${devs[$i]}
		echo
		i=i+1
	done
	echo
}

get_npiv()
{
	echo "STATS FROM /usr/ios/cli/ioscli fcstat -client :"
	if [ ! -d /usr/ios ]; then
		echo "This lpar is not a VIOS"
		return
	fi
	if [ "$all_devs" = 1 ]; then
		/usr/ios/cli/ioscli fcstat -client
		return
	fi
	integer i=0
	str="hostname"
	host=$(/usr/bin/hostname -s)
	while [ $i -lt $numdevs ] 
	do
		str="$str|$host  ${devs[i]}"
		i=i+1
	done
	/usr/ios/cli/ioscli fcstat -client | grep -Ep "$str"
	echo
}


integer numdevs=0 numsamp=1 sampletime=0
stime=0 samples=0;
unset all_devs devs do_kdb do_procfs do_fcstat do_npiv sampletime

while getopts N:S:npfkEAd: flag ; do
        case $flag in
		S) stime=$OPTARG;; # time in seconds
		N) samples=$OPTARG;; # number of samples
                A) all_devs=1;;
		d) devs[$numdevs]=$OPTARG;numdevs=numdevs+1;;
		p) do_procfs=1;;
		f) do_fcstat=1;;
		n) do_npiv=1;;
		k) do_kdb=1;;
		E) do_procfs=1;do_fcstat=1;do_npiv=1;do_kdb=1;;
		\?) show_usage $0;;
	esac
done
if [ "$all_devs" = 1 ]; then 
	set +A devs $(/usr/sbin/lsdev -S A -Cc adapter -F name | grep "^fcs")
	numdevs=${#devs[@]}
fi
if [ "$stime" -gt 0 ]; then
	sampletime=$stime
	if [ "$samples" -gt 1 ]; then
		numsamp=$samples
	else
		numsamp=2
	fi
fi

SECONDS=0
integer n=1
while [ "$n" -le $numsamp ]; do
	echo "FC data collection at : `/bin/date` : SAMPLE=$n  CURSECONDS=$SECONDS"
	test "$do_kdb" = 1 -a -z "$NO_KDB" && get_kdbstats
	test "$do_procfs" = 1 && get_procfs_stats
	test "$do_fcstat" = 1 && get_fcstat_stats
	test "$do_npiv" = 1 && get_npiv
	if [ -n "$sampletime" -a $n -lt $numsamp ]; then
		echo "Sleeping for $sampletime seconds"
		/bin/sleep $sampletime
	fi
	n=n+1
done
