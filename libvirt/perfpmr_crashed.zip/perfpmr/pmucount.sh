#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp.  2000,2001,2002,2003,2004,2005,2006,2007
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# pmucount.sh
#
# collect standard performance data needed for AIX performance pmr
#

export LANG=C
export PMU_NATIVE_MODE=		# set to empty to get all PMU groups instead of 18 in compat mode
BIN=/usr/bin
setpri_val=58

do_timestamp()
{
        if [ "$2" = "nonewline" ]; then
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
        else
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
        fi
}

do_priority()
{
	if [ -x $PERFPMRDIR/setpri ]; then
		#$BIN/renice -n -20 -p $$
		$PERFPMRDIR/setpri -p $setpri_val $$
	else
		$BIN/renice -n -20 -p $$
	fi
}
do_pmucount_allgroups()
{
	do_priority
	do_timestamp "pmucount.sh collecting pmucount data"

	integer i=0
	{
	echo "pmcycles nominal/odm frequency: `$BIN/pmcycles`" 
	echo "pmcycles measured frequency: `$BIN/pmcycles -M`" 
	} >  $pmoutfile
	echo "pmucount.sh: running pmucount for $pmgroups groups SECONDS=$SECONDS at `/bin/date`"  2> $pmerrfile >&2
	echo "pmucount.sh: running pmucount for $pmgroups groups: "
	while ((i < $pmgroups )) do
		echo "$i \c"
		#echo "pmucount -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile" >&2 2>> $pmerrfile
		echo "$PMUCOUNT_TOOL -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile   SECONDS=$SECONDS" 2>> $pmerrfile >&2
                if [ $IMP == "Power9" ]
                then
                    $PERFPMRDIR/$PMUCOUNT_TOOL -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile  2>> $pmerrfile
                else
                    $PERFPMRDIR/$PMUCOUNT_TOOL -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile   2>> $pmerrfile
                fi
		let i=i+1
	done
	echo "\n"
}
do_pmucount_group_range()
{
	do_priority
	echo "pmucount.sh: collecting pmucount data at time: `/bin/date`"
	do_timestamp "pmucount.sh collecting pmucount data"
	$BIN/pmcycles > $pmoutfile
	IFS=, set $pmgroup_num
	for range in $pmgroup_num ; do
		echo $range | IFS='-' read start end
		[ -z "$start" ] && continue
		[ -z "$end" ] && end=$start
		i=$start
		while [ $i -le $end ]; do
			#echo "$i"
			do_pmucount_specific_group $i
			let i=i+1
		done
	done
	echo "\n"
}
do_pmucount_specific_group()
{
	i=$1
	#echo "pmucount.sh:  running pmucount for group number: $i"  2> $pmerrfile >&2
	#echo "pmucount.sh:  running pmucount for group number: $i "
	echo "$i \c"
	#echo "$PMUCOUNT_TOOL -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile" >&2 2>> $pmerrfile
	echo "$PMUCOUNT_TOOL -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile   SECONDS=$SECONDS" 2>> $pmerrfile >&2
	if [ $IMP == "Power9" ]
	then
	    $PERFPMRDIR/$PMUCOUNT_TOOL -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile  2>> $pmerrfile
	else
	    $PERFPMRDIR/$PMUCOUNT_TOOL -kuyngG $i /usr/bin/sleep $pmsleeptime >> $pmoutfile   2>> $pmerrfile
	fi
}

do_group_chk()
{
	# group count may be as follows
	# P5: 187  P6: 202  P7: 276   P8: 295  P9: 253
	pmgroups=$($BIN/pmlist -s |$BIN/awk '/^Number of groups/ {print $NF}')
	if [ "$pmgroups" -gt 0 ]; then
		:
	else
		echo "NUMGRPS=<$pmgroups>  .. pmucount may not be supported"
		exit 1
	fi
}

do_nothing()
{
	if [ $1 == "platform" ]
	then
		echo "pmucount.sh: platform ($2) not supported by pmucount.sh"
	else
		echo "pmucount.sh: operating system version ($2) not supported by pmucount.sh"
	fi
	exit 1
}

do_aix53_chk()
{
	if [ $TL -lt 12 ]
	then
		echo "pmucount.sh: TL$TL not supported by pmucount.sh"
		exit 1
	fi
}

do_aix61_chk()
{
	if [ $TL -lt 6 ]
	then
		echo "pmucount.sh: TL$TL not supported by pmucount.sh"
		exit 1
	fi
}

do_aix71_chk()
{
	if [ $TL -lt 1 ]
	then
		echo "pmucount.sh: TL$TL not supported by pmucount.sh"
		exit 1
	fi
}

do_aix72_chk()
{
	if [ $TL -lt 0 ]
	then
		echo "pmucount.sh: TL$TL not supported by pmucount.sh"
		exit 1
	fi
}
do_aix73_chk()
{
	return
}

show_usage()
{
	echo "Usage: pmucount.sh [-L] | [-P pri] [-o outputfile] [-e errfile ] [-g group#] <collection_interval_time_per_group_in_seconds>"
	echo "-L        Just get the output of pmlist -g -1 into pmlist.allgroups.txt"
	echo "-P pri    specifies the fixed scheduling priority value for pmucount"
	echo "             default is 58"
	echo "-o file   specifies the filename for which pmucount standard output should go"
	echo "             default outputfile name is $pmoutfile"
	echo "-e file   specifies the filename for which pmucount standard error should go"
	echo "             default errfile name is $pmerrfile"
	echo "-g group  specifies the group number of range of groups to collect"
	echo "             default is to collect all groups"
	echo "             ex. -g 175    or -g 0-28    or -g 0-28,52,175"
	exit 1
}


#----------------------------------- MAIN --------------------------------
pmoutfile=pmucount_kuyng.txt
pmerrfile=pmucount.stderr
unset pmgroup_num
get_groups=0

while getopts LP:e:o:g: flag ; do
        case $flag in
		L)     get_groups=1;;
		P)     setpri_val=$OPTARG;;
                o)     pmoutfile=$OPTARG;;
                e)     pmerrfile=$OPTARG;;
                g)     pmgroup_num=$OPTARG;;
                \?)    show_usage
        esac
done
shift OPTIND-1
pmsleeptime=$@

if [  "$pmsleeptime" -gt 0 ]; then
	:
else
	#echo "Must specify a collection interval time greater than 0"
	#show_usage
	pmsleeptime=2
fi

PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
OSLEVEL=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -n 1|$BIN/awk '{print substr($2,1,3)}'`
typeset -i TL
TL=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -n 1|$BIN/awk '{print $2}'|$BIN/awk -F "." '{print $3}'`
if [ "$OSLEVEL" = "6.1" ]; then
	LSCTOOL=lsc61
	PMUCOUNT_TOOL=pmucount61
else
	LSCTOOL=lsc
	PMUCOUNT_TOOL=pmucount
fi

if [ ! -x $PERFPMRDIR/$LSCTOOL ]; then
	echo "Unable to execute $PERFPMRDIR/$LSCTOOL"
	exit 1
fi
IMP=`$PERFPMRDIR/$LSCTOOL -m|grep "^implementation"|awk '{print $2}'`
MODE=`$PERFPMRDIR/$LSCTOOL -m|grep "^version"|awk '{print $2}'`
PHYSIMP=`$PERFPMRDIR/$LSCTOOL -m|grep "^physimplmntation"|awk '{print $2}'`
VERSION=`$PERFPMRDIR/$LSCTOOL -m|grep "^version"|awk '{print $2}'`
if [ "$IMP" = "Power9" -o "$IMP" = "Power10" ]; then
	#PMUCOUNT_TOOL=pmucount_72H
	PMUCOUNT_TOOL=pmucount_72V
fi
if [ "$IMP" = "Power10" ]; then
	PMUCOUNT_TOOL=pmucount_730
fi
	


case $OSLEVEL in
	"5.3") do_aix53_chk;;
	"6.1") do_aix61_chk;;
	"7.1") do_aix71_chk;;
	"7.2") do_aix72_chk;;
	"7.3") do_aix73_chk;;
	*) do_nothing os $OSLEVEL;;
esac

case $IMP in
        "Power10")
                if [ $OSLEVEL != "7.2" -a "$OSLEVEL" != "7.3" ]
                then
                    do_nothing platform $IMP  # pmucount_72H or pmucount_72V  not tested on 7.1
                fi
		;;
        "Power9")
                if [ $OSLEVEL != "7.2" -a "$OSLEVEL" != "7.3" ]
                then
                    do_nothing platform $IMP  # pmucount_72H  or pmucount_72V not tested on 7.1
                fi
		;;
	"Power8") ;;
	"Power7") ;;
	"Power6") ;;
	"Power5") ;;
	*) do_nothing platform $IMP;;
esac

#if [ "$PHYSIMP" = "P10" -a "$OSLEVEL" = "7.2" ]; then
if [ "$PHYSIMP" = "P10" -a "$VERSION" = "Power9_Compat" ]; then
	echo "Running pmctl -N 1"
	/usr/bin/pmctl -N 1
	changed_pmctlN=1
	export PMU_NATIVE_MODE=""
fi
cursec=$SECONDS
if [ "$get_groups" = 1 ]; then
	pmlist -g -1 > pmlist.allgroups.txt
	echo "Output in pmlist.allgroups.txt"
	let elasec=$SECONDS-$cursec
	do_timestamp "pmlist completed\c"
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	if [ "$changed_pmctlN" = 1 ]; then
		/usr/bin/pmctl -N 0
	fi
	exit
fi
if [ "$pmgroup_num" = "" -o "$pmgroup_num" = "all" -o "$pmgroup_num" = "ALL" ]; then
	do_group_chk			# use pmlist to set $pmgroups
	echo "pmcount.sh: Implementation=$IMP Mode=$MODE Groups=$pmgroups"
	do_pmucount_allgroups		# run pmcucount on pm
else 
	echo "pmcount.sh: Implementation=$IMP Mode=$MODE Group=$pmgroup_num"
	do_pmucount_group_range $pmgroup_num	# run pmucount on $pmgroup_num
fi
let elasec=$SECONDS-$cursec
echo "pmucount.sh: Output is in $pmoutfile and stderr/debug output is in $pmerrfile"
do_timestamp "pmucount.sh completed\c"
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
if [ "$changed_pmctlN" = 1 ]; then
	/usr/bin/pmctl -N 0
fi
exit 0
