#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp. 2000,2001,2002,2003,2004,2005,2006,2007
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# config.sh
#
# invoke configuration commands and create report
#
#set -x
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
unset EXTSHM
ulimit -d 8388608  # set to 8GB in case we need that much for gensyms
 	           # but not unlimited just to be safe

CFGOUT=config.sum
RESTNGOUT=tunables.sum
RESTNGOUTX=tunablesx.sum
if [ "$GETGENNAMES" = 0 ]; then
        nogennames=1
fi
OSLEVEL=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -n 1|$BIN/awk '{print substr($2,1,3)}'`

show_usage()
{
	echo "Usage: config.sh [-kaglpsvmNL -u usercount]"
        echo "\t-k  do not run kdb"
	echo "\t-a  do not run lsattr on every device"
	echo "\t-g  do not run gennames command"
	echo "\t-l  do not run detailed LVM commands on each LV"
	echo "\t-p  do not run lspv on each disk"
	echo "\t-s  do not run SSA cfg commands"
	echo "\t-m  do not run detailed memory script"
	echo "\t-L  get ldatacreate callers if running detailed memory script"
	echo "\t-v  do not collect vnode data"
	echo "\t-u  usercount do not collected detailed memory stats per user if number of unique user ids is greater than usercount"
	echo "\t-N  do not collect snap data"
	echo "\toutput is generated in $CFGOUT"
	exit 1
}

do_timestamp()
{
	if [ "$2" = "nonewline" ]; then
        	echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
	else
        	echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
	fi
}

detailed_mem_flag=1
while getopts :vkgslaprQmu:NL flag ; do
        case $flag in
		L)	do_ldatacallers="-L";;
		N)	NO_SNAPDATA=1;;
		v)     no_vnode=1;;
	        k)     NO_KDB=1;;
		Q)     quicker_cfg=1;;
		r)     do_report=1;;
                p)     nolspv=1;;
                g)     nogennames=1;;
                s)     nossa=1;;
                l)     nolv=1;;
                a)     nolsattr=1;;
		m)     detailed_mem_flag=0;;
		u)     user_threshold_flag="-u $OPTARG";;
                \?)    show_usage
        esac
done


do_config_begin()
{
do_timestamp "config.sh begin"
echo "\n     CONFIG.SH: Generating SW/HW configuration"

echo "\n\n\n        C O N F I G U R A T I O N     S  U  M  M  A  R  Y     O  U  T  P  U  T\n\n\n" > $CFGOUT
echo "\n\nHostname:  "  `$BIN/hostname -s` >> $CFGOUT
echo     "Time config run:  " `$BIN/date` >> $CFGOUT
echo     "AIX VRLM (oslevel):  " `$BIN/oslevel -s` >> $CFGOUT

echo "\n\n\n        T U N A B L E S     O  U  T  P  U  T (-Fa)\n\n\n" > $RESTNGOUT
echo "\n\nHostname:  "  `$BIN/hostname -s` >> $RESTNGOUT
echo     "Time config run:  " `$BIN/date` >> $RESTNGOUT

echo "\n\n\n        T U N A B L E S     O  U  T  P  U  T (-x)\n\n\n" > $RESTNGOUTX
echo "\n\nHostname:  "  `$BIN/hostname -s` >> $RESTNGOUTX
echo     "Time config run:  \n" `$BIN/date` >> $RESTNGOUTX
configbeginsec=$SECONDS
}

do_uname()
{
echo "\n\nPROCESSOR TYPE  (uname -m)" >> $CFGOUT
echo     "--------------------------\n" >> $CFGOUT
$BIN/uname -m  >> $CFGOUT
echo     "        ## = model" >> $CFGOUT
}

do_mem()
{
echo "\n\nMEMORY  (bootinfo -r):  " `$SBIN/bootinfo -r`  >> $CFGOUT
echo     "MEMORY  (lscfg -l memN)" >> $CFGOUT
echo     "-----------------------\n"  >> $CFGOUT
$SBIN/lscfg -l mem\* >> $CFGOUT
}

do_kdb_vmm()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_kdb_vmm function will not be run since NO_KDB was set"
        return
fi
do_timestamp "do_kdb_vmm" nonewline; cursec=$SECONDS
echo "\n\nMEMORY (dd wlm_hw_pages/vmker -psize)\n----------------------" >> $CFGOUT
echo "Stats have been moved to the file kdb.stats.out" >> $CFGOUT
echo "\n\n$(/bin/date)  MEMORY (dd wlm_hw_pages/vmker -psize/etc)\n----------------------" > kdb.stats.out
echo "stat\ndd wlm_hw_pages\n\nvmstat\nvmstat -p 0\nvmstat -p 1\nfrs *\npst *\npst 0\npst 1\npfhdata\npfhdata -lrumpss\npfhdata -tune\npfhdata -lsa\npfhdata -psm\nvmker\nvmker -psize\nvmker -pvl\n\nppda *\n\ndw hcall_stats_flag\n\ndw pmap_stat 20\n\ndw hd_use_srads\ndw hd_init_srads\nsrad *\ndw fused_core_mode" | $SBIN/kdb >> kdb.stats.out
echo "$(/bin/date) SCB/VMKER -dr/nvmo" >> kdb.stats.out
echo "scb a 2\nipc 2 1\nvmker -dr\nvmo -m\ndw nx_available" | $SBIN/kdb >> kdb.stats.out
echo "\n\n$(/bin/date) VTIOL counters (vtiol) \n----------------------" >> kdb.stats.out
#echo "vtiol\nvtiol *\n\nnx -acc\n" | $SBIN/kdb >> kdb.stats.out
echo "vtiol\nvtiol *\n" | $SBIN/kdb >> kdb.stats.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_kdb_devsw()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_kdb_devsw function will not be run since NO_KDB was set"
        return
fi
do_timestamp "do_kdb_devsw" nonewline; cursec=$SECONDS
	echo "\n\nDEVSW (devsw output in devsw.out) \n----------------------" >> $CFGOUT
	echo "devsw" | $SBIN/kdb > devsw.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_kdb_vtiol()
{
	return  # done in do_kdb_vmm now
	
}

do_lsps()
{
# get current paging space info
echo "\n\nPAGING SPACES  (lsps -a)\n------------------------\n" >> $CFGOUT
$SBIN/lsps -a  >> $CFGOUT

echo "\n\nPAGING SPACES  (lsps -s)\n------------------------\n" >> $CFGOUT
$SBIN/lsps -s  >> $CFGOUT
}

do_ipcs()
{
do_timestamp "ipcs -Smqsa" nonewline; cursec=$SECONDS
echo "\n\nINTERPROCESS COMMUNICATION FACILITY STATUS (ipcs -Smqsa)\n----------------------------------------------------\n" >> $CFGOUT
#$BIN/ipcs -Smqsa  >> $CFGOUT
$BIN/ipcs -Smqsa -1 >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_lsdev()
{
# get detail device info
echo "\f\n\nPHYSICAL / LOGICAL DEVICE DETAILS  (lsdev -C | sort +2)\n-------------------------------------------------------\n" >> $CFGOUT
$SBIN/lsdev -C | $BIN/sort +2 >> $CFGOUT
}


do_lspv()  # not used any more
{
# get current physical volume names
echo "\f\n\nPHYSICAL VOLUMES  (lspv)\n------------------------\n" >> $CFGOUT
$SBIN/lspv  >> $CFGOUT
}

do_lspv_l()  # not used any more
{
# get detail physical volume info
if [ ! -n "$nolspv" ]; then
 do_timestamp "lspv -l" nonewline; cursec=$SECONDS
 for i in `$SBIN/lspv | $BIN/awk '{print $1}'`; do
    echo "\n\nPHYSICAL VOLUME DETAILS FOR $i  (/usr/sbin/lspv -l $i)\n------------------------------------------------------\n" >> $CFGOUT
    $SBIN/lspv -l $i >> $CFGOUT   2>&1
 done
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
fi
}

do_lspv_new()
{
# get current physical volume names
do_timestamp "lspv " nonewline; cursec=$SECONDS
echo "\f\n\nPHYSICAL VOLUMES  (lspv)\n------------------------\n\n" >> $CFGOUT
$SBIN/lspv  |while read line; do
    echo "$line"
    if [ ! -n "$nolspv" ]; then
	set $line
	if [ "$2" != "none" ]; then
    		echo "\n\nPHYSICAL VOLUME DETAILS FOR $i  (/usr/sbin/lspv -l $i)\n------------------------------------------------------\n"
		$SBIN/lspv -l $1
		echo "\n\n"
	fi
    fi
done >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_lspv_u()
{
	do_timestamp "lspv -u " nonewline; cursec=$SECONDS
	echo "\nUUID info for physical volumes (lspv -u > lspv.uuid.out )\n------------\n" >> $CFGOUT
	$SBIN/lspv -u > lspv.uuid.out
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_lsvg()
{
# get volume group info
do_timestamp "lsvg " nonewline; cursec=$SECONDS
echo "\n\nVOLUME GROUPS that are varied on:" >> $CFGOUT
$SBIN/lsvg -o >> $CFGOUT 2>&1
for i in `$SBIN/lsvg -o`; do
  echo "\n\nVOLUME GROUP DETAILS  (/usr/sbin/lsvg  $i)\n-------------------------------------------\n" >> $CFGOUT
  $SBIN/lsvg  $i >> $CFGOUT 2>&1
  echo  >> $CFGOUT
  $SBIN/lsvg -m $i >> $CFGOUT 2>&1
done
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_lsvg_l()
{
# get detail volume group info
do_timestamp "lsvg -l" nonewline; cursec=$SECONDS
for i in `$SBIN/lsvg -o`; do
  echo "\n\nVOLUME GROUP DETAILS  (/usr/sbin/lsvg -l $i)\n-------------------------------------------\n" >> $CFGOUT
  $SBIN/lsvg -l $i >> $CFGOUT
done
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_mount()
{

# get current mount info
echo "\f\n\nMOUNTED FILESYSTEMS  (mount)\n----------------------------\n" >> $CFGOUT
$SBIN/mount  >> $CFGOUT
}


do_lsfs()
{
echo "\n\nFILE SYSTEM INFORMATION:  (lsfs -q)\n-----------------------------------\n" >> $CFGOUT
$SBIN/lsfs -q  >>  $CFGOUT   2>&1
}

do_df()
{
echo "\n\nFILE SYSTEM SPACE:  (df)\n------------------------\n" >> $CFGOUT
do_timestamp "df" nonewline; cursec=$SECONDS
$BIN/df    >>  $CFGOUT &
dfpid=$!
dfi=0;dftimeout=30
while [ $dfi -lt $dftimeout ]; do
        $BIN/ps -p $dfpid >/dev/null
        if [ $? = 0 ]; then
                $BIN/sleep 2
        else
                break
        fi
        let dfi=dfi+1
done
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
if [ "$dfi" = $dftimeout ]; then
        echo "Killing <df> process"
        kill -9 $dfpid
fi
}


do_lslv()
{
if [ ! -n "$nolv" ]; then
do_timestamp "lslv lv" nonewline; cursec=$SECONDS
# for LV in `/usr/sbin/lsvg -o|/usr/sbin/lsvg -il|$BIN/awk '{print $1}'|$BIN/egrep -v ':|LV' `; do
 for LV in `$SBIN/lsvg -o|$SBIN/lsvg -il|$BIN/awk '{if ($2 != "NAME") print $1}' | $BIN/grep -v ':'`; do
   echo "\n\nLOGICAL VOLUME DETAILS   (/usr/sbin/lslv $LV)\n---------------------------------------\n"
   $SBIN/lslv $LV
   echo
   $SBIN/lslv -l $LV
   echo
 done >> $CFGOUT
fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_quicksnap()
{
# ======================= ESS CFG INFO =====================
#$PERFPMRDIR/quicksnap.sh > quicksnap.out
:
}

do_fastt()
{
# ============================= FASTT CFG ====================================

  /usr/bin/whereis fget_config 2>&1  > /dev/null
  if [ $? -eq 0 ]
  then
    fget_config -vA > fastt.out
  fi

}

do_ssa()
{
# ============================= SSA CFG ====================================

if [ ! -n "$nossa" ]; then
  echo "\n\nMapping of SSA hdisk to pdisk\n-----------------------------\n" >> $CFGOUT
  for i in $(/usr/sbin/lsdev -Csssar -thdisk -Fname)
  do
    echo "ssaxlate -l $i: `$SBIN/ssaxlate -l $i`"  >> $CFGOUT
  done

  echo "\n\nMapping of SSA pdisk to hdisk\n-----------------------------\n" >> $CFGOUT
  for i in $(/usr/sbin/lsdev -Csssar -cpdisk -Fname)
  do
    echo "ssaxlate -l $i: `$SBIN/ssaxlate -l $i`"   >> $CFGOUT
  done

  echo "\n\nSSA connection data (ssaconn -l pdiskN -a ssaN)\n-----------------------------------------------\n" >> $CFGOUT
  for pdisk in $(/usr/sbin/lsdev -Csssar -cpdisk -Fname)
  do
      for adap in $(/usr/sbin/ssaadap -l $pdisk 2>/dev/null)
      do
        $SBIN/ssaconn -l $pdisk -a $adap    >> $CFGOUT
      done
  done

  echo "\n\nSSA connection data sorted by link" >> $CFGOUT
  echo "(ssaconn -l all_pdisks -a all_ssa_adapters | $BIN/sort -d +4 -5 +2 -3)"   >> $CFGOUT
  echo "-----------------------------------------------------------------"  >> $CFGOUT
  unset Cssa
  for adap in $(/usr/sbin/lsdev -Ctssa -Fname) $(/usr/sbin/lsdev -Ctssa160 -Fname)
  do
    for pdisk in $(/usr/sbin/lsdev -Csssar -cpdisk -Fname)
    do
      xssa=$(/usr/sbin/ssaconn -l $pdisk -a $adap 2>/dev/null )
      if [[ -n $xssa ]]
      then
        Cssa="$Cssa\\n$xssa"
      fi
    done
    echo "$Cssa" | $BIN/sort -d +4 -5 +2 -3      >> $CFGOUT
    unset Cssa
    unset string
  done

  for adap in $(/usr/sbin/ssaraid -M 2>/dev/null)
  do
    echo "\n\nssaraid -l $adap -I\n-------------------"   >> $CFGOUT
    $SBIN/ssaraid -l $adap -I           >> $CFGOUT
  done

fi   # no ssa

# =====================   END OF SSA CFG ===================================
}

do_sissas()
{
  for adap in $(lsdev -C -Fname | grep sissas)
  do
    echo "SISSAS Adapter information for $adap" >> $CFGOUT
    lsdev -Cl $adap >> $CFGOUT 2>&1
    echo "\nlsattr -E -l $adap" >> $CFGOUT 
    lsattr -El $adap >> $CFGOUT 2>&1
    echo "********** RAID Configuration *************" >> $CFGOUT
    sissasraidmgr -L -j1 -l $adap >> $CFGOUT 2>&1
    echo "********** Multi-path Summary *************" >> $CFGOUT
    sissasraidmgr -Tl $adap -j3 >> $CFGOUT 2>&1
    echo "********** Multi-path Full Details *************" >> $CFGOUT
    sissasraidmgr -Tl $adap -j3 -o1 >> $CFGOUT 2>&1
  done
}


do_netstat()
{
# get static network configuration info
echo "\f\n\nNETWORK  CONFIGURATION  INFORMATION\n-----------------------------------\n" >> $CFGOUT
do_timestamp "$BIN/netstat -in -rn -D -an -c -Cn" nonewline; cursec=$SECONDS
for i in  in rn D an c Cn
do
  echo "$BIN/netstat -$i:\n------------\n"  >> $CFGOUT
  $BIN/netstat -$i >> $CFGOUT
  echo "\n\n" >> $CFGOUT
done
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_ifconfig()
{
echo "\n\nINTERFACE CONFIGURATION:  (ifconfig -a)\n------------------------\n"  >> $CFGOUT
$SBIN/ifconfig -a >>  $CFGOUT
echo "\n\nINTERFACE CONFIGURATION:  (ifconfig -l)" >> $CFGOUT
$SBIN/ifconfig -l >>  $CFGOUT
for en in `$SBIN/ifconfig -l`; do
	$BIN/netstat -aI $en >> $CFGOUT
	echo "\n" >> $CFGOUT
done
}

do_no()
{
echo "\n\nNETWORK OPTIONS:  (no -a)\n-------------------------\n"  >> $CFGOUT
$SBIN/no -a >>  $CFGOUT
}

do_nfso()
{
echo "\n\nNFS OPTIONS:  (nfso -a)\n-----------------------\n"  >> $CFGOUT
$SBIN/nfso -a >>  $CFGOUT
}


do_showmount()
{
echo "\n\nshowmount -e\n------------\n" >> $CFGOUT
$BIN/showmount -e      >>  $CFGOUT    2>&1 &
perfpmr_showmount_e_pid=$!
/bin/sleep 2
echo "\n\nshowmount -a\n------------\n" >> $CFGOUT
$BIN/showmount -a      >>  $CFGOUT    2>&1 &
perfpmr_showmount_a_pid=$!
/bin/sleep 2
did_showmount=1
}


do_lsattr()
{
# Capture all lsattr settings
do_timestamp "lsattr -E -l dev" nonewline; cursec=$SECONDS
if [ ! -n "$nolsattr" ]; then
  $SBIN/lsdev -C -r name | while read DEVS; do
      	echo "\n\nlsattr -E -l $DEVS"
      	echo     "--------------------"
      	$SBIN/lsattr -E -l $DEVS  2>&1
  done >> $CFGOUT
fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

# Get microcode levels
do_lsmcode()
{
	do_timestamp "lsmcode -A" nonewline; cursec=$SECONDS
	$SBIN/lsmcode -A > microcode_levels.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_cp_tunables()
{
# get tuning files
$BIN/cp /etc/tunables/nextboot tunables_nextboot
$BIN/cp /etc/tunables/lastboot tunables_lastboot
$BIN/cp /etc/tunables/lastboot.log tunables_lastboot.log
}



do_schedo()
{
# collect schedo current settings
echo "\n\nSCHEDO SETTINGS   (schedo)\n--------------------------------\n"  >> $CFGOUT
if [ -f $SBIN/schedo ]; then
     $SBIN/schedo -F -a >> $CFGOUT
	echo "\n\nASOO SETTINGS   (asoo)\n--------------------------------\n"  >> $CFGOUT
     $SBIN/asoo -F -a >> $CFGOUT
else
     echo "$SBIN/schedo not installed\n   This program is part of the bos.perf.tune fileset" >> $CFGOUT
fi
}


do_vmo_vmstat_v()
{
echo "\n\nVMO SETTINGS  (vmo)\n-------------------------\n"  >> $CFGOUT
if [ -f $SBIN/vmo ]; then
     $SBIN/vmo -F -a >> $CFGOUT
     echo "\n\nIOO SETTINGS  (ioo -a)\n----------------------------\n"  >> $CFGOUT
     $SBIN/ioo -F -a   >> $CFGOUT 2>&1
     echo "\n\nVMSTAT -v SETTINGS  (vmstat -v)\n----------------------------\n"  >> $CFGOUT
     $BIN/vmstat -v   >> $CFGOUT   2>&1
else
     echo "kernel tuning tools not installed\n    These programs are part of the bos.perf.tune fileset" >> $CFGOUT
fi
}

do_tunables_FL()
{
echo "\n\nVMO SETTINGS  (vmo -Fa)\n-------------------------\n"  >> $RESTNGOUT
if [ -f $SBIN/vmo ]; then
     $SBIN/vmo -Fa >> $RESTNGOUT
     echo "\n\nIOO SETTINGS  (ioo -Fa)\n----------------------------\n"  >> $RESTNGOUT
     $SBIN/ioo -Fa   >> $RESTNGOUT 2>&1
     echo "\n\nSCHEDO SETTINGS   (schedo -Fa)\n--------------------------------\n"  >> $RESTNGOUT
     $SBIN/schedo -Fa >> $RESTNGOUT 2>&1
     echo "\n\nNETWORK OPTIONS:  (no -Fa)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/no -Fa >>  $RESTNGOUT
     echo "\n\nNFSO OPTIONS:  (nfso -Fa)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/nfso -Fa >>  $RESTNGOUT
     echo "\n\nASOO OPTIONS:  (asoo -Fa)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/asoo -Fa >>  $RESTNGOUT
     echo "\n\nRASO OPTIONS:  (raso -Fa)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/raso -Fa >>  $RESTNGOUT

     echo "\n\nVMO SETTINGS  (vmo -FL)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/vmo -FL >> $RESTNGOUT
     echo "\n\nIOO SETTINGS  (ioo -FL)\n----------------------------\n"  >> $RESTNGOUT
     $SBIN/ioo -FL   >> $RESTNGOUT 2>&1
     echo "\n\nSCHEDO SETTINGS   (schedo)\n--------------------------------\n"  >> $RESTNGOUT
     $SBIN/schedo -FL >> $RESTNGOUT 2>&1
     echo "\n\nNETWORK OPTIONS:  (no -FL)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/no -FL >>  $RESTNGOUT
     echo "\n\nNFSO OPTIONS:  (nfso -FL)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/nfso -FL >>  $RESTNGOUT
     echo "\n\nASOO OPTIONS:  (asoo -FL)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/asoo -FL >>  $RESTNGOUT
     echo "\n\nRASO OPTIONS:  (raso -FL)\n-------------------------\n"  >> $RESTNGOUT
     $SBIN/raso -FL >>  $RESTNGOUT
else
     echo "kernel tuning tools not installed\n   These programs are part of the bos.perf.tune fileset" >> $RESTNGOUT
fi
}

do_tunables_x()
{
echo "schedo -F -x" >> $RESTNGOUTX
$SBIN/schedo -F -x >> $RESTNGOUTX
echo "vmo -F -x" >> $RESTNGOUTX
$SBIN/vmo -F -x >> $RESTNGOUTX
echo "ioo -F -x" >> $RESTNGOUTX
$SBIN/ioo -F -x >> $RESTNGOUTX
echo "no -F -x" >> $RESTNGOUTX
$SBIN/no -F -x >> $RESTNGOUTX
echo "nfso -F -x" >> $RESTNGOUTX
$SBIN/nfso -F -x >> $RESTNGOUTX
echo "asoo -F -x" >> $RESTNGOUTX
$SBIN/asoo -F -x >> $RESTNGOUTX
echo "raso -F -x" >> $RESTNGOUTX
$SBIN/raso -F -x >> $RESTNGOUTX
}

do_lvmo()
{
echo "\n\nLVMO SETTINGS  (lvmo)\n-------------------------\n"  >> $CFGOUT
for l in `$SBIN/lsvg -o`; do
$SBIN/lvmo -v $l -a 
echo 
done >> $CFGOUT
echo     "----------------------------\n"  >> $CFGOUT
}

do_mempool()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_mempool function will not be run since NO_KDB was set"
        return
fi

# =====================  MEMPOOL STATISTICS ===============================
echo "\n\nMEMPOOL STATS (getmempool.sh  )\n--------------------------------------------\n"  >> $CFGOUT
do_timestamp "getmempool.sh" nonewline; cursec=$SECONDS
$PERFPMRDIR/getmempool.sh  >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_vmpool()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_vmpool function will not be run since NO_KDB was set"
        return
fi
# =====================  VMPOOL STATISTICS ===============================
echo "\n\nMEMPOOL STATS (getvmpool.sh  )\n--------------------------------------------\n"  >> $CFGOUT
do_timestamp "getvmpool.sh" nonewline; cursec=$SECONDS
$PERFPMRDIR/getvmpool.sh >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_jfs2mem()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_jfs2mem function will not be run since NO_KDB was set"
        return
fi

# =====================  JFS2 MEMORY STATISTICS ===============================
echo "\n\nJFS2 MEMORY STATS (getj2mem.sh  )\n--------------------------------------------\n"  >> $CFGOUT
do_timestamp "getj2mem.sh" nonewline; cursec=$SECONDS
$PERFPMRDIR/getj2mem.sh >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_jfs2stats()
{
# =====================  JFS2 STATISTICS ===============================
echo "\n\nJFS2 STATS \n--------------------------------------------\n"  >> $CFGOUT
$BIN/cat /proc/sys/fs/jfs2/statistics >> $CFGOUT
}

do_lbp()
{
# =====================  LBP STATISTICS ===============================
echo "\n\nDISK LBP STATS - cat /proc/sys/disk/lbp/statistics \n--------------------------------------------"  >> $CFGOUT
if [ -f /proc/sys/disk/lbp/statistics ]; then
	$BIN/cat /proc/sys/disk/lbp/statistics >> $CFGOUT
else
	echo "/proc/sys/disk/lbp/statistics does not exit" >> $CFGOUT
fi
}



do_wlm()
{
# =====================  WORKLOAD MANAGER ===============================
echo "\n\nworkload manager status  (wlmcntrl -q ; echo \$?)\n-------------------------------------------------" >> $CFGOUT
$SBIN/wlmcntrl -q  2>&1 >> $CFGOUT
echo $?      >> $CFGOUT

echo "\n\nworkload manager classes (lsclass -C/lsclass -f)\n-------------------------------------" >> $CFGOUT
 $SBIN/lsclass -C   >> $CFGOUT
 $SBIN/lsclass -f   >> $CFGOUT
# =====================  END OF WORKLOAD MANAGER ===========================
}

do_wpar()
{
# =====================  WPAR ===============================
echo "\n\nWPAR status (lspwar)\n--------------------" >> $CFGOUT
$SBIN/lswpar >> $CFGOUT
$SBIN/lswpar -L > lswpar.out
}

do_genkld()
{
# =====================  GEN* COMMANDS ===============================
# get genkld and genkex output
do_timestamp "genkld" nonewline; cursec=$SECONDS
echo "\n\nGENKLD OUTPUT  (genkld)\n-----------------------\n"  >> $CFGOUT
whence genkld > /dev/null  2>&1
if [ $? = 0 ]; then
     #$BIN/genkld |$BIN/sort > genkld.out
     $BIN/genkld  > genkld.out
else
     echo "genkld not installed or not in current PATH"  >> $CFGOUT
     echo "   This program is part of the bos.perf.tools fileset" >> $CFGOUT
fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_genkex()
{
echo "\n\nGENKEX OUTPUT  (genkex)\n-----------------------\n"  >> $CFGOUT
do_timestamp "genkex" nonewline; cursec=$SECONDS
whence genkex > /dev/null  2>&1
if [ $? = 0 ]; then
     #$BIN/genkex | $BIN/sort >  genkex.out
     $BIN/genkex  >  genkex.out
else
     echo "genkex not installed or not in current PATH\n   This program is part of the bos.perf.tools fileset" >> $CFGOUT
fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"

# ==================  END OF GEN* COMMANDS ===============================
}


do_audit()
{
echo "\n\nSYSTEM AUDITING STATUS  (audit query)\n-------------------------------------\n"  >> $CFGOUT
/usr/sbin/audit query  >>  $CFGOUT
}


do_env()
{
echo "\n\nSHELL ENVIRONMENT  (env)\n------------------------\n"  >> $CFGOUT
$BIN/env   >>  $CFGOUT
}

do_getevars()
{
echo "\n\nSHELL ENVIRONMENTS (getevars -l > getevars.out)\n--------------------------------------------\n"  >> $CFGOUT
do_timestamp "getevars" nonewline; cursec=$SECONDS
if [ "$OSLEVEL" = "6.1" ]; then
	$PERFPMRDIR/getevars.61 -p -u -l -e > getevars.out
else
	$PERFPMRDIR/getevars -p -u -l -e > getevars.out
fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_slashproc()
{
	do_timestamp "ls /proc/pid/cwd" nonewline; cursec=$SECONDS
	$BIN/ls -l /proc/*/cwd > proc.cwd.out
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_errpt()
{
# get 2000 lines of verbose error report output
do_timestamp "errpt" nonewline; cursec=$SECONDS
echo "\n\nVERBOSE ERROR REPORT   (errpt -a | head -2000 > errpt_a)\n--------------------------------------------------------\n" >> $CFGOUT
echo "ERRPT of first 2000 lines. Run errpt on the errlog file to get full output" > errpt_a
$BIN/errpt -a | $BIN/head -2000 >> errpt_a
# get 100 most recent entries in errpt
echo "ERROR REPORT   (errpt | head -100)\n----------------------------------\n" >> $CFGOUT
$BIN/errpt | $BIN/head -100  >> $CFGOUT
$BIN/cp /var/adm/ras/errlog  errlog
$BIN/cp /var/adm/ras/errtmplt  errtmplt
echo "\nERRDEMON SETTINGS:  errdemon -l" >> $CFGOUT
/usr/lib/errdemon -l >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_ifix_list()
{
do_timestamp "emgr -lv3 > emgr.out " nonewline; cursec=$SECONDS
echo "\n\nIFIXES INSTALLED (emgr -lv3)" > emgr.out
$SBIN/emgr -lv3 >> emgr.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_lslpp()
{
# get lpp history info
do_timestamp "lslpp -ch" nonewline; cursec=$SECONDS
echo "\f\n\nLICENSED  PROGRAM  PRODUCT  HISTORY  (lslpp -ch)\n------------------------------------------------\n" >> $CFGOUT
$BIN/lslpp -ach >> $CFGOUT
$BIN/lslpp -Lc >> lslpp.Lc
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_instfix()
{
# get apar info
do_timestamp "instfix -ic" nonewline; cursec=$SECONDS
$SBIN/instfix -ic > instfix.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}



do_java()
{
# get java lpp info
echo "\n\njava -fullversion\n-----------------\n" >> $CFGOUT
whence java >> $CFGOUT  2>&1
if [ $? = 0 ]; then
    java -fullversion >> $CFGOUT    2>&1
fi
}


do_lsslot()
{
# get slot information
echo "\f\n\nPCI SLOT CONFIGURATION  (lsslot -c pci)\n-----------------------------------------\n" >> $CFGOUT 
$SBIN/lsslot -c pci >> $CFGOUT 2>/dev/null
}


do_lscfg_vp()
{
# get verbose machine configuration
#  added because it is useful to tell between 601 and 604 upgrades
echo "\f\n\nVERBOSE MACHINE CONFIGURATION  (lscfg -vp)\n-----------------------------------------\n" >> $CFGOUT
do_timestamp "lscfg -vp" nonewline; cursec=$SECONDS
$SBIN/lscfg -vp  >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_lsc()
{
# get cache info via Matt's program
echo "\f\n\nPROCESSOR DETAIL  (lsc -m)\n--------------------------\n" >> $CFGOUT
if [ "$OSLEVEL" = "6.1" ]; then
	$PERFPMRDIR/lsc61 -m >> $CFGOUT
else
	$PERFPMRDIR/lsc -m >> $CFGOUT
fi
}

do_lparstatsum()
{
echo "\f\n\nLPARSTAT -i (lparstat -i)\n--------------------------\n" >> $CFGOUT
$BIN/lparstat -i >> $CFGOUT
echo "\n\nLPARSTAT -x (lparstat -x)\n--------------------------\n" >> $CFGOUT
$BIN/lparstat -x >> $CFGOUT 2>&1
$BIN/cat<<EOF >> $CFGOUT
0 - speculative execution fully enabled
3 - speculative execution controls to mitigate user to kernel side channel attacks
2 - speculative execution controls to mitigate user to kernel & user to user  side channel attacks
EOF
}


#do_kdb_th()
#{
#if [ -n "$NO_KDB"  ]; then
#        echo "$0: do_kdb_pth function will not be run since NO_KDB was set"
#        return
#fi
#
## get kproc and thread info AND kernel heap stats
#echo "\n\nKERNEL THREAD TABLE  " >> $CFGOUT
#echo     "-------------------------------\n" >> $CFGOUT
#do_timestamp "th *|kdb" nonewline; cursec=$SECONDS
#echo "th *" | $SBIN/kdb >> $CFGOUT
#let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
#}

do_kdb_xm() # moved to memdetails.sh
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_kdb_xm function will not be run since NO_KDB was set"
        return
fi

echo "\n\nKERNEL HEAP USAGE  (xm -u)\n-------------------------------\n" >> $CFGOUT
do_timestamp "xm -u |kdb" nonewline; cursec=$SECONDS
echo "xm -u" | $SBIN/kdb >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_kdb_th()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_kdb_th function will not be run since NO_KDB was set"
        return
fi

echo "\n\KDB thread ouput  (th *)\n-------------------------------\n" >> th.kdb.out
do_timestamp "th  |kdb" nonewline; cursec=$SECONDS
echo "th *" | $SBIN/kdb >> th.kdb.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_kdb_vnode_vfs()
{
	# get vnode and vfs info
	if [ -n "$NO_KDB"  ]; then
		echo "$0: do_kdb_vnode_vfs function will not be run since NO_KDB was set"
		return
	fi

	if [ "$no_vnode" != 1 ]; then
		do_timestamp "echo vnode|kdb" nonewline; cursec=$SECONDS
		echo "vnode"|$SBIN/kdb > vnode.kdb
		let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	fi
	do_timestamp "echo vfs|kdb" nonewline; cursec=$SECONDS
	echo "vfs"|$SBIN/kdb > vfs.kdb
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_kdb_kmbucket()
{
# get mbuf stats
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_kdb_kmbucket function will not be run since NO_KDB was set"
        return
fi

echo "\n\nMBUF STATS: kmbucket -s" >> $CFGOUT
echo "kmbucket -s" | $SBIN/kdb  | $BIN/egrep 'alloc|wall|kmemin' >> $CFGOUT
echo "dw wildcard_in_table" | $SBIN/kdb  >> $CFGOUT
}


do_kdb_vpm()
{
# get vpm stats
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_kdb_vpm function will not be run since NO_KDB was set"
        return
fi
echo "\n\nDRVARS: drvars" >> $CFGOUT
echo "drvars" | $SBIN/kdb >> $CFGOUT
echo "\n\nVPM STATS: vpm" >> $CFGOUT
echo "vpm" | $SBIN/kdb   >> $CFGOUT
}

do_kdb_scb()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_kdb_scb function will not be run since NO_KDB was set"
        return
fi
do_timestamp "do_kdb_scb" nonewline; cursec=$SECONDS
echo "scb 6 0" | $SBIN/kdb > scb.6.0
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_devtree()
{
# get devtree information
do_timestamp "echo dmpdt_chrp -i" nonewline; cursec=$SECONDS
/usr/lib/boot/bin/dmpdt_chrp -i > devtree.out 2>&1
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_sysdumpdev()
{
# get system dump config info
echo "\n\nSYSTEM DUMP INFO (sysdumpdev -l;sysdumpdev -e)\n----------------------------------------------\n" >> $CFGOUT
do_timestamp "sysdumpdev -l, -e" nonewline; cursec=$SECONDS
$BIN/sysdumpdev -l >> $CFGOUT
$BIN/sysdumpdev -e >> $CFGOUT
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_bosdebug()
{
# get bosdebug settings
echo "\n\nbosdebug -L\n-----------\n" >> $CFGOUT
$SBIN/bosdebug -L  >> $CFGOUT
}

do_locktrace()
{
# get locktrace settings
echo "\n\nlocktrace -l\n-----------\n" >> $CFGOUT
$BIN/locktrace -l  >> $CFGOUT 2>&1
}


do_unix()
{
# get ls of kernel in use
echo "\n\nls -al /unix INFO\n-----------------" >> $CFGOUT
$BIN/ls -al /unix  >> $CFGOUT
echo "\nls -al /usr/lib/boot/uni* INFO\n------------------------------" >> $CFGOUT
$BIN/ls -al /usr/lib/boot/uni*  >> $CFGOUT
}


do_pmctrl()
{
# get power management settings
echo "\n\npower management (pmctrl -v)\n----------------------------\n" >> $CFGOUT

pmctrl -v  >> $CFGOUT  2>&1
}

do_rset()
{
# get rset information
echo "\n\nRSET (resource set) configuration in lsrset.out\n----------------------------\n" >> $CFGOUT
$SBIN/lsrset -a -v > lsrset.out
echo "\n\nRSET attachments for each pid" >> lsrset.out
if [ "$OSLEVEL" = "6.1" ]; then
	$PERFPMRDIR/getevars.61 -R >> lsrset.out
else
	$PERFPMRDIR/getevars -R >> lsrset.out
fi
}

do_lssrad()
{
# get srad information
echo "\n\nSRAD (system resource affinity domain ) configuration in lssrad.out\n----------------------------\n" >> $CFGOUT
$SBIN/lssrad -a -v > lssrad.out
}


do_gennames()
{
# get gennames output if needed (not present or older than .init.state)
# the reason gennames is important is that it also collects the equivalent
# of genld -l which is useful to show if shlibs were copied into a 
# private segment
if [ ! -n "$nogennames" ]; then
	echo "\n\ngennames > gennames.out\n-----------------------\n" >> $CFGOUT
	if [ ! -f gennames.out -o gennames.out -ot /etc/.init.state ]; then
		do_timestamp "gennames" nonewline; cursec=$SECONDS
     		LDR_CNTRL=MAXDATA=0x80000000 $BIN/gennames > gennames.out  2>&1
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	fi
fi
}


do_crontab()
{
# get crontab -l info
echo "\n\ncrontab -l > crontab_l\n----------------------\n" >> $CFGOUT
$BIN/crontab -l > crontab_l
$BIN/mkdir crontabs
$BIN/cp /var/spool/cron/crontabs/*  crontabs
}


do_limits()
{
# get /etc/security/limits
echo "\n\ncp /etc/security/limits etc_security_limits\n-------------------------------------------\n" >> $CFGOUT
$BIN/cp /etc/security/limits etc_security_limits
}


do_initt_fs_rc()
{
# get misc files
$BIN/cp /etc/inittab  etc_inittab
$BIN/cp /etc/filesystems  etc_filesystems
$BIN/cp /etc/rc  etc_rc
$BIN/cp /etc/profile  etc_profile
$BIN/cp /etc/environment  etc_environment
$BIN/cp /etc/services  etc_services
$BIN/cp /etc/resolv.conf  etc_resolvconf
$BIN/cp /etc/security/ldap/ldap.cfg  etc_sec_ldapcfg
}

do_streams()
{
$BIN/cp /etc/dlpi.conf dlpi.conf
strtune -Q > strtune.out
}


do_what()
{
# get what output of /unix
$BIN/what /unix > unix.what
}


do_cfg_end()
{
echo "\nTIMESTAMP of /etc/.init.state" >> $CFGOUT
$BIN/ls -l /etc/.init.state >> $CFGOUT

echo "config.sh data collection completed." >> $CFGOUT
echo "     CONFIG.SH: Report is in file $CFGOUT"

###end of shell
do_timestamp "config.sh completed\c"
let configendsec=$SECONDS-$configbeginsec; echo "  :  execution_time: $configendsec seconds"
}

get_vfc()
{
mkdir svfc
cd svfc
/etc/lsdev -C|/usr/bin/grep vfchost|/usr/bin/grep Available | /usr/bin/awk '{print $1}'|while read host; do
        fcsdev=`/etc/lsattr -E -l $host -a map_port -F value`
        if [ "$fcsdev" = "" ]; then
                continue
        fi
        echo "svfcCI; svfcPrQs; svfcva $host; svfcdds $host; svfccq $host;" | kdb > $host.state
        /usr/ios/cli/ioscli lsmap  -npiv -vadapter $host > $host.map
done
cd -
}

do_vio()
{
if [ -d /usr/ios ]; then
	do_timestamp "VIO cfg data" nonewline; cursec=$SECONDS
	echo "------------ ioslevel  ----------" > vio.cfg
	/usr/ios/cli/ioscli ioslevel  >> vio.cfg
	echo "\n\n------------ lsdev -virtual ----------" >> vio.cfg
	/usr/ios/cli/ioscli lsdev -virtual >> vio.cfg
	echo "\n\n------------ lspath ----------" >> vio.cfg
	/usr/ios/cli/ioscli lspath  >> vio.cfg
	echo "\n\n------------ lsmap -all -npiv ----------" >> vio.cfg
	/usr/ios/cli/ioscli lsmap -all -npiv >> vio.cfg
	echo "\n\n------------ lsmap net ----------" >> vio.cfg
	/usr/ios/cli/ioscli lsmap -all -net >> vio.cfg
	echo "\n\n------------ lsmap -all ----------" >> vio.cfg
	/usr/ios/cli/ioscli lsmap -all  >> vio.cfg
	echo "\n\n------------ lsmap -all -ams ----------" >> vio.cfg
	/usr/ios/cli/ioscli lsmap -all -ams >> vio.cfg
	echo "\n\n------------ cluster -list ----------" >> vio.cfg
	/usr/ios/cli/ioscli cluster -list >> vio.cfg
	echo "\n\n------------ cluster -status -verbose ----------" >> vio.cfg
	/usr/ios/cli/ioscli cluster -status -verbose >> vio.cfg
	echo "\n\n------------ pv -list -verbose ----------" >> vio.cfg
	/usr/ios/cli/ioscli pv -list -verbose >> vio.cfg

	if [ -z "$NO_KDB"  ]; then
		echo "sea" | $SBIN/kdb > vio_sea.out
		get_vfc
	fi


let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
else
	# vio client
	do_timestamp "VIO client cfg data" nonewline; cursec=$SECONDS
	string=
	if [ -z "$NO_KDB"  ]; then
	   /usr/sbin/lsdev -Ccadapter|$BIN/grep "^fcs"|$BIN/awk '{print $1}'| while read fc
	   do
        	string="$string vfcs $fc\n"
	   done

           string="$string\ncvai\n\n"
           echo "cvai" | $SBIN/kdb | $BIN/grep ^vscsi | $BIN/awk '{ print $1 }' | while read vs
           do
                string="$string\ncvai $vs"
           done
	   echo "$string" | $SBIN/kdb  > vfc_client.kdb.out
	else
	   echo "No stats generated due to NO_KDB specified" > vfc_client.kdb.out
	fi
	unset string
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
fi
}

do_ras()
{
if [ -f /usr/sbin/raso ]; then
	echo "\n\n------------ RAS   ----------\nraso -a" >> $CFGOUT
	$SBIN/raso -F -a >> $CFGOUT
fi
if [ -f /usr/sbin/errctrl ]; then
	echo "\nerrctrl -q" >> $CFGOUT
	$SBIN/errctrl -q >> $CFGOUT
fi
if [ -f /usr/sbin/ctctrl ]; then
	echo "\nctctrl -q" >> $CFGOUT
	$SBIN/ctctrl -q >> $CFGOUT
fi

if [ -f /usr/sbin/skeyctl ]; then
	echo "\nskeyctl" >> $CFGOUT
	$SBIN/skeyctl >> $CFGOUT
fi
}

do_fc()
{
FCSTATOUT=fcstat.out
if [ -f /usr/sbin/fcstat ]; then
	echo "\n\n------------ FCSTAT   > fcstat.out ----------\n" >> $CFGOUT
	echo "\n\n------------ FCSTAT    ----------\n" > $FCSTATOUT
	$SBIN/instfix -ik IZ15616 >/dev/null 2>&1
	if [ $? -eq 0 ]; then
        	fcstat_nflag="-n"
	else
        	fcstat_nflag=""
	fi
	for f in `/usr/sbin/lsdev -Ccadapter|$BIN/grep "^fcs"|$BIN/awk '{print $1}'`; do
	echo "\n------------------------------------------------" >> $FCSTATOUT
		$SBIN/fcstat  $f >> $FCSTATOUT 
		if [  "$fcstat_nflag" = "-n" ]; then
			echo "Running fcstat with -n" >> $FCSTATOUT
			$SBIN/fcstat $fcstat_nflag $f >> $FCSTATOUT 
		fi
	done
fi
}
	

cp_odm()
{
        $BIN/mkdir objrepos
	do_timestamp "copying ODM files" nonewline; cursec=$SECONDS
        $BIN/cp /etc/objrepos/* objrepos
        #do_odm $PWD/objrepos
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_xmwlm()
{
	#$BIN/cp /etc/perf/daily/* .
  	TOPASDIR_TMP=`grep topasrec /etc/inittab | grep -v "^:" `
  	if [ "$TOPASDIR_TMP" != "" ]; then
    		TOPASDIR=`echo $TOPASDIR_TMP | awk '{
			for (i=0; i<NF; i++)
			{
				if ($i == "-o" ) {
				print $(i+1);
				break;
				}
			}
    		}'  `
    		$BIN/cp ${TOPASDIR}/* .
  	else  # Probably worthless - or would get old data since topasrec not found in /etc/inittab
    		$BIN/cp /etc/perf/daily/* .
	fi
}

do_topasnmon()
{
topasrecdir=`$BIN/ps -Nef | $BIN/grep /usr/bin/topasrec | $BIN/awk -F' -o ' '{print $2}'|$BIN/awk '{print $1}'`
topasnmonfile=`$BIN/ps -Nef | $BIN/grep /usr/bin/topas_nmon | $BIN/awk -F' -F ' '{print $2}'|$BIN/awk '{print $1}'`
topasnmondir=`$BIN/dirname $topasnmonfile`
numtopasfiles=7; numnmonfiles=7
if [ -d "$topasrecdir" ]; then
  filelist=`$BIN/ls -t $topasrecdir/*.nmon $topasrecdir/*.topas | $BIN/head -$numtopasfiles`
  for file in $filelist; do
        fname=${file##*/}
        if [ ! -f $PWD/$fname ]; then
                #echo "cp $file ."
                $BIN/cp $file .
        fi
  done
fi
if [ -d "$topasnmondir" ]; then
  filelist=`$BIN/ls -t $topasnmondir/*.nmon | $BIN/head -$numnmonfiles`
  for file in $filelist; do
        fname=${file##*/}
        if [ ! -f $PWD/$fname ]; then
                #echo "cp $file ."
                $BIN/cp $file .
        fi
  done
fi
}

do_detailed_mem()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_detailed_mem function will not be run since NO_KDB was set"
        return
fi

if [ "$detailed_mem_flag" = 1 ]; then
	if [ "$PERFPMR_SEGMENT_COUNT" -gt "$PERFPMR_SEGMENT_LIMIT" ]; then
		echo "$0: do_detailed_mem function will not be run because cur_seg_count=$PERFPMR_SEGMENT_COUNT is greater than perfpmr_segment_limit=$PERFPMR_SEGMENT_LIMIT"
		return
	fi
	$BIN/mkdir mem_details_dir ;  cd mem_details_dir
	do_timestamp "memdetails.sh  $user_threshold_flag $do_ldatacallers" nonewline; cursec=$SECONDS
	$PERFPMRDIR/memdetails.sh $user_threshold_flag $do_ldatacallers > memdetails.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	do_timestamp "memdetails.sh  completed"
	cd ..
fi
}

do_disk_qd()
{
if [ -n "$NO_KDB"  ]; then
        echo "$0: do_disk_qd function will not be run since NO_KDB was set"
        return
fi

DISKCOUNT=${1:-0}
DISK_QD_LOG=disk_qdepth.out
DISKLIST=disk_qd_list
do_timestamp "getting disk queue_depth info" nonewline; cursec=$SECONDS
$BIN/rm -fr $DISK_QD_LOG $DISKLIST $DISKLIST.tmp
for i in `echo scsidisk | $SBIN/kdb | $BIN/grep 0xF | $BIN/cut -c15- | $BIN/awk '{ print $1 }'`
do
    echo "scsidisk $i"
done > $DISKLIST.tmp
if [ $DISKCOUNT = 0 ]; then
        $BIN/mv $DISKLIST.tmp $DISKLIST
else
	count=`$BIN/wc -l $DISKLIST.tmp`
        $BIN/head -$DISKCOUNT $DISKLIST.tmp > $DISKLIST
fi
$SBIN/kdb < $DISKLIST  > disk_kdb.out
#$SBIN/kdb < $DISKLIST | $BIN/egrep "devno|queue_depth" |$BIN/sed 's/;//'| $BIN/awk '{
#        if ($2 == "devno")
#                printf("devno  %s  ",$4);
#        else if ($2 == "queue_depth")
#                printf("queue_depth  %d\n",$4);
#        }' >> $DISK_QD_LOG
awk 'BEGIN {
printf("%10s %6s %10s %12s %12s %8s %8s %8s %8s %8s %8s %8s %9s\n", "hdiskname","qdepth", "mxtransfer", "xfers", "rxfers","q_depth","q_full","rtimeout","rfailed","wtimeout","wfailed","wqdepth","pathcount");
}
/^hdisk/ { printf("%10s",$1); }
/queue_depth/ { printf(" %6d", $4); }
/max_request/ {printf(" %10d", $4); }
/struct dkstat/ { getline; getline; }
/dk_xfers/ { printf(" %12s", $3); }
/__dk_rxfers/ { printf(" %12s", $3); }
/dk_q_depth/ { printf(" %8s", $3); }
/dk_q_full/ { printf(" %8s", $3); }
/dk_rtimeout/ { printf(" %8s", $3); }
/dk_rfailed/ { printf(" %8s", $3); }
/dk_wtimeout/ { printf(" %8s", $3); }
/dk_wfailed/ { printf(" %8s", $3); }
/dk_wq_depth/ {printf(" %8s", $3); }
/path_count/ {printf(" %8s\n", $4); }
' disk_kdb.out > $DISK_QD_LOG

let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
do_timestamp "disk queue_depth info completed"
}

do_alog()
{
	do_timestamp "getting alog information"
	$BIN/alog -ot console > alog.console
	$BIN/alog -ot boot > alog.boot
}
do_emc()
{
do_timestamp "powermt data being collected"
$SBIN/powermt display dev=all   > emc_powermt.txt 2>&1
}


do_db2()
{
#userid=db2inst1
do_timestamp "db2 tids being collected" nonewline; cursec=$SECONDS
$BIN/ps -Nelf|$BIN/grep db2sysc|$BIN/grep -v grep|$BIN/awk '{ print $3 }'|$BIN/sort -u|while read userid; do
        userhome=~${userid}
        eval userhome=$userhome
        if [ "$userid" != "" ]; then
                $BIN/su  $userid -c ". $userhome/sqllib/db2profile; $userhome/sqllib/adm/db2pd -alldbp -edus"  > db2_tids.$userid.out 2>&1
                $BIN/su  $userid -c ". $userhome/sqllib/db2profile; $userhome/sqllib/adm/db2set -all"  > db2set.$userid.out 2>&1
		#do_timestamp "db2 support data being collected"
		#$BIN/su  $userid -c ". $userhome/sqllib/db2profile; $userhome/sqllib/bin/db2support  .  > db2log.${userid} 2>&1"
        fi
  done
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_get_app_gensyms()
{
do_timestamp "application symbol tables being generated" nonewline; cursec=$SECONDS
# get Sybase gensyms
dataserverbin=`$BIN/grep "_=" getevars.out|$BIN/grep dataserver|$BIN/head -1|$BIN/sed 's/_=//'`
if [ "$dataserverbin" != "" ]; then
        LDR_CNTRL=MAXDATA=0x80000000 $BIN/gensyms -s -b  $dataserverbin > dataserver.syms
fi

# get Informix gensyms
oninitbin=`$BIN/grep "_=" getevars.out|$BIN/grep oninit|$BIN/head -1|$BIN/sed 's/_=//'`
if [ "$oninitbin" != "" ]; then
        LDR_CNTRL=MAXDATA=0x80000000 $BIN/gensyms -s -b  $oninitbin > oninit.syms
fi

# get Oracle syms
i=0
> oraclesyms.readme
> oracle_dumpH.out
$BIN/grep "^ORACLE_HOME" getevars.out | $BIN/sort -u | awk -F'ORACLE_HOME=' '{print $2}'|while read oradir; do
        oraclebin=$oradir/bin/oracle
        LDR_CNTRL=MAXDATA=0x80000000 $BIN/gensyms -s -b $oraclebin > oracle.syms.$i
        echo "$i\t$oraclebin" >> oraclesyms.readme
	echo "$i\t$oraclebin" >> oracle_dumpH.out
	/usr/bin/dump -X64 -H $oraclebin >> oracle_dumpH.out	# to see if oracle was linked statically or not
	/usr/bin/dump -X64 -H $oradir/bin/tnslsnr >> oracle_dumpH.out	
	echo "--------------------------" >> oracle_dumpH.out
        let i=i+1
done

# get Epic syms
#epicexe=/epic/prd/cachesys/bin/irisdb
#if [ -f $epicexe ]; then
#	if [ ! -p $epicexe ]; then
#		gensyms -s -b $epicexe > irisdb.syms
#	fi
#fi
if  /bin/ps -Nef | grep irisdb >/dev/null; then
  iris list | grep "directory:" | while read dir path; do
        instance=$(basename $path)
        gensyms -s -b $path/bin/irisdb > irisdb.$instance.syms
  done
fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

# get proctree info
do_proctree()
{
	do_timestamp "proctree -Tt" nonewline; cursec=$SECONDS
	$BIN/proctree -Tt > proctree.out
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_dscrctl_nx()
{
	do_timestamp "collect dscrctl and NX settings" nonewline; cursec=$SECONDS
echo "\ndscrctl prefetch output: " >> $CFGOUT
/usr/sbin/dscrctl -q >> $CFGOUT
echo "\nhardware crypto acceleration: acfo" >> $CFGOUT
if [ -x /usr/sbin/acfo ]; then
	/usr/sbin/acfo -d >> $CFGOUT
else
	echo "acfo command does not exist on this AIX level"
fi
if [ -x /usr/sbin/nxstat ]; then
	echo "\nNX accelerator stat (/usr/bsbin/nxstat -S)" >> $CFGOUT
	/usr/sbin/nxstat -S >> $CFGOUT
fi
if [ -n "$NO_KDB"  ]; then
        echo "$0: nx -acc kdb function will not be run since NO_KDB was set"
else
	echo "nx -acc\n" | $SBIN/kdb >> $CFGOUT
fi
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}


do_collect_logfiles()
{
	do_timestamp "collect logfiles" nonewline; cursec=$SECONDS
	$BIN/cp /smit.log .
	# collect aso logs later?
	mkdir aso_logs
	for file in /var/log/aso/*; do
		if [ ! -p $file ]; then
			$BIN/cp $file aso_logs
		fi
	done
	$BIN/cp /var/adm/ras/conslog conslog.alog
	mkdir syslogs
	$BIN/cp /etc/syslog.conf syslogs
	$BIN/grep -v "^#" /etc/syslog.conf|$BIN/grep "/" |$BIN/awk '{print $2}'|while read file; do
		if [ ! -p $file ]; then
			case "$file" in
				/dev/* ) ;;  # do nothing if file has /dev in it
				*) $BIN/cp $file syslogs ;;
			esac
		fi
	done
	$BIN/cp /tmp/lvmt.log .
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_collect_ipsec()
{
	do_timestamp "ipsec" nonewline; cursec=$SECONDS
echo "IPSECSTAT (/usr/sbin/ipsecstat)\n-----------------" > ipsec.out
$SBIN/ipsecstat >> ipsec.out 2>&1
echo "\n\nACTIVE FILTERS (/usr/sbin/lsfilt -a)\n-------------------" >> ipsec.out
$SBIN/lsfilt -a >> ipsec.out 2>&1
echo "\n\nALL FILTERS (/usr/sbin/lsfilt)\n--------------------" >> ipsec.out
$SBIN/lsfilt  >> ipsec.out 2>&1
echo "\n\nACTIVE TUNNELS (/usr/sbin/lstun -a)\n-------------------" >> ipsec.out
$SBIN/lstun -a >> ipsec.out 2>&1
echo "\n\nALL TUNNELS (/usr/sbin/lstun)\n--------------------" >> ipsec.out
$SBIN/lstun  >> ipsec.out 2>&1
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_nis()
{
	echo "\n\n\tNIS config information" >> $CFGOUT
	echo "domainname: `domainname`" >> $CFGOUT
}

do_aixpert()
{
	{
	echo "\n\naixpert -t"
	aixpert -t
	if [ -d /usr/ios ]; then
		echo "\n\nPSCXPERT (pscxpert -t)" 
		pscxpert -t
	fi
	} >> $CFGOUT 2>&1
	aixpertlog=/etc/security/aixpert/log/aixpert.log
	if [ -f "$aixpertlog" ]; then
		cp $aixpertlog .
	fi
}
do_smtctl()
{
	
	do_timestamp "smtctl" nonewline; cursec=$SECONDS
	echo "smtctl" > smtctl.out
	smtctl >> smtctl.out 
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_lruobj()
{
	if [ -n "$NO_KDB"  ]; then
        	echo "$0: do_lruobj function will not be run since NO_KDB was set"
        	return
	fi
	mkdir lrulist_dir
	if [ -d lrulist_dir ]; then
	  cd lrulist_dir
	do_timestamp "lruobj" nonewline; cursec=$SECONDS
	  listobj=$(echo "cla" | $SBIN/kdb|$BIN/grep "LRU List"|$BIN/head -1|$BIN/awk '{print $NF}')
	  pools=$($BIN/vmstat -v|$BIN/grep "pool"|$BIN/awk '{print $1}')
	  echo "memp *" | $SBIN/kdb > mempools_all.out
	  i=0
	  while [ $i -lt $pools ]; do
		echo "lrulo $listobj"|$SBIN/kdb > ${listobj}.out
		mp=$($BIN/grep "llo_mp" ${listobj}.out | $BIN/awk '{print $NF}')
		echo "$listobj\t$(grep $mp mempools_all.out)"
		listobj=$($BIN/grep llo_next ${listobj}.out | $BIN/grep llo_next | $BIN/awk '{print $NF}')
		let i=i+1
	  done > lrulist.out
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	  cd -
	fi
}
do_aha()
{
	do_timestamp "AHAFS:  " nonewline; cursec=$SECONDS
	/usr/sbin/mount | grep "/aha.*ahafs" >/dev/null
	if [ $? = 0 ]; then
		echo "AHAFS is being used .. collecting ahafs config"
		find /aha -xdev > ahafs.conf
	fi
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_mmfs()
{
	do_timestamp "MMFS" nonewline; cursec=$SECONDS
	/usr/sbin/lsfs -v mmfs 
	if [ $? != 0 ]; then
		let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
		return
	fi
	echo "\n****************************************************"
	/usr/sbin/lsfs -v mmfs  | grep "^/dev"|awk '{print $1,$2,$3}' | while read dev node fs; do 
		echo "FILESYSTEM: $fs"
		echo "mmlsfs $dev"
		/usr/lpp/mmfs/bin/mmlsfs $dev
		echo "======================================="
	done
	echo "\n****************************************************"
	echo "MMLSCONFIG"
	/usr/lpp/mmfs/bin/mmlsconfig
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_netbackup()
{
	do_timestamp "netbackup" nonewline; cursec=$SECONDS
	echo "Content of directory /usr/openv/netbackup/db/config" 
	/usr/bin/ls -l /usr/openv/netbackup/db/config 
	echo "NOSHM file:"
	/usr/bin/ls -l /usr/openv/netbackup/NOSHM
	echo "/usr/openv/netbackup/NET_BUFFER_SZ:"
	/usr/bin/cat /usr/openv/netbackup/NET_BUFFER_SZ
	echo "/usr/openv/netbackup/db/config/SIZE_DATA_BUFFERS:"
	/usr/bin/cat /usr/openv/netbackup/db/config/SIZE_DATA_BUFFERS
	echo "/usr/openv/netbackup/db/config/NUMBER_DATA_BUFFERS:"
	/usr/bin/cat /usr/openv/netbackup/db/config/NUMBER_DATA_BUFFERS
	echo "/usr/openv/netbackup/db/config/NUMBER_DATA_BUFFERS_DISK:"
	/usr/bin/cat /usr/openv/netbackup/db/config/NUMBER_DATA_BUFFERS_DISK
	echo "/usr/openv/netbackup/db/config/CHILD_DELAY:"
	/usr/bin/cat /usr/openv/netbackup/db/config/CHILD_DELAY
	echo "/usr/openv/netbackup/db/config/PARENT_DELAY:"
	/usr/bin/cat /usr/openv/netbackup/db/config/PARENT_DELAY
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

gen_otherfiles()
{
    ulimit -d 8388608  # set to 8GB in case we need that much for gensyms
                       # but not unlimited just to be safe

    # get inode output if needed (not present or older than .init.state)
    if [ ! -n "$noinodetbl" ]; then
      if [ ! -f trace.crash.inode -o trace.crash.inode -ot /etc/.init.state ]; then
#         if [ -f /usr/sbin/pstat ]; then
#               do_timestamp "collecting pstat -i data"
#               $SBIN/pstat -i > trace.inode 2>/dev/null
#               if [ $? != 0 ]; then
#                       echo "pstat failed"
#               fi
#         fi
        if [ -z "$NO_KDB"  ]; then
	 if [ "$PERFPMR_SEGMENT_COUNT" -gt "$PERFPMR_SEGMENT_LIMIT" ]; then
	  echo "inode table will not be generated due to segment count of $PERFPMR_SEGMENT_COUNT being higher than the perfpmr limit of $PERFPMR_SEGMENT_LIMIT"
	 else
	  do_timestamp "collecting inode data from kdb"  nonewline; cursec=$SECONDS
          echo "inode" | $SBIN/kdb  >trace.crash.inode  2>&1  # in case pstat doesn't work
          echo "i2" | $SBIN/kdb > trace.j2.inode 2>&1  # get JFS2 inode table
	  let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	 fi
        fi
      fi
    fi

    # in case tprof is used to post process the trace files, get gensyms data
    do_timestamp "running gensyms"  nonewline; cursec=$SECONDS
     $BIN/gensyms > trace.syms
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
    do_timestamp "gensyms completed"

    # get gennames output if needed (not present or older than .init.state)
# the reason gennames is important is that it also collects the equivalent
# of genld -l which is useful to show if shlibs were copied into a
# private segment

    if [ -z "$nogennames" ]; then
      if [ ! -f gennames.out -o gennames.out -ot /etc/.init.state ]; then
        if [ "$GETGENNAMESF" = 1 ]; then
          do_timestamp "running gennames"  nonewline; cursec=$SECONDS
          $BIN/gennames -f >gennames.out  2>&1
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
          do_timestamp "gennames completed"
        else
          do_timestamp "running gennames"  nonewline; cursec=$SECONDS
          $BIN/gennames >gennames.out  2>&1
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
          do_timestamp "gennames completed"
        fi
      fi
    fi
}

do_lsconf()
{
    	do_timestamp "running lsconf"  nonewline; cursec=$SECONDS
	/usr/sbin/lsconf > lsconf.out
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}

do_cpuextintr()
{
	echo "\n------------------\n/usr/sbin/cpuextintr_ctl -Q" >> $CFGOUT
	/usr/sbin/cpuextintr_ctl -Q >> $CFGOUT
	echo "------------------" >> $CFGOUT
}
do_vnic()
{
	do_timestamp "vnicstat.sh" nonewline; cursec=$SECONDS
	$PERFPMRDIR/vnicstat.sh  >> vnic.out
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_radinfo()
{
	do_timestamp "radinfo" nonewline; cursec=$SECONDS
	$PERFPMRDIR/radinfo > radinfo.out
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_nvme()
{
	do_timestamp "nvme_collect" nonewline; cursec=$SECONDS
	PASSNO=2 SCRIPTLOG=./nvme.log SNAPDIR=$PWD /usr/lib/scripts/snap/nvme_collect
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_pmctl()
{
	do_timestamp "pmctl/pmcycles" nonewline; cursec=$SECONDS
	echo "\n------------------\n/usr/bin/pmctl -s" >> $CFGOUT
	/usr/bin/pmctl -s >> $CFGOUT
	echo "\n------------------\n/usr/bin/pmcycles -d" >> $CFGOUT
	/usr/bin/pmcycles -d >> $CFGOUT
	echo "------------------" >> $CFGOUT
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_vxfs()
{
	do_timestamp "vxfs" nonewline; cursec=$SECONDS
	CHECKED_VXFS_PATH=0;VXTUNEFS_NOTFOUND=0
	$SBIN/mount | $BIN/grep vxfs | $BIN/awk '{print $2}' | while read fs; do 
		if [ "$CHECKED_VXFS_PATH" = 0 ]; then
			vxtunefsexe=`$BIN/which vxtunefs`
			if [ $? != 0 ]; then
				if [ -x /opt/VRTSvxfs/sbin/vxtunefs ]; then
					vxtunefsexe=/opt/VRTSvxfs/sbin/vxtunefs
				else
					VXTUNEFS_NOTFOUND=1
				fi
			fi
			CHECKED_VXFS_PATH=1
			
		fi
		if [ -f /etc/vx/tunefstab ]; then
			$BIN/cp /etc/vx/tunefstab vxfs_tunefstab
		fi
		if [ "$VXTUNEFS_NOTFOUND" = 1 ]; then
			return
		fi
		echo "FILESYSTEM: $fs\n" 
		$vxtunefsexe $fs 
		echo "\n\n" 
	done   > vxfs_tunables.out
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_ipf()
{
	do_timestamp "ipf" nonewline; cursec=$SECONDS
	if [ -x /usr/sbin/ipfstat ]; then
		/usr/sbin/ipfstat -i > ipfstat.out
	fi
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_efsenable()
{
	do_timestamp "efsenable" nonewline; cursec=$SECONDS
	if [ -x /usr/sbin/efsenable ]; then
		/usr/sbin//efsenable -p -v > efs.out
		/usr/sbin//efsenable -q  >> efs.out
	fi
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
}
do_snap()
{
	if [ -n "$NO_SNAPDATA" ]; then
        	echo "$0: do_snap function will not be run since NO_SNAPDATA was set"
		return
	fi
        do_timestamp "snap -gGfFLktRSn -d $PWD/snap_data" ; cursec=$SECONDS
        mkdir snap_data
	if [ -d /usr/ios ]; then
		# make up for not using -a option on snap
		mkdir snap_data/lsvirt
		PASSNO=1 SNAPDIR=$PWD/snap_data/lsvirt /usr/lib/ras/snapscripts/lsvirt > snap_data/lsvirt/lsvirt.log
		PASSNO=2 SNAPDIR=$PWD/snap_data/lsvirt /usr/lib/ras/snapscripts/lsvirt > snap_data/lsvirt/lsvirt.out 2> snap_data/lsvirt/lsvirt.err
		mkdir snap_data/poolfs
		cd snap_data/poolfs
		/usr/sbin/pooladm dump support -dest $PWD
		cd -
	fi
	$SBIN/snap -gGfFLktRSn -d $PWD/snap_data
	$BIN/mv script.log $PWD/snap_data 2>/dev/null
        let elasec=$SECONDS-$cursec; echo "  :  snap execution_time: $elasec seconds"
}
do_lcpu2bid()
{
	do_timestamp "lcpu2bid" nonewline; cursec=$SECONDS
	$PERFPMRDIR/lcpu2bid > lcpu2bid.out
        let elasec=$SECONDS-$cursec; echo "  :  snap execution_time: $elasec seconds"
}
do_tsm()
{
	do_timestamp "dsmc"
	if [ -f /usr/bin/dsmc ]; then
        	do_timestamp "dsmc q options"
		/usr/bin/dsmc q option > dsmc.options
	fi
}
do_locale()
{
	do_timestamp "locale"
        echo "\n------------------\n/usr/bin/locale" >> $CFGOUT
	/usr/bin/locale  >> $CFGOUT
        echo "------------------" >> $CFGOUT
}
do_ipclimits()
{
	do_timestamp "ipclimits"
        echo "\n------------------\n./ipclimits" >> $CFGOUT
	$PERFPMRDIR/ipclimits  >> $CFGOUT
        echo "------------------" >> $CFGOUT
}
do_osversion()
{
	do_timestamp "proc/version"
	echo "\n----------- AIX version - cat /proc/version ----" >> $CFGOUT
	/usr/bin/cat /proc/version >> $CFGOUT
}
do_pmlist()
{
	do_timestamp "pmlist"
	$PERFPMRDIR/pmucount.sh -L
}
do_config_begin
cp_odm
do_uname
do_mem
do_kdb_vmm
do_kdb_vtiol
do_lsps
do_ipcs
do_lsdev
if [ "$quicker_cfg" != 1 ]; then
	do_lsmcode
	#do_lspv
	#do_lspv_l
	do_lspv_u
	do_lspv_new
	do_lsvg
	do_lsvg_l
	do_lslv
	do_ssa
	do_sissas
	do_lsattr
	do_disk_qd
else
	$SBIN/lsattr -E -l sys0 >> $CFGOUT
fi
do_fastt
do_mount
do_lsfs
do_df
#do_quicksnap
do_kdb_kmbucket
do_netstat
do_ifconfig
do_no
do_nfso
do_showmount
do_cp_tunables
do_tunables_FL
do_tunables_x
do_schedo
do_vmo_vmstat_v
do_lvmo
do_ras
do_mempool
do_vmpool
do_jfs2mem
do_jfs2stats
do_wlm
do_genkld
do_genkex
do_audit
do_env
do_getevars
do_slashproc
do_errpt
do_ifix_list
do_lslpp
do_instfix
do_java
do_lsslot
do_lscfg_vp
do_lsc
do_lparstatsum
#do_kdb_xm   # moved to memdetails.sh
do_kdb_devsw
if [ "$quicker_cfg" != 1 ]; then
	#do_kdb_th
	do_kdb_vnode_vfs
fi
do_dscrctl_nx
do_devtree
do_sysdumpdev
do_bosdebug
do_locktrace
do_unix
#do_pmctrl
do_rset
do_lssrad
do_gennames
do_crontab
do_limits
do_initt_fs_rc
do_streams
do_what
do_vio
do_wpar
#do_fc    # moved to monitor.sh
do_xmwlm  # for topas/nmon files
do_topasnmon  # also for topas/nmon in case default directory is changed
do_alog
do_emc
do_db2
do_proctree
do_detailed_mem
do_get_app_gensyms
do_collect_logfiles
do_collect_ipsec
do_nis
do_aixpert
do_smtctl
do_lruobj
do_aha
do_netbackup > netbackup.cfg 2>&1
do_mmfs > mmfs.cfg 2>&1
do_kdb_vpm
do_kdb_th
do_lsconf
do_kdb_scb
do_cpuextintr
do_vnic
do_radinfo
do_nvme
do_pmctl
do_vxfs
do_lbp
do_lcpu2bid
do_ipf
do_efsenable
do_snap
do_locale
do_ipclimits
do_pmlist
if [ "$DO_TRACE_MISCFILES_INCONFIG" = 1 ]; then
	gen_otherfiles
fi
if [ "$did_showmount" = 1 ]; then  # in case showmount hangs
	$BIN/ps -fp "$perfpmr_showmount_a_pid" | $BIN/grep showmount|$BIN/grep -v grep >/dev/null && $BIN/kill -9 $perfpmr_showmount_a_pid
	$BIN/ps -fp "$perfpmr_showmount_e_pid" | $BIN/grep showmount|$BIN/grep -v grep >/dev/null && $BIN/kill -9 $perfpmr_showmount_e_pid
fi
#do_tsm
do_osversion
do_cfg_end
