#!/bin/ksh
BIN=/usr/bin
IO_DATADIR=io_data
MEM_DATADIR=mem_data
CPU_DATADIR=cpu_data
CFG_DATADIR=cfg_data
NETWORK_DATADIR=network_data
TPROF_DATADIR=tprof_data
PPROF_DATADIR=pprof_data
PMC_DATADIR=pmc_data
TRACE_DATADIR=trace_data
TOPAS_DATADIR=topasnmon_data
DB2_DATADIR=db2_data
SNAP_DATADIR=snap_data

for dir in $IO_DATADIR $MEM_DATADIR $CPU_DATADIR $CFG_DATADIR $NETWORK_DATADIR $TPROF_DATADIR $PPROF_DATADIR $PMC_DATADIR $TRACE_DATADIR $TOPAS_DATADIR $DB2_DATADIR; do
	if [ ! -d $dir ]; then
		mkdir $dir 2>/dev/null
	fi
done

$BIN/mv  aiostat.int $IO_DATADIR
$BIN/mv  alog* $CFG_DATADIR
$BIN/mv  config.sum $CFG_DATADIR      ################
$BIN/mv  crontab_l $CFG_DATADIR
$BIN/mv  db2_tids* $CFG_DATADIR
$BIN/mv  oracle* $CFG_DATADIR
$BIN/mv  dataserver*.sym* $CFG_DATADIR
$BIN/mv  devsw.out $CFG_DATADIR
$BIN/mv  devtree.out $CFG_DATADIR
$BIN/mv  disk_qd_list $IO_DATADIR
$BIN/mv  disk_qdepth.out $IO_DATADIR
$BIN/mv  dlpi.conf $CFG_DATADIR
$BIN/mv  emc_powermt.txt $IO_DATADIR
$BIN/mv  errlog $CFG_DATADIR
$BIN/mv  errpt_a $CFG_DATADIR
$BIN/mv  errtmplt $CFG_DATADIR
$BIN/mv  etc_filesystems $CFG_DATADIR
$BIN/mv  etc_inittab $CFG_DATADIR
$BIN/mv  etc_rc $CFG_DATADIR
$BIN/mv  etc_security_limits $CFG_DATADIR
$BIN/mv  etc_environment $CFG_DATADIR
$BIN/mv  etc_profile $CFG_DATADIR
$BIN/mv  fastt.out $IO_DATADIR
$BIN/mv  fcstat.* $IO_DATADIR
$BIN/mv  fcstat2.* $IO_DATADIR
$BIN/mv `$BIN/ls filemon*|$BIN/grep -Ev "filemon.sh"`  $IO_DATADIR
$BIN/mv  genkex.out $CFG_DATADIR
$BIN/mv  genkld.out $CFG_DATADIR
$BIN/mv  gennames.out $CFG_DATADIR
$BIN/mv  getevars.out $CFG_DATADIR
$BIN/mv  hpm*.out  $PMC_DATADIR
$BIN/mv  instfix.out $CFG_DATADIR
$BIN/mv  iomon.out $IO_DATADIR
$BIN/mv `$BIN/ls iostat*|grep -Ev "iostat.sh"`  $IO_DATADIR
$BIN/mv `$BIN/ls iptrace*|grep -Ev "iptrace.sh"`  $NETWORK_DATADIR
$BIN/mv  lparstat.d lparstat.int lparstat.l  $CPU_DATADIR
$BIN/mv  lparstat.nsp   $TRACE_DATADIR
$BIN/mv  lparstat.sum   $CFG_DATADIR
$BIN/mv  lslpp.Lc   $CFG_DATADIR
$BIN/mv  lsps.*   $MEM_DATADIR
$BIN/mv  lsrset.out   $CFG_DATADIR
$BIN/mv  lssrad.out   $CFG_DATADIR
$BIN/mv  lswpar.out   $CFG_DATADIR
$BIN/mv  mem_details_dir   $MEM_DATADIR
$BIN/mv  mempools.*   $MEM_DATADIR
$BIN/mv  microcode*   $CFG_DATADIR
$BIN/mv  monitor.int   $CPU_DATADIR     ##########
$BIN/mv  monitor.sum   $CPU_DATADIR     ##########
$BIN/mv  mpstat*.int   $CPU_DATADIR     
$BIN/mv  mrq.out   $CPU_DATADIR     
$BIN/mv  netstat.int   $NETWORK_DATADIR      #####
$BIN/mv  nfsstat.int   $NETWORK_DATADIR      #####
$BIN/mv  objrepos   $CFG_DATADIR      
#$BIN/mv  perfpmr.cfg   $CFG_DATADIR      
#$BIN/mv  perfpmr.int   $CFG_DATADIR      
$BIN/mv  pile.*   $IO_DATADIR      
$BIN/mv  ppda.out   $CPU_DATADIR      
$BIN/mv  pvpa*   $TRACE_DATADIR      
$BIN/mv `$BIN/ls pprof*|$BIN/grep -Ev "$PPROF_DATADIR|pprof.sh"`  $PPROF_DATADIR
$BIN/mv  rqi.out   $CPU_DATADIR      
$BIN/mv  sar.*   $CPU_DATADIR      
$BIN/mv `$BIN/ls sar.*|$BIN/grep -v "sar.sh"`  $CPU_DATADIR
$BIN/mv  seastat*  $NETWORK_DATADIR
$BIN/mv  smit.log*   $CFG_DATADIR
$BIN/mv  strtune.out   $CFG_DATADIR      
$BIN/mv `$BIN/ls svmon*|$BIN/grep -Ev "svmon.sh"`  $MEM_DATADIR
$BIN/mv `$BIN/ls tcpdump*|$BIN/grep -Ev "tcpdump.sh"`  $NETWORK_DATADIR
$BIN/mv `$BIN/ls tprof*|$BIN/grep -Ev "$TPROF_DATADIR|tprof.sh"`  $TPROF_DATADIR
$BIN/mv `$BIN/ls trace*|grep -Ev "$TRACE_DATADIR|trace.sh"`  $TRACE_DATADIR
$BIN/mv trc_419* $TRACE_DATADIR
$BIN/mv  tstat.out $CPU_DATADIR
$BIN/mv  tunables* $CFG_DATADIR
$BIN/mv  unix.what $CFG_DATADIR
$BIN/mv  vfs.kdb  $CFG_DATADIR
$BIN/mv  *.topas*  *.nmon $TOPAS_DATADIR
$BIN/mv persistent_local $TOPAS_DATADIR
$BIN/mv  vio.cfg $CFG_DATADIR
$BIN/mv  vio_sea.out $CFG_DATADIR
$BIN/mv  vfc_client.kdb* $CFG_DATADIR
#$BIN/mv  vmker*  $MEM_DATADIR
$BIN/mv  vmmstats*  $MEM_DATADIR
$BIN/mv  vmpools*  $MEM_DATADIR
$BIN/mv  vmstat.psize*  $MEM_DATADIR
$BIN/mv  vmstati*  $IO_DATADIR
$BIN/mv  vmstat_s*  $MEM_DATADIR
$BIN/cp  vmstat_v*  $IO_DATADIR
$BIN/mv  vmstat_v*  $MEM_DATADIR
$BIN/mv  vmstat.int  $MEM_DATADIR
$BIN/mv  vmstat.sum  $MEM_DATADIR
$BIN/mv  vnode.kdb  $CFG_DATADIR
$BIN/mv  w.int  $CFG_DATADIR
$BIN/mv  db2support* $DB2_DATADIR
$BIN/mv  db2_tids* $DB2_DATADIR
$BIN/mv  db2log* $DB2_DATADIR
$BIN/mv  proctree.out $CPU_DATADIR
$BIN/mv  24x7count.csv 24x7count.int 24x7count.err $CPU_DATADIR
$BIN/mv  ipsec.* $CFG_DATADIR
$BIN/mv  tcpstat.out $NETWORK_DATADIR
$BIN/mv lsconf.out $CFG_DATADIR
$BIN/mv etc_services $CFG_DATADIR
$BIN/mv mmfs.cfg $CFG_DATADIR
$BIN/mv lsmpio.out  $IO_DATADIR
$BIN/mv lparstat.E  $CPU_DATADIR
$BIN/mv netbackup.cfg  $CFG_DATADIR
$BIN/mv powerstat.out $CPU_DATADIR
$BIN/mv smtctl.out $CFG_DATADIR
$BIN/mv ventstat.out $NETWORK_DATADIR
$BIN/mv tbdiff.out $TRACE_DATADIR
$BIN/mv perfstat_trigger.premonitor.out $CPU_DATADIR
$BIN/mv proc_sys_adapter.int* $CFG_DATADIR
$BIN/mv persistent.db $TOPAS_DATADIR
$BIN/mv eidmon.* $CPU_DATADIR
$BIN/mv disk_kdb.out $IO_DATADIR
$BIN/mv ctctrl.err $CFG_DATADIR
$BIN/mv foldstat.out $CPU_DATADIR
$BIN/mv th.kdb.out  $CFG_DATADIR
$BIN/mv pmapstat.out $MEM_DATADIR
$BIN/mv fc.before $IO_DATADIR
$BIN/mv fc.after $IO_DATADIR
$BIN/mv etc_* $CFG_DATADIR
$BIN/mv scb.6.0 $MEM_DATADIR
$BIN/mv syslogs $CFG_DATADIR
$BIN/mv pmucount.stderr pmucount_k* $PMC_DATADIR
$BIN/mv crontabs $CFG_DATADIR
$BIN/mv conslog.alog $CFG_DATADIR
$BIN/mv aso_logs $CFG_DATADIR
$BIN/mv comptrace_dir $TRACE_DATADIR
$BIN/mv lrulist_dir $MEM_DATADIR
$BIN/mv ps_output $CPU_DATADIR
$BIN/mv `$BIN/ls ps*|$BIN/grep -Ev "ps.sh"`  $CPU_DATADIR
$BIN/mv amecmem* $MEM_DATADIR
$BIN/mv amevms* $MEM_DATADIR
$BIN/mv vmstat.wpar.int $MEM_DATADIR
$BIN/mv radinfo.out $CFG_DATADIR
$BIN/mv nvme* $IO_DATADIR
$BIN/mv vxfs_tun* $CFG_DATADIR
$BIN/mv vnic.out $NETWORK_DATADIR
$BIN/mv vnicserver_stats* $NETWORK_DATADIR
$BIN/mv vnicserver.namelist $NETWORK_DATADIR
$BIN/mv probe_tw.out probe.err threadwaitlock.e  $CPU_DATADIR
$BIN/mv emgr.out $CFG_DATADIR
$BIN/mv script.log $SNAP_DATADIR
$BIN/mv kdb.stats.out $MEM_DATADIR
$BIN/mv lvmt.log $CFG_DATADIR
$BIN/mv ahafs.conf $CFG_DATADIR
$BIN/mv memtrace.err $TRACE_DATADIR
$BIN/mv kdb.err $CFG_DATADIR
$BIN/mv lcpu2bid.out $CFG_DATADIR
$BIN/mv proc_sys_adapter.err $CFG_DATADIR
$BIN/mv proc.cwd.out $CFG_DATADIR
$BIN/mv glvm.stdout_stderr  glvm_rpvstat.out rpvstat.*.out $IO_DATADIR 
$BIN/mv efs.out acfstat.out $CFG_DATADIR
$BIN/mv lvmpbufstat.out  $IO_DATADIR
$BIN/mv pmlist.allgroups.txt  $PMC_DATADIR
$BIN/mv lspv.uuid.out  $CFG_DATADIR
$BIN/mv fcstat*.before $IO_DATADIR
$BIN/mv fcstat*.after $IO_DATADIR
$BIN/mv acf.out  $CFG_DATADIR
$BIN/mv ioscli.log  $CFG_DATADIR
