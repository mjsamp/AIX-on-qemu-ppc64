#!/bin/ksh

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

do_summary()
{
TMPDIR=.
MEMFILE=$TMPDIR/jfs2mem.kdb
NAMFILE=$TMPDIR/jfs2mem.name
echo pile | $SBIN/kdb  > pile.out
$BIN/grep -v "(0)" pile.out | $BIN/awk '{
a=1
while (status=getline >0)
{
        if ( a == 1 )
        {
                if   (substr($0,0,7) != "ADDRESS" )
                        continue;
                else
                {
                        a = 0;
                        continue;
                }
        }


        split ($0,temp)
        printf("%16s  %16d\n",temp[2],temp[3]);

}
}' > $MEMFILE
$BIN/awk '{print $1}' $MEMFILE|$BIN/sort -u > $NAMFILE

sumkbytes=0
while read name; do
        sumpages=0
        $BIN/grep -w $name $MEMFILE | $BIN/awk '{print $2}'| while read pages; do
                let sumpages=sumpages+pages
        done
        let kbytes=sumpages*4
        printf "%16s  %16d kbytes\n" $name $kbytes
        let sumkbytes=sumkbytes+kbytes
done < $NAMFILE
echo "========================================"
echo "TOTAL JFS2 kernel heap usage: $sumkbytes kbytes"
$BIN/rm $MEMFILE
$BIN/rm $NAMFILE

}


do_detail()
{
echo pile | $SBIN/kdb >  pile.out
$BIN/grep -v "(0)" pile.out | $BIN/awk '{
a=1
sumpages=0
while (status=getline >0)
{
        if ( a == 1 )
        {
                if   (substr($0,0,7) != "ADDRESS" )
                        continue;
                else
                {
                        a = 0;
                        continue;
                }
        }


        split ($0,temp)
        printf("%16s  %16d kbytes\n",temp[2],temp[3]*4);
        sumpages = sumpages + temp[3];

}
        printf("========================================\n");
        printf("TOTAL JFS2 kernel heap usage:  %d kbytes\n", sumpages*4);
}'

}


if [ "$1" = "-s" ]; then
	do_summary
else
	do_detail
fi

/bin/cat /proc/sys/fs/jfs2/memory_usage
