#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp. 2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# svmon.sh
#
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

WPARG=0
WPARARGG=ALL
WPARPG=0
WPARARGPG=ALL
AME=0
bufsize=32MB

show_usage()
{
	echo "Usage: svmon.sh [-o outputfile] [-w <wparname|ALL>] [-W <wparname|ALL>][-b maxbufsize]"
	echo "default output file is svmon.out"
	exit 1
}

do_timestamp()
{
        if [ "$2" = "nonewline" ]; then
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
        else
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
        fi
}


# exit if svmon executable is not installed
if [ ! -f /usr/bin/svmon ]; then
  echo "     SVMON: /usr/bin/svmon command is not installed"
  echo "     SVMON:   This command is part of the 'bos.perf.tools' fileset."
  exit 1
fi


while getopts b:Ao:w:W: flag ; do
        case $flag in
		b)     bufsize=$OPTARG;;
		A)     AME=1;;
		o)     filename=$OPTARG;;
		w)     WPARARGG=$OPTARG;WPARG=1;;
		W)     WPARARGPG=$OPTARG;WPARPG=1;;
                \?)    show_usage
        esac
done
if [ -z "$filename" ]; then
	filename=svmon.out
fi

svmon_begin_sec=$SECONDS
if [ $AME -eq 1 ]
then
        SVMONOPT="-O summary=ame -O pgsz=on"
fi

do_G_flag()
{
if [ $WPARG -eq 1 ]
then
	do_timestamp "svmon -G -@ ALL "   nonewline; cursec=$SECONDS
	echo "svmon -G -@ ALL" >> $filename
	echo "----------" >> $filename
	$BIN/svmon -G -@ ALL >> $filename
	#do_timestamp "svmon -G -Oaffinity=detail -@ ALL "
	#echo "svmon -G -Oaffinity=detail -@ ALL" >> $filename
	#$BIN/svmon -G  -Oaffinity=detail -@ ALL >> $filename
	if [ $? -eq 1 ]
	then
		do_timestamp "svmon -G"
		$BIN/svmon -G >> $filename
		#do_timestamp "svmon -G -Oaffinity=detail"
		#echo "svmon -G -Oaffinity=detail" >> $filename
		#echo "----------" >> $filename
		#$BIN/svmon -G  -Oaffinity=detail >> $filename
	fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
else
	do_timestamp "svmon -G "   nonewline; cursec=$SECONDS
	echo "$BIN/svmon -G $SVMONOPT" >> $filename
	echo "----------" >> $filename
	$BIN/svmon -G  $SVMONOPT >> $filename
	#do_timestamp "svmon -G -Oaffinity=detail"
	#echo "svmon -G -Oaffinity=detail" >> $filename
	#echo "----------" >> $filename
	#$BIN/svmon -G  -Oaffinity=detail >> $filename
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
fi
}

do_P_flag()
{
if [ $WPARG -eq 1 ]
then
	if [ $WPARPG -eq 1 ] # different from above WPARG
	then
		#do_timestamp "svmon -Pnsm -@ $WPARARGPG"   nonewline; cursec=$SECONDS
		#echo "svmon -Pnsm -@ $WPARARGPG" >> $filename
		do_timestamp "svmon -P -O mapping=on,maxbufsize=$bufsize -@ $WPARARGPG "   nonewline; cursec=$SECONDS
		echo "svmon -P -O mapping=on,maxbufsize=$bufsize -@ $WPARARGPG" >> $filename
		echo "----------" >> $filename
		#$BIN/svmon -Pnsm -@ $WPARARGPG >> $filename
		$BIN/svmon -P -O mapping=on,maxbufsize=$bufsize -@ $WPARARGPG >> $filename
		if [ $? -eq 1 ]
		then
			#do_timestamp "svmon -Pnsm"
			#$BIN/svmon -Pnsm  >> $filename
			do_timestamp "svmon -P -O mapping=on,maxbufsize=$bufsize"
			$BIN/svmon -P -O mapping=on,maxbufsize=$bufsize  >> $filename
		fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	else
		#do_timestamp "svmon -Pnsm -@ ALL"   nonewline; cursec=$SECONDS
		#echo "svmon -Pnsm -@ ALL" >> $filename
		do_timestamp "svmon -P -O mapping=on,maxbufsize=$bufsize -@ ALL "   nonewline; cursec=$SECONDS
		echo "svmon -P -O mapping=on,maxbufsize=$bufsize -@ ALL" >> $filename
		echo "----------" >> $filename
		#$BIN/svmon -Pnsm -@ ALL >> $filename
		$BIN/svmon -P -O mapping=on,maxbufsize=$bufsize -@ ALL >> $filename
		if [ $? -eq 1 ]
		then
			#do_timestamp "svmon -Pnsm"
			#$BIN/svmon -Pnsm  >> $filename
			do_timestamp "svmon -P -O mapping=on,maxbufsize=$bufsize"
			$BIN/svmon -P -O mapping=on,maxbufsize=$bufsize  >> $filename
		fi
	fi
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
else
	#do_timestamp "svmon -Pnsm"   nonewline; cursec=$SECONDS
	#echo "svmon -Pnsm" >> $filename
	do_timestamp "svmon -P -O mapping=on,maxbufsize=$bufsize "   nonewline; cursec=$SECONDS
	echo "svmon -P -O mapping=on,maxbufsize=$bufsize" >> $filename
	echo "----------" >> $filename
	#$BIN/svmon -Pnsm  >> $filename
	$BIN/svmon -P -O mapping=on,maxbufsize=$bufsize  >> $filename
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
fi
}

do_S_flag()
{
if [ $WPARG -eq 1 ]
then
	#do_timestamp "svmon -lS -@ ALL"   nonewline; cursec=$SECONDS
	#svmon -lS -@ ALL > ${filename}.S
	do_timestamp "svmon -S -O pidlist=on,maxbufsize=$bufsize -@ ALL "   nonewline; cursec=$SECONDS
	svmon -S -O pidlist=on,maxbufsize=$bufsize -@ ALL > ${filename}.S
	if [ $? -eq 1 ]
	then
		#do_timestamp "svmon -lS"
		#svmon -lS > ${filename}.S
		do_timestamp "svmon -S -O pidlist=on,maxbufsize=$bufsize"
		svmon -S -O pidlist=on,maxbufsize=$bufsize > ${filename}.S
	fi
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
else
	#do_timestamp "svmon -lS"   nonewline; cursec=$SECONDS
	#$BIN/svmon -lS > ${filename}.S
	do_timestamp "svmon -S -O pidlist=on,maxbufsize=$bufsize "   nonewline; cursec=$SECONDS
	$BIN/svmon -S -O pidlist=on,maxbufsize=$bufsize > ${filename}.S
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
fi
}

echo "Date/Time:   `$BIN/date`\n" >> $filename

do_G_flag
if [ "$PERFPMR_SEGMENT_COUNT" -gt "$PERFPMR_SEGMENT_LIMIT" ]; then
	echo "$0: Usual svmon -S/-P will not be run because cur_seg_count=$PERFPMR_SEGMENT_COUNT is greater than perfpmr_segment_limit=$PERFPMR_SEGMENT_LIMIT"
	echo "Instead normal svmon -S will be run"
	do_timestamp "svmon -S -O maxbufsize=$bufsize " nonewline; cursec=$SECONDS
	$BIN/svmon -S -O maxbufsize=$bufsize > ${filename}.S
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
else
	do_P_flag
	do_S_flag
fi
do_timestamp "svmon.sh completed" nonewline
let elasec=$SECONDS-$svmon_begin_sec; echo "  :  execution_time: $elasec seconds"
#$BIN/rm -f svmon.tmp
