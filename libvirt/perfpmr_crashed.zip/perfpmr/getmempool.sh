#!/bin/ksh
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

do_postprocess=0
if [ "$1" = "-p" ]; then
	do_postprocess=1
fi

do_bcd()
{
	echo "ib=16\n$1"|$BIN/bc
}
do_bch()
{
	echo "ob=16\n$1"|$BIN/bc
}


get_kdb()
{
#np=`$BIN/vmstat -v|$BIN/grep "memory pools"|$BIN/awk '{print $1}'`
#np=`echo "mempool *"| $SBIN/kdb |$BIN/grep vmmdseg|$BIN/wc -l`
#nf=`echo "frameset *"|$SBIN/kdb | $BIN/grep vmmdseg|$BIN/wc -l`
np=`echo "mempool *"| $SBIN/kdb |$BIN/awk 'BEGIN { mp=0 }{ if ($0 ~ /^$/) next; if (mp == 1) { if ($1 != "(0)>") print $0 } if ($1=="VMP") { mp = 1 } }'|$BIN/wc -l`
nf=`echo "frameset *"| $SBIN/kdb |$BIN/awk 'BEGIN { mp=0 }{ if ($0 ~ /^$/) next; if (mp == 1) { if ($1 != "(0)>") print $0 } if ($1=="FRS") { mp = 1 } }'|$BIN/wc -l`
let fr_per_pool=nf/np
p=0
f=0
str=""
while [ $p -lt $np ]; do
    if [ $fr_per_pool = 2 ]; then
	let f1=p*2
	let f2=f1+1
	pH=`do_bch $p`
	f1H=`do_bch $f1`
	f2H=`do_bch $f2`
	str="$str lrustate $pH\nmempool $pH\nframeset $f1H\nframeset $f2H\n"
    elif [ $fr_per_pool = 4 ]; then
	let f1=p*4
	let f2=f1+1
	let f3=f2+1
	let f4=f3+1
	pH=`do_bch $p`
	f1H=`do_bch $f1`
	f2H=`do_bch $f2`
	f3H=`do_bch $f3`
	f4H=`do_bch $f4`
	str="$str lrustate $pH\nmempool $pH\nframeset $f1H\nframeset $f2H\nframeset $f3H\nframeset $f4H\n"
    fi
    let p=p+1
done
str="$str memstat\nmemstat -av\nmempsum -psx"
echo "$str" | $SBIN/kdb
}

post_process()
{
file=$1
	
$BIN/egrep -w "Page Size|(lrumem)|(nolru)|(all_lrumem)|Memory Pool|nb_frame|numclient|numperm|rpgcnt|Frame Set|numfrb" $file| while read line 
 do
	if echo $line | $BIN/grep "Page Size" >/dev/null; then
		echo "  $line"
		continue
	fi
	hval=`echo "$line"|$BIN/awk -F: '{print $2}'`
	nm=`echo "$line"|$BIN/awk -F: '{print $1}'`
	if [ "$hval" != "" ]; then
		echo "\t$nm : `do_bcd $hval`"
	else
		if echo "$nm" | $BIN/grep "Frame Set" >/dev/null; then
			echo "  $nm"
		else
			echo "\n$nm"
			
		fi
	fi
done
}


get_kdb > mempools.out

get_kdb2()
{
# get actual frames in each pool
str=""
$BIN/egrep  "(lrumem)|(nolru)|(all_lrumem)" mempools.out | $BIN/awk -F: '{print $2}'|while read lrumem 
do
	str="$str vmint $lrumem\n" 
done
i=0;set -A lrumemA `echo "$str"| $SBIN/kdb | $BIN/grep pages|$BIN/awk '{print $1}'`
str=""
while read line; do
	if echo $line | $BIN/egrep "lrumem" >/dev/null; then
		echo $line | read a b c d e f
		echo "$a $b $c $d     $e ${lrumemA[$i]}"
	  	let i=i+1
	else
	  echo $line
	fi
done < mempools.out > mempools.out1
$BIN/cp mempools.out mempools.save
		

$BIN/mv mempools.out1 mempools.out
if [ "$do_postprocess" = 1 ]; then
	post_process mempools.out
else
	$BIN/cat mempools.out
fi
echo "memp *\n\nvmpool -l *" | $SBIN/kdb
}



echo "memp *\n\nvmpool *" | $SBIN/kdb >> mempools.out
