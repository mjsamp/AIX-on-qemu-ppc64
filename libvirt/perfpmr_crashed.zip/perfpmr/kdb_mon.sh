#!/bin/ksh
TIMEP=${1:-600}
# determine INTERVAL and COUNT
if [ $TIMEP -lt 601 ]; then
 INTERVAL=10
 let COUNT=$TIMEP/10
else
 INTERVAL=60
 let COUNT=$TIMEP/60
fi

i=0
(
while [ $i -lt $COUNT ]
do
        /usr/bin/sleep $INTERVAL
        echo '!echo "TIMESTAMP: `/usr/bin/date`"'
        echo "rqi"
	echo "mrq *"
        echo "ppda *"
        let i=i+1
done
) 2>/dev/null |   /usr/sbin/kdb > rqi_ppda_mrq.out
/usr/bin/grep -v -E 'echo|CURTHREAD|ppda|mrq|primary|run_queue|num_nodes|near|load|FLAGS|MRQ|my_n|active|rqs|exclu|disabled_cpus|rq_slot|zstart|sched_tid|S3_any|num_S1|S2_stealable|srad_mask|aff_info|lsample|accum' rqi_ppda_mrq.out > rqi.out
#/usr/bin/grep -v -E 'echo|CURTHREAD|ppda' rqi_ppda.out > rqi.out
/usr/bin/grep  -E 'TIMESTAMP|CURTHREAD|ppda' rqi_ppda_mrq.out|/usr/bin/grep -v echo > ppda.out
/usr/bin/grep -E 'TIMESTAMP|echo|mrq|primary|run_queue|num_nodes|near|load|FLAGS|MRQ|my_n|active|rqs|exclu|disabled_cpus|rq_slot|zstart|sched_tid|S3_any|num_S1|S2_stealable|srad_mask|aff_info|lsample|accum' rqi_ppda_mrq.out > mrq.out

/usr/bin/rm rqi_ppda_mrq.out
