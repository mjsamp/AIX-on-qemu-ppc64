#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp.  2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# tcpdump.sh
#
# invoke RISC System/6000 tcpdump command or generate report
#
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

TCPDUMPOUT=tcpdump.raw
show_usage()
{
        echo "Usage: tcpdump.sh [-S][-f tcpdump_rawfilename] [-i IFname] <seconds> | tcpdump.sh [-f tcdump_rawfilename][-i IFname] -r"
        echo "\t-S  bring up SEA interfaces if down on a VIOS but restore them to original state after tcpdump"
        echo "\t-i  name of interface ex. tr0 or en0 ..."
	echo "\t      Can specify -i multiple times to trace or run reports on multiple interfaces"
        echo "\t-f  name of tcpdump raw file .. default is ${TCPDUMPOUT}.<interface>"
        echo "\t-r  produce reports and place in tcpdump.int.<interface> file"
	echo "\ttime in seconds is how long to collect data"
        exit 1
}

do_timestamp()
{
        echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
}

check_for_fixes()
{
	tcpdump_ok=1
	aixv=`$BIN/uname -v`
	aixr=`$BIN/uname -r`
	lnc_level=`$BIN/lslpp -qLc  devices.ethernet.lnc.rte 2>/dev/null |$BIN/awk -F: '{print $3}'`
	lnc2_level=`$BIN/lslpp -qLc  devices.ethernet.lnc2.rte 2>/dev/null |$BIN/awk -F: '{print $3}'`
	# The following APARs fix an Etherchannel issue triggered by tcpdump
	if [ "$lnc_level" != "" -o "$lnc2_level" != "" ]; then
		if [ "$aixv" = 6 ]; then
			lnc_tl=`echo $lnc_level|$BIN/awk -F. '{print $3}'`
			if [ "$lnc_tl" -lt 9 ]; then
				tcpdump_ok=0
			fi
			if [ "$lnc_tl" -eq 9 ]; then
				$SBIN/instfix -ik IV80689 > /dev/null 2>&1
				if [ $? -eq 0 ]; then
                			tcpdump_ok=1
				else
                			tcpdump_ok=0
        			fi
			fi
		fi
		if [ "$aixv" = 7 -a "$aixr" = 1 ]; then
			lnc_tl=`echo $lnc_level|$BIN/awk -F. '{print $3}'`
			if [ "$lnc_tl" -lt 3 ]; then
				tcpdump_ok=0
			fi
			if [ "$lnc_tl" -eq 3 ]; then
				$SBIN/instfix -ik IV78920 > /dev/null 2>&1
				if [ $? -eq 0 ]; then
                			tcpdump_ok=1
				else
                			tcpdump_ok=0
        			fi
			fi
			if [ "$lnc_tl" -eq 4 ]; then
				$SBIN/instfix -ik IV81423 > /dev/null 2>&1
				if [ $? -eq 0 ]; then
                			tcpdump_ok=1
				else
                			tcpdump_ok=0
        			fi
			fi
			if [ "$lnc_tl" -gt 4 ]; then
				tcpdump_ok=1
			fi
		fi
		if [ "$aixv" = 7 -a "$aixr" = 2 ]; then
			lnc2_tl=`echo $lnc2_level|$BIN/awk -F. '{print $3}'`
			if [ "$lnc2_tl" -eq 0 ]; then
				$SBIN/instfix -ik IV82108 > /dev/null 2>&1
				if [ $? -eq 0 ]; then
                			tcpdump_ok=1
				else
                			tcpdump_ok=0
        			fi
			fi
			if [ "$lnc2_tl" -eq 1 ]; then
				$SBIN/instfix -ik IV82482 > /dev/null 2>&1
				if [ $? -eq 0 ]; then
                			tcpdump_ok=1
				else
                			tcpdump_ok=0
        			fi
			fi
		fi
	fi
}
run_reports()
{
	if [ "$iflist" != "" ]; then
		for IF in $iflist; do
			# see if needed files are here
			if [ ! -f ${TCPDUMPOUT}.$IF ]; then
				echo "    TCPDUMP: ${TCPDUMPOUT}.$IF file not found..."
			else
				echo "\n     TCPDUMP: Generating report on ${TCPDUMPOUT}.$IF ...."
				$SBIN/tcpdump  -venr ${TCPDUMPOUT}.$IF > tcpdump.$IF.int 2>&1 
				echo "     TCPDUMP: tcpdump report is in file tcpdump.$IF.int"
			fi
		done
	else
		for file in `ls ${TCPDUMPOUT}*` ; do
			suffix=${file##$TCPDUMPOUT}
			echo "\n     TCPDUMP: Generating report on file $file ...."
			$SBIN/tcpdump  -venr $file > tcpdump.int$suffix 2>&1 
			echo "     TCPDUMP: tcpdump report is in file tcpdump.int$suffix"
		done
	fi
}
stop_and_wait4exit()
{
	num_tcpdumps=$1	 # from collect_data
	j=0
	while [ $j -lt $num_tcpdumps ]; do
		kill -TERM ${tcpdump_pid[$j]}
		let j=j+1
	done
	echo "     TCPDUMP: tcpdump collected."
	# wait until tcpdump has closed the output file
	j=0 ; sleptonce=0
	while [ $j -lt $num_tcpdumps ]; do
		sleepcounter[$j]=0
		while $BIN/ps -p ${tcpdump_pid[$j]} | grep tcpdump | grep -v grep >/dev/null ; do
			if [ "$sleptonce" = 0 ]; then
				$BIN/sleep 5
				sleptonce=1
			else
				$BIN/sleep 2
			fi
			let sleepcounter[$j]=sleepcounter[$j]+1
			if [ "${sleepcounter[$j]}" = 2 ]; then
				$BIN/ps -p tcpdump_pid[$j] | grep tcpdump|grep -v grep >/dev/null && kill -9 tcpdump_pid[$j]
			elif [ "${sleepcounter[$j]}" = 3 ]; then
				echo "tcpdump on ${interfaces[$j]} is hung .. please investigate this"
			fi
		done
   		echo "     TCPDUMP: Binary tcpdump data is in file ${TCPDUMPOUT}.${interfaces[$j]}"
		let j=j+1
	done
}
handle_vios()
{
     action=$1
     if [ "$action" = "run" ]; then
        num_seas=0
        $SBIN/lsdev -C| $BIN/grep "Shared Ethernet Adapter"|$BIN/grep Avail|$BIN/awk '{print $1}'| while read seadev
        do
           num=${seadev##*ent}
           enif=en$num
           vio_seaifs_name[$num_seas]=$enif
             /etc/ifconfig $enif 2>/dev/null| $BIN/grep "<UP," >/dev/null
             if [ $? = 0 ]; then
                vio_seaifs_state[$num_seas]=up;
             else
                vio_seaifs_state[$num_seas]=down;
                do_timestamp "Bring up ${vio_seaifs_name[$num_seas]} SEA interface for tcpdump .. does increase overhead"
                  ifconfig ${vio_seaifs_name[$i]} up
             fi
             let num_seas=num_seas+1
        done
    fi

    if [ "$action" = "stop" ]; then
        i=0
        while [ $i -lt $num_seas ]
        do
                if [ ${vio_seaifs_state[$i]} = "down" ]; then
                  do_timestamp "Restore ${vio_seaifs_name[$num_seas]} SEA interface to original state of down"
                  ifconfig ${vio_seaifs_name[$i]} down
                fi
                let i=i+1
        done
    fi
}
collect_data()
{
	echo "\n     TCPDUMP: Starting tcpdump for $sleeptime seconds...."
	cursec=$SECONDS
	i=0
	for IF in $iflist; do
		interfaces[$i]=$IF
		$BIN/rm -f ${TCPDUMPOUT}.$IF
		$SBIN/tcpdump -i $IF -w ${TCPDUMPOUT}.$IF 2> tcpdump.$IF.err &
		tcpdump_pid[$i]=$!
		let i=i+1
	done
	$BIN/sleep $sleeptime
	stop_and_wait4exit $i  # call function to stop the tcpdumps and wait for them to exit
  	let elasec=$SECONDS-$cursec; echo "TCPDUMP COLLECTION :  execution_time: $elasec seconds"
}

if [ $# -eq 0 ]; then
	show_usage
fi

if [ ! -x /usr/sbin/tcpdump ]; then
	echo "\n     TCPDUMP: /usr/sbin/tcpdump is not installed."
	echo   "     TCPDUMP:  This command is part of the bos.net.tcp.server' fileset."
	exit 1
fi

check_for_fixes
if [ $tcpdump_ok -ne 1 ]; then
        echo "tcpdump.sh: IV78920, IV80689, IV81423, IV82108, or IV82482  must be installed. Unable to collect tcpdump data"
        exit 0
fi


iflist=""
while getopts Sf:ri: flag ; do
        case $flag in
		f)	TCPDUMPOUT=$OPTARG;;
                i)     iflist="$iflist $OPTARG";;
                r)     doreport=1;;
                S)     vios_iptrc=1;;
                \?)    show_usage
        esac
done
shift OPTIND-1
sleeptime=$@

if [ "$iflist" = "" -a -z "$doreport" ]; then  # do all but loopback
   	if [ "$vios_iptrc" = 1 ]; then
        	if [ -d /usr/ios ]; then
               	 handle_vios run
        	fi
   	fi
	# use output of tcpdump -D to get the list. Ex.:
		# tcpdump -D
		# 1.en0
		# 2.en1
		# 3.lo0 [Loopback]
	#iflist=`$SBIN/tcpdump -D | $BIN/grep -v Loopback | cut -d. -f2`
	iflist=`$SBIN/tcpdump -D | $BIN/grep -v Loopback | $BIN/awk '{print $1}' | $BIN/cut -d. -f2`
fi
	
#
# see if tcpdump to be taken now
if [ -z "$doreport" ]; then
	if [ "$sleeptime" = "" ]; then
		echo "$0: must specify collection time in seconds"
		exit 1
	fi
	collect_data
   if [ "$vios_iptrc" = 1 ]; then
        if [ -d /usr/ios ]; then
                handle_vios stop
        fi
   fi
else
	run_reports
fi
exit 0
