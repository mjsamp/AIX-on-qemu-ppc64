#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp.  2000,2001,2002,2003,2004,2005,2006,2007
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# perfpmr.sh
#
# collect standard performance data needed for AIX performance pmr
#

unset ENV
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
export PATH=$BIN:/etc:$SBIN
cursec=$SECONDS
#PREVPERFPMRVER='2022/09/25'
PERFPMRVER='Universal 2024/02/08'
PERFPMRTIME=1707418990   # number of seconds since EPOCH for version of perfpmr
TOO_OLD=7776000	# number of seconds in 3 months


#-----------------------------
# Name: show_usage
#-----------------------------
show_usage()
{
  echo "Version: $PERFPMRVER"
  echo "\nperfpmr.sh: Usage: \n"
  echo "  perfpmr.sh [-bOVkhUyPQDIgfnpscEGHASTuNe][-C component_string][-r][-i intvltime_sec][-F file][-x file][-d sec] [-W program [-w sec]][-o "outputdirs"][-Z][-z paxfile] monitor_seconds"
  echo "  -b preallocate AIX trace buffers before trace.sh is run"
  echo "  -C component_string  - run comptrace.sh specifying -C component_string"
  echo "  -i intvltime_sec  - override monitor scripts interval times"
  echo "  -k do not run kdb"
  echo "  -T do not run iptrace nor tcpdump"
  echo "  -r run post processing scripts only"
  echo "  -P preview only - show scripts to run and disk space needed"
  echo "  -Q don't run lsattr,lvlv,lspv commands in order to save time"
  echo "  -D run perfpmr the original way without a perfpmr cfg file"
  echo "  -I get lock instrumented trace also"
  echo "  -g do not collect gennames output."
  echo "  -f if gennames is run, specify gennames -f."
  echo "  -A will use all other options such as -H, -E, and tprof -D needed for AMS systems"
  echo "  -E used if -E flag in tprof is desired"
  echo "  -h used if hpmstat desired."
  echo "  -G used if no fcstat/fcstat2 is to be run"
  echo "  -H used if hpmcount.sh is to be run"
  echo "  -n used if no netstat or nfsstat desired."
  echo "  -p used if no pprof collection desired while monitor.sh running."
  echo "  -s used if no svmon/memdetails desired."
  echo "  -c used if no configuration information is desired."
  echo "  -U used if pmucount.sh should be run"
  echo "  -u used if probevue.sh should be run"
  echo "  -y used if 24x7count.sh should NOT be run"
  echo "  -N used if snap command should NOT be run"
  echo "  -e used if inode and vnode data should NOT be collected"
  echo "  -S bring Shared Ethernet Adapter interfaces up when running iptrace"
  echo "  -F file   use file as the perfpmr cfg file - default is perfpmr.cfg"
  echo "  -x file   only execute file found in perfpmr installation directory"
  echo "  -d sec  sec is time to wait before starting collection period"
  echo "                default is delay_seconds 0"
  echo "  -W program  wait until <program> is in the process table before data collection begins"
  echo "              delay -w seconds between each ps command or by default 10 seconds each time"
  echo "  -o outdirs  list of directory names to archive into pax file (must be enclosed in quotes) - default is current dir"
  echo "  -z paxfile  archive data files into gzipped pax file specified with -z - ex. /tmp/sfticket#.pax.gz"
  echo "  -Z run pax and gzip after data collection (must be used with -z option)"
  echo "  -O override warning/sleep delays due to perfpmr being too old or not having enough memory"
  echo "  -V      display the version of perfpmr"

  echo "  monitor_seconds is for the the monitor collection period in seconds"

  echo "\nUse 'perfpmr.sh 600' for the standard collection period where the high level"
  echo "stats are collected for 600 seconds."
  echo "Note that the time required for perfpmr to complete will be an additional few"
  echo "minutes or more beyond time specified. On servers where there are a very"
  echo "large number of processes and/or large libraries in memory or a huge number"
  echo "of files in memory, perfpmr could take much longer to complete."
  echo "Adding the -U option to get pmucount data could add an additional 10 minutes"
  echo "to the perfpmr completion time."
  exit 1
}

#-----------------------------
# Name: validate_fs
#-----------------------------
validate_fs()
{
        $BIN/df $PWD | $BIN/tail -1 | $BIN/awk '{print $1,$NF}'  | read lv fs
        if [ "$fs" != "" ]; then
             $SBIN/mount | $BIN/fgrep -w "$fs" | $BIN/awk '{print $3,$4,$7}' | read fstype1 fstype2 options
             if echo $options | $BIN/egrep 'cio|dio' >/dev/null; then
                echo "The filesystem for $PWD is mounted with 'cio' or 'dio'"
                echo "Data collection will have additional overhead"
                echo "Delaying 5 seconds to allow ctrl/c out of perfpmr.sh"
                $BIN/sleep 5
             fi
             if echo $fstype1 $fstype2 | $BIN/egrep 'nfs|dfs|autofs' >/dev/null; then
                echo "The filesystem for $PWD is a remote filesystem"
                echo "Data collection may have additional overhead"
                echo "Delaying 5 seconds to allow ctrl/c out of perfpmr.sh"
                $BIN/sleep 5
             fi
        fi
}


#-----------------------------
# Name: do_timestamp
#-----------------------------
do_timestamp()
{
        if [ "$2" = "nonewline" ]; then
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
        else
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
        fi
}


#-----------------------------
# Name: wait_for_program
#-----------------------------
wait_for_program()
{

	if [ -n "$WAITDELAY" ]; then
		validate_int "$WAITDELAY" &&  waitdelay=$WAITDELAY
	else
		waitdelay=10
	fi
	if [ -n "$WAITFORPROGRAM" ]; then
		do_timestamp "wait for process" | $TEEOUT
		echo "PERFPMR: waiting for <$WAITFORPROGRAM> to be in the process table" | $TEEOUT
		while :; do
			if $BIN/ps -ef | $BIN/grep "$WAITFORPROGRAM" |$BIN/egrep -v 'grep|perfpmr.sh' >/dev/null; then
				break;
			else
				sleep ${waitdelay:-10}
			fi
		done
		do_timestamp "wait for process completed" | $TEEOUT
	fi
}
#-----------------------------
# Name: perfpmr_trace_419
#-----------------------------
perfpmr_trace_419()
{

if [ "$1" != "getargs" ]; then
	if [ "$traceexists" = "true" ]; then
   	echo "WARNING: A trace process is already running."
   	echo "         perfpmr will not gather information using trace."
   	echo "         Stop the trace process (trcstop) and rerun perfpmr"
   	echo "         to collect a complete set of standard system"
   	echo "         performance data.\n"
	return
	fi

	echo "                        PERFPMR: Executing $PERFPMRDIR/trace_419.sh $@" | $TEEOUT
	$PERFPMRDIR/trace_419.sh $@ 2>&1| $TEEOUT
	return
fi
shift
$BIN/awk -v ncpus=$NCPUS '
BEGIN {
}
/^trace_419.sh/ {
	while (status=getline >0) 
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "inhooks" && temp[3] != "")
                                inhooks= "-j " temp[3]
                if (temp[1] == "exhooks" && temp[3] != "")
                                exhooks= "-k " temp[3]
                if (temp[1] == "ingrps" && temp[3] != "")
                                ingrps= "-J " temp[3]
                if (temp[1] == "exgrps" && temp[3] != "")
                                exgrps= "-K " temp[3]
                if (temp[1] == "logsize" && temp[3] != "")
                {
                        logsize= "-L " temp[3]
                        logbytes= temp[3]
                }
                if (temp[1] == "kbufsize")
                        kbufsize= "-T " temp[3]
                if (temp[1] == "trace_time_seconds" )
                        trace_time= temp[3]
                if (temp[1] == "space_required" )
                        space= temp[3]
	}
  }
END {
        if ( space == "" )
        {
                if ( per_cpu_trc != "-C" )
                {
                        #"$PERFPMRDIR/lsc -c" | getline ncpus
                        #close("$PERFPMRDIR/lsc -c");
                        space= logbytes * ncpus
                        if ( num_traces != "" )
                                space= space * n_traces
                }
                else {
                        space= logbytes
                        if ( num_traces != "" )
                                space= space * n_traces
                }
        }
        if ( trace_time == "" )
                        trace_time= default_time

        printf("%d perfpmr_trace_419   %s %s %s %s   %s %s %s %s %s\n",
                space, inhooks, exhooks, ingrps, exgrps, logsize,kbufsize, per_cpu_trc,
                num_traces,  trace_time);

} ' default_time=$default_time_trace_419 $PERFPMRCFG
}

#-----------------------------
# Name: perfpmr_comptrace
#-----------------------------
perfpmr_comptrace()
{
if [ "$1" != "getargs" ]; then
        if [ -z "$COMPONENT_STRING" ]; then
		echo "                        PERFPMR: skipping comptrace collection" | $TEEOUT
                return
        fi
	echo "                        PERFPMR: Executing $PERFPMRDIR/comptrace.sh -C $COMPONENT_STRING $@" | $TEEOUT
	$PERFPMRDIR/comptrace.sh -C $COMPONENT_STRING  $@ 2>&1| $TEEOUT
	return
fi
shift
$BIN/awk -v ncpus=$NCPUS '
BEGIN {
}
/^comptrace.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "collect_fc_config" && temp[3] == "true" )
				comp_fc_config = "-f "
                if (temp[1] == "dump_comptrace" && temp[3] == "true")
                                comp_dumptrace= "-d " 
                if (temp[1] == "trace_sleeptime" && temp[3] != "")
                                comp_sleeptime= "-s " temp[3]
		if (temp[1] == "trace_logsz" && temp[3] != "")
		{
			comp_logsize= "-L " temp[3]
			comp_logbytes= temp[3]
		}
		if (temp[1] == "trace_bufsz")
			comp_kbufsize= "-T " temp[3]
	}
  }
END {
	#"$PERFPMRDIR/lsc -c" | getline ncpus
	#close("$PERFPMRDIR/lsc -c");
	space= comp_logbytes * ncpus
	if ( comp_dumptrace == "-d" )
		space = space + 25000000;
	if ( comp_fc_config == "-f" )
		space = space + 2000000;
        if ( comp_sleeptime == "" )
                        comp_sleeptime= "-s " default_time
        printf("%d perfpmr_comptrace  %s %s %s %s %s\n",
                space, comp_logsize,comp_kbufsize, comp_dumptrace, comp_fc_config, comp_sleeptime);
}' default_time=$default_time_comptrace $PERFPMRCFG
}



#-----------------------------
# Name: perfpmr_trace
#-----------------------------
perfpmr_trace()
{

if [ "$1" != "getargs" ]; then
	if [ "$traceexists" = "true" ]; then
   	echo "WARNING: A trace process is already running."
   	echo "         perfpmr will not gather information using trace."
   	echo "         Stop the trace process (trcstop) and rerun perfpmr"
   	echo "         to collect a complete set of standard system"
   	echo "         performance data.\n"
	return
	fi

	echo "                        PERFPMR: Executing $PERFPMRDIR/trace.sh.sh -p $INSTRUMENTEDTRACE $@" | $TEEOUT
	$PERFPMRDIR/trace.sh -p $INSTRUMENTEDTRACE $@ 2>&1| $TEEOUT
	return
fi
shift
$BIN/awk -v ncpus=$NCPUS '
BEGIN {
}
/^trace.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "inhooks" && temp[3] != "")
				inhooks= "-j " temp[3]
		if (temp[1] == "exhooks" && temp[3] != "")
				exhooks= "-k " temp[3]
                if (temp[1] == "ingrps" && temp[3] != "")
                                ingrps= "-J " temp[3]
                if (temp[1] == "exgrps" && temp[3] != "")
                                exgrps= "-K " temp[3]
		if (temp[1] == "logsize" && temp[3] != "")
		{
			logsize= "-L " temp[3]
			logbytes= temp[3]
		}
		if (temp[1] == "kbufsize")
			kbufsize= "-T " temp[3]
		if (temp[1] == "lock_tracing")
		{
			if (temp[3] == "true")
				locktrc= "-S"
			else
				locktrc= ""
		}
		if (temp[1] == "lock_trace_level" && temp[3] != "" )
		{
			locktrclevel= "-E" temp[3]
		}
		if (temp[1] == "interactive_trace")
		{
			if (temp[3] == "true")
				itrc= "-i"
			else
				itrc= ""
		}
		if (temp[1] == "loop_tracing")
		{
			if (temp[3] == "true")
				looptrc= "-l"
			else
				looptrc= ""
		}
		if (temp[1] == "lockinstrumented_trace")
		{
			if (temp[3] == "true")
				instrumented_trace= "-I"
			else
				instrumented_trace= ""
		}
		if (temp[1] == "run_gennames")
		{
			if (temp[3] == "false")
				run_gennames= "-g"
			else
				run_gennames= ""
		}
		if (temp[1] == "get_inode_table")
		{
			if (temp[3] == "true")
				get_inode_tbl= ""
			else
				get_inode_tbl= "-N"
		}
		if (temp[1] == "get_component_trace")
		{
			if (temp[3] == "true")
				component_trc_flag= "-c"
			else
				component_trc_flag= ""
		}
		if (temp[1] == "per_cpu_trc")
		{
			if (temp[3] == "true" )
				per_cpu_trc= ""
			else
				per_cpu_trc= "-C"
		}
		if (temp[1] == "num_traces_to_run" && temp[3] != "" )
		{
			num_traces= "-n " temp[3]
			n_traces=  temp[3]
		}
		if (temp[1] == "delay_seconds" && temp[3] != "" )
			delay_seconds= "-s " temp[3]
		if (temp[1] == "trace_time_seconds" )
			trace_time= temp[3]
		if (temp[1] == "space_required" )
			space= temp[3]
                if (temp[1] == "loop_trace_stop_file" && temp[3] != "" )
                        stop_trigger_file= "-f " temp[3]
		if (temp[1] == "force_trace")
		{
        		if (temp[3] == "true")
                		forcetrace= "-F"
        		else
                		forcetrace= ""
		}
			
	}
  }
END {

	if ( space == "" )
	{
		if ( per_cpu_trc != "-C" )
		{
			#"$PERFPMRDIR/lsc -c" | getline ncpus
			#close("$PERFPMRDIR/lsc -c");
			space= logbytes * ncpus
			if ( num_traces != "" )
				space= space * n_traces
		}
		else {
			space= logbytes
			if ( num_traces != "" )
				space= space * n_traces
		}
	}
	if ( trace_time == "" )
			trace_time= default_time

	printf("%d perfpmr_trace %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
		space, ingrps, exgrps, inhooks,exhooks,logsize,kbufsize,instrumented_trace,locktrc,
		itrc,looptrc,run_gennames,get_inode_tbl,per_cpu_trc,
		num_traces, delay_seconds, stop_trigger_file, forcetrace,component_trc_flag, locktrclevel, trace_time);

} ' default_time=$default_time_trace $PERFPMRCFG
}  


#-----------------------------
# Name: perfpmr_hpmcount
#-----------------------------
perfpmr_hpmcount()
{
if [ "$1" != "getargs" ]; then
    if [ -z "$HPMCOUNT_HFLAG" ]; then
	echo "                        PERFPMR: skipping hpmcount collection" | $TEEOUT
	return
    fi
	if whence hpmcount >/dev/null; then
		echo "                        PERFPMR: Executing $PERFPMRDIR/hpmcount.sh $@" | $TEEOUT
		$PERFPMRDIR/hpmcount.sh  $@ 2>&1 $TEEOUT
	fi
	return
fi

shift
$BIN/awk  '
BEGIN {
}
/^hpmcount.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "hpmcount_time_seconds" && temp[3] != "")
			hpmcount_time_secs = temp[3]
		if (temp[1] == "space_required" )
			space= temp[3]
	}
   }
END {
	if ( space == "" )
		space= 1000000
	if ( hpmcount_time_secs == "" )
		hpmcount_time_secs= default_time
	if ( HPMCOUNT_FLAG == 1 )
		hpmcount_flag= ""
	else
		hpmcount_flag= "-H"
	printf("%d perfpmr_hpmcount %s %s\n", space, hpmcount_flag, hpmcount_time_secs);
} ' default_time=$default_time_hpmcount HPMCOUNT_FLAG=$HPMCOUNT_HFLAG $PERFPMRCFG
}



#-----------------------------
# Name: perfpmr_pmucount
#-----------------------------
perfpmr_pmucount()
{
if [ "$1" != "getargs" ]; then
    	if [ -z "$PMUCOUNT_FLAG" ]; then
		echo "                        PERFPMR: skipping pmucount collection" | $TEEOUT
		return
    	fi
	echo "                        PERFPMR: Executing $PERFPMRDIR/pmucount.sh $@" | $TEEOUT
	$PERFPMRDIR/pmucount.sh  $@ 2>&1| $TEEOUT
        return
fi

shift
$BIN/awk  '
BEGIN {
}
/^pmucount.sh/ {
        while (status=getline >0)
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "pmucount_time_seconds" && temp[3] != "")
                        pmucount_time_secs = temp[3]
                if (temp[1] == "pmucount_group_range" && temp[3] != "")
                        pmucount_group_num = "-g " temp[3]
                if (temp[1] == "pmucount_outfile" && temp[3] != "")
                        pmucount_outfile = "-o " temp[3]
                if (temp[1] == "pmucount_errfile" && temp[3] != "")
                        pmucount_errfile = "-e " temp[3]
                if (temp[1] == "pmucount_priority" && temp[3] != "")
                        pmucount_priority = "-P " temp[3]
                if (temp[1] == "space_required" )
                        space= temp[3]
        }
   }
END {
        if ( space == "" )
                space= 1000000
        if ( pmucount_time_secs == "" )
                pmucount_time_secs= default_time_pmucount
        printf("%d perfpmr_pmucount %s %s %s %s %s \n", space, pmucount_group_num, pmucount_outfile, pmucount_errfile, pmucount_priority, pmucount_time_secs);
} ' default_time=$default_time_pmucount $PERFPMRCFG
}

#-----------------------------
# Name: perfpmr_probevue
#-----------------------------
perfpmr_probevue()
{
if [ "$1" != "getargs" ]; then
        if [ -z "$PROBEVUE_FLAG" ]; then
                echo "                        PERFPMR: skipping probevue collection" | $TEEOUT
                return
        fi
	echo "                        PERFPMR: Executing $PERFPMRDIR/probevue.sh $@" | $TEEOUT
	$PERFPMRDIR/probevue.sh  $@ 2>&1| $TEEOUT
        return
fi

shift
$BIN/awk  '
BEGIN {
}
/^probevue.sh/ {
        while (status=getline >0)
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "probevue_time_seconds" && temp[3] != "")
                        probevuetime = temp[3]
                if (temp[1] == "probevue_lockcount" && temp[3] != "")
                        probevuelcount = temp[3]
                if (temp[1] == "probevue_stackdepth" && temp[3] != "")
                        probevuesdepth = temp[3]
                if (temp[1] == "space_required" )
                        space= temp[3]
        }
   }
END {
        if ( space == "" )
                space= 2000000
        if ( probevuetime == "" )
                probevuetime = default_time_probevue
        printf("%d perfpmr_probevue %s\n", space, probevuetime, probevuelcount, probevuesdepth);
} ' default_time=$default_time_probevue $PERFPMRCFG
}

#-----------------------------
# Name: perfpmr_premonitor
#-----------------------------
perfpmr_perfpmr_premonitor()
{
if [ "$1" != "getargs" ]; then
        echo "                        PERFPMR: Executing $PERFPMRDIR/perfpmr_premonitor.sh $@" | $TEEOUT
	if echo $@ | $BIN/grep -- "-t" >/dev/null; then
		export TCPSTAT_PREMONITOR=1
	fi
        $PERFPMRDIR/perfpmr_premonitor.sh  $@ 
	/bin/sleep 1
        return
fi

shift
$BIN/awk  '
BEGIN {
}
/^perfpmr_premonitor.sh/ {
	perfstat_intvl_time=1;
	tcpstat_intvl_time=1;
	vmstat_intvl_time=1;
	iostatstat_intvl_time=10;
	lparstath_intvl_time=10;
	lparstatH_intvl_time=10;
        while (status=getline >0)
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "space_required" )
                        space= temp[3]
                if (temp[1] == "run_perfstat" )
                {
                        if (temp[3] == "true" )
                                run_perfstat= "-p"
                }
                if (temp[1] == "perfstat_intvl_time" )
		{
			if ( temp[3] != "" )
                        	perfstat_intvl_time= temp[3];
		}
                if (temp[1] == "run_tcpstat" ) 	# for premonitor
                {
                        if (temp[3] == "true" )
                                run_tcpstat= "-t"
                }
                if (temp[1] == "tcpstat_intvl_time" )
		{
			if ( temp[3] != "" )
                        	tcpstat_intvl_time= temp[3];
		}
                if (temp[1] == "run_vmstat" ) 	# for premonitor
                {
                        if (temp[3] == "true" )
                                run_vmstat= "-v"
                }
                if (temp[1] == "vmstat_intvl_time" )
		{
			if ( temp[3] != "" )
                        	vmstat_intvl_time= temp[3];
		}
                if (temp[1] == "run_iostat" ) 	# for premonitor
                {
                        if (temp[3] == "true" )
                                run_iostat= "-i"
                }
                if (temp[1] == "iostat_intvl_time" )
		{
			if ( temp[3] != "" )
                        	iostat_intvl_time= temp[3];
		}
                if (temp[1] == "run_lparstath" ) 	# for premonitor
                {
                        if (temp[3] == "true" )
                                run_lparstath= "-h"
                }
                if (temp[1] == "lparstath_intvl_time" )
		{
			if ( temp[3] != "" )
                        	lparstath_intvl_time= temp[3];
		}
                if (temp[1] == "run_lparstatH" ) 	# for premonitor
                {
                        if (temp[3] == "true" )
                                run_lparstatH= "-H"
                }
                if (temp[1] == "lparstatH_intvl_time" )
		{
			if ( temp[3] != "" )
                        	lparstatH_intvl_time= temp[3];
		}
        }
   }
END {
        if ( space == "" )
                space= 4000000;
	if ( run_tcpstat == "-t" )
		tcpstat = sprintf("-t %d", tcpstat_intvl_time);
	if ( run_perfstat == "-p" )
		perfstat = sprintf("-p %d", perfstat_intvl_time);
	if ( run_vmstat == "-v" )
		vmstat = sprintf("-v %d", vmstat_intvl_time);
	if ( run_iostat == "-i" )
		iostat = sprintf("-i %d", iostat_intvl_time);
	if ( run_lparstath == "-h" )
		lparstath = sprintf("-h %d", lparstath_intvl_time);
	if ( run_lparstatH == "-H" )
		lparstatH = sprintf("-H %d", lparstatH_intvl_time);
        printf("%d perfpmr_perfpmr_premonitor %s %s %s %s %s %s \n", space,perfstat,iostat,vmstat,lparstath, lparstatH, tcpstat);
} '  $PERFPMRCFG
}
#-----------------------------
# Name: perfpmr_allocate_tracebuffers
#-----------------------------
perfpmr_allocate_tracebuffers()
{
if [ "$1" != "getargs" ]; then
	if [ "$preallocate_tracebufs" = 1 ]; then
        	echo "                        PERFPMR: Executing $PERFPMRDIR/allocate_tracebuffers.sh $@" | $TEEOUT
        	$PERFPMRDIR/allocate_tracebuffers.sh
	fi
        return
fi
shift
$BIN/awk  '
BEGIN {
}
/^allocate_tracebuffers.sh/ {
}
END {
	printf("%d perfpmr_allocate_tracebuffers %s\n", 0,"");
}' $PERFPMRCFG
}



#-----------------------------
# Name: perfpmr_config
#-----------------------------
perfpmr_config()
{
if [ "$1" != "getargs" ]; then
	if [  -z "$NO_CONFIG" ]; then
	    echo "                        PERFPMR: Executing $PERFPMRDIR/config.sh $NO_SNAPDATA $NO_KDB $QUICK_CFG $CFGFLAGS $@" | $TEEOUT
	    $PERFPMRDIR/config.sh $NO_SNAPDATA $NO_KDB $QUICK_CFG $CFGFLAGS $@ 2>&1| $TEEOUT
	else
		echo "                        PERFPMR: skipping config.sh collection" | $TEEOUT
	fi
	return
fi

shift
$BIN/awk  '
BEGIN {
}
/^config.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "run_lsattr_all_devs" )
		{
			if (temp[3] == "false" )
				run_lsattr_all= "-a"
		}
		if (temp[1] == "run_gennames" )
		{
			if (temp[3] == "false" )
				run_gennames= "-g"
		}
		if (temp[1] == "detailed_LV_info" )
		{
			if (temp[3] == "false" )
				detailedLV= "-l"
		}
		if (temp[1] == "run_lspv_alldisks" )
		{
			if (temp[3] == "false" )
				runlspvall= "-p"
		}
		if (temp[1] == "get_ssa_cfg" )
		{
			if (temp[3] == "false" )
				getssacfg= "-s"
		}
		if (temp[1] == "quicker_config" )
		{
			if (temp[3] == "true" )
				quicker_cfg= "-Q"
		}
		if (temp[1] == "detailed_mem" )
		{
			if (temp[3] == "false" )
				dodetailed_mem= "-m"
		}
		if (temp[1] == "detailed_mem_user_threshold" )
		{
			if (temp[3] != "" )
				dodetailed_mem_user= "-u " temp[3]
		}
		if (temp[1] == "get_ldatacreate_callers" )
		{
			if (temp[3] == "true" )
				doldatacallers= "-L"
		}
                if (temp[1] == "do_not_run_kdb" )
                {
                        if (temp[3] = "true" )
                                nokdb= "-k "
                }
		if (temp[1] == "get_vnode_data" )
		{
			if (temp[3] == "false" )
				getvnode= "-v"
		}
		if (temp[1] == "get_snap_data" )
		{
			if (temp[3] == "false" )
				getsnap= "-N"
		}
		if (temp[1] == "space_required" )
			space= temp[3]
	}
 }
END {
	if ( space == "" )
		space= 2000000
	printf("%d perfpmr_config %s %s %s %s %s %s %s %s %s %s %s %s\n", space,
		run_lsattr_all,run_gennames,detailedLV, runlspvall, getssacfg, quicker_cfg, dodetailed_mem, dodetailed_mem_user,nokdb,getvnode,getsnap,doldatacallers);
} '  nokdb="$NO_KDB" quicker_cfg="$QUICK_CFG"  $PERFPMRCFG
}  


#-----------------------------
# Name: perfpmr_filemon
#-----------------------------
perfpmr_filemon()
{
if [ "$1" != "getargs" ]; then
	if [ "$traceexists" = "true" ]; then
		echo "WARNING: no filemon data will be collected since trace process was detected"
		return
	fi
	if whence filemon >/dev/null; then
	        echo "                        PERFPMR: Executing $PERFPMRDIR/filemon.sh $@" | $TEEOUT
		$PERFPMRDIR/filemon.sh $@ 2>&1| $TEEOUT
	fi
	return
fi

shift
$BIN/awk  -v ncpus=$NCPUS '
BEGIN {
}
/^filemon.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "filemon_time_seconds" && temp[3] != "")
			filemon_time_secs = temp[3]
		if (temp[1] == "filemon_kbufsize" )
			filemon_kbufsize= temp[3]
                if (temp[1] == "filemon_Ooptions" )
                        filemon_Ooptions= temp[3]
		if (temp[1] == "space_required" )
			space= temp[3]
		if (temp[1] == "filemon_rmtrcfiles" )
                        if (temp[3] == "true" )
                                fmon_rmtrcfiles= "-D"

	}
   }
END {
	if ( space == "" )
		space= 1000000
	if ( filemon_time_secs  == "" )
			filemon_time_secs= default_time
        if ( filemon_Ooptions  == "" )
                        filemon_Ooptions= "detailed,all"
	if ( filemon_kbufsize  == "" )
			filemon_kbufsize= 5242880
	if ( fmon_rmtrcfiles  == "" )
			fmon_rmtrcfiles= ""


	#"$PERFPMRDIR/lsc -c" | getline ncpus
	#close("$PERFPMRDIR/lsc -c");
	space= filemon_kbufsize * ncpus

	printf("%d perfpmr_filemon  -T %s -O %s %s %s\n", space, filemon_kbufsize, filemon_Ooptions,fmon_rmtrcfiles,filemon_time_secs);
} ' default_time=$default_time_filemon $PERFPMRCFG
}  


#-----------------------------
# Name: perfpmr_netpmon
#-----------------------------
perfpmr_netpmon()
{
if [ "$1" != "getargs" ]; then
	if [ "$traceexists" = "true" ]; then
		echo "WARNING: no netpmon data will be collected since trace process was detected"
		return
	fi
	if whence netpmon >/dev/null; then
	        echo "                        PERFPMR: Executing $PERFPMRDIR/netpmon.sh $@" | $TEEOUT
		$PERFPMRDIR/netpmon.sh $@ 2>&1| $TEEOUT
	fi
	return
fi

shift
$BIN/awk  '
BEGIN {
}
/^netpmon.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "netpmon_time_seconds" && temp[3] != "")
			netpmon_time_secs = temp[3]
		if (temp[1] == "space_required" )
			space= temp[3]
	}
   }
END {
	if ( space == "" )
		space= 1000000
	if ( netpmon_time_secs == "" )
		netpmon_time_secs= default_time
	printf("%d perfpmr_netpmon %s\n", space, netpmon_time_secs);
} ' default_time=$default_time_netpmon $PERFPMRCFG
}  


#-----------------------------
# Name: perfpmr_tprof
#-----------------------------
perfpmr_tprof()
{
if [ -n "$PERFPMR_NO_WPAR" ]; then
        WPAR=0
else
	WPAR=`$SBIN/lswpar -q | $BIN/wc -l | $BIN/awk '{print $1}'`
fi
if [ $WPAR -gt 0 ]
then
        TPROF_WFLAG=1
else
        TPROF_WFLAG=0
fi
if [ "$1" != "getargs" ]; then
	if [ "$traceexists" = "true" ]; then
		echo "WARNING: no tprof data will be collected since trace process was detected"
		return
	fi
	if whence tprof >/dev/null; then
	        echo "                        PERFPMR: Executing $PERFPMRDIR/tprof.sh $@" | $TEEOUT
		$PERFPMRDIR/tprof.sh $@ 2>&1| $TEEOUT
	fi
	return
fi

shift
$BIN/awk '
BEGIN {
}
/^tprof.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "tprof_time_seconds" && temp[3] != "")
				tprof_time_secs= temp[3]
		if (temp[1] == "space_required" )
			space= temp[3]
		if (temp[1] == "sampling_frequency" )
		{
			if ( temp[3] != "" )
				tprof_samp_freq= "-f" temp[3] 
			else
				tprof_samp_freq= ""
		}
		if (temp[1] == "use_E_flag" )
		{
			if (temp[3] == "true" )
                                tprof_E_flag= "-E"
			else
				tprof_E_flag= ""
		}
		if (temp[1] == "use_D_flag" )
		{
			if (temp[3] == "true" )
                                tprof_D_flag= "-D"
			else
				tprof_D_flag= ""
		}
		if (temp[1] == "search_path" )
		{
			if ( temp[3] != "")
				tprof_search_path= "-S" temp[3]
			else
				tprof_search_path= ""
		}

	}
   }
END {
	if ( space == "" )
		space= 1000000
	if ( tprof_time_secs == "" )
		tprof_time_secs= default_time
	if ( TPROF_EFLAG == 1 )
		tprof_E_flag= "-E"
	if ( TPROF_DFLAG == 1 )
		tprof_D_flag= "-D"
	if ( TPROF_WFLAG > 0)
		tprof_W_flag= "-W"
	printf("%d perfpmr_tprof %s %s %s %s %s %s\n", space, tprof_search_path, tprof_W_flag, tprof_E_flag, tprof_D_flag, tprof_samp_freq,tprof_time_secs);
} ' default_time=$default_time_tprof TPROF_EFLAG=$TPROF_EFLAG TPROF_WFLAG=$TPROF_WFLAG TPROF_DFLAG=$TPROF_DFLAG $PERFPMRCFG
}  


#-----------------------------
# Name: perfpmr_iptrace
#-----------------------------
perfpmr_iptrace()
{
if [ "$NO_IPTRACE_TCPDUMP" = 1 ]; then
	echo "option -T was specified so iptrace will not be run"
	return 1
fi
if [ $1 != "getargs" ]; then
	echo "                        PERFPMR: Executing $PERFPMRDIR/iptrace.sh $@" | $TEEOUT
	$PERFPMRDIR/iptrace.sh $@ 2>&1| $TEEOUT
	return
fi
shift
$BIN/awk  '
BEGIN {
pktsize=""
}
/^iptrace.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "iptrace_time_seconds" && temp[3] != "")
			iptrace_time_secs = temp[3]
		if (temp[1] == "space_required" )
			space= temp[3]
		if (temp[1] == "bring_vios_sea_up" )
		{
			if ( temp[3] == "true" )
				vios_sea_up="-S"
			else
				vios_sea_up=""
		}
		if (temp[1] == "packet_size" )
			pktsize="-L " temp[3]
	}
   }
END {
	if ( space == "" )
		space= 10000000

	if ( iptrace_time_secs == "" )
		iptrace_time_secs= default_time;

	space= space * iptrace_time_secs

	if ( IPTRACE_SFLAG == 1 )
		vios_sea_up="-S"

	printf("%d perfpmr_iptrace %s %s %s\n", space, pktsize, vios_sea_up, iptrace_time_secs);
} ' default_time=$default_time_iptrace IPTRACE_SFLAG=$VIOS_SEAS_UP $PERFPMRCFG
}


	
#-----------------------------
# Name: perfpmr_tcpdump
#-----------------------------
perfpmr_tcpdump()
{
if [ "$NO_IPTRACE_TCPDUMP" = 1 ]; then
        echo "option -T was specified so tcpdump will not be run"
        return 1
fi
if [ "$1" != "getargs" ]; then
	if [ "$traceexists" = "true" ]; then
   	echo "WARNING: no tcpdump data will be collected since trace process has been detected"
	return 1
	fi

	echo "                        PERFPMR: Executing $PERFPMRDIR/tcpdump.sh $@" | $TEEOUT
	$PERFPMRDIR/tcpdump.sh $@ 2>&1| $TEEOUT
	return
fi
shift
$BIN/awk  '
BEGIN {
}
/^tcpdump.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "tcpdump_time_seconds" && temp[3] != "")
			tcpdump_time_secs = temp[3]
		if (temp[1] == "space_required" )
			space= temp[3]
	}
   }
END {
	if ( space == "" )
		space= 1000000

	if ( tcpdump_time_secs == "" )
		tcpdump_time_secs= default_time;

	space= space * tcpdump_time_secs
        if ( IPTRACE_SFLAG == 1 )
                vios_sea_up="-S"
	printf("%d perfpmr_tcpdump %s %s\n", space, vios_sea_up, tcpdump_time_secs);
} ' default_time=$default_time_tcpdump IPTRACE_SFLAG=$VIOS_SEAS_UP $PERFPMRCFG
}
#-----------------------------
# Name: perfpmr_24x7count
#-----------------------------
perfpmr_24x7count()
{
if [ "$1" != "getargs" ]; then
    	if [  "$NO_TWENTYFOUR_SEVEN_COUNT" -eq 1 ]; then
		echo "                        PERFPMR: skipping 24x7count collection" | $TEEOUT
		return
    	fi
	echo "                        PERFPMR: Executing $PERFPMRDIR/24x7count.sh $@" | $TEEOUT
	$PERFPMRDIR/24x7count.sh  $@ 2>&1 | $TEEOUT
        return
fi

shift
$BIN/awk  '
BEGIN {
}
/^24x7count.sh/ {
        while (status=getline >0)
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "twentyfour_count_time_seconds" && temp[3] != "")
                        twentyfour_count_time_seconds = temp[3]
                if (temp[1] == "space_required" )
                        space= temp[3]
        }
   }
END {
        if ( space == "" )
                space= 1000000
        if ( twentyfour_count_time_seconds == "" )
                twentyfour_count_time_seconds= default_time
        printf("%d perfpmr_24x7count %s\n", space, twentyfour_count_time_seconds);
} ' default_time=$default_time_24x7count $PERFPMRCFG
}


#-----------------------------
# Name: perfpmr_monitor
#-----------------------------
perfpmr_monitor()
{
if [ "$1" != "getargs" ]; then
	echo "                        PERFPMR: Executing $PERFPMRDIR/monitor.sh $NO_KDB $MONFLAGS $@" | $TEEOUT
	$PERFPMRDIR/monitor.sh $NO_KDB $MONFLAGS $@ 2>&1| $TEEOUT
	return
fi

shift
$BIN/awk  '
BEGIN {
}
/^monitor.sh/ {
	while (status=getline >0) 
	{
		if ($0 == "")
			exit;
		split($0,temp)
		if (temp[1] == "run_netstat_nfsstat" )
		{
			if (temp[3] == "false" )
				run_netstatnfsstat= "-n"
		}
		if (temp[1] == "run_fcstats" )
		{
			if (temp[3] == "false" )
				run_fcstats= "-F"
		}
		if (temp[1] == "run_pprof" )
		{
			if (temp[3] == "false" )
				run_pprof= "-p"
		}
		if (temp[1] == "run_svmon" )
		{
			if (temp[3] == "false" )
				run_svmon= "-s"
		}
		if (temp[1] == "run_powerstat" )
		{
			if (temp[3] == "false" )
				run_powerstat= "-P"
		}
		if (temp[1] == "run_emstat" )
		{
			if (temp[3] == "false" )
				run_emstat= "-e"
		}
		if (temp[1] == "run_hpmstat" )
		{
			if (temp[3] == "true" )
				run_hpmstat= "-h"
		}
                if (temp[1] == "run_glvm" )
                {
                        if (temp[3] == "true" )
                                run_glvm= "-g"
                }
		if (temp[1] == "monitor_time_seconds" )
			monitor_time_secs= temp[3]

		if (temp[1] == "perfxtra_init" )
			perfxtra_init= temp[3]

		if (temp[1] == "perfxtra_count" )
			perfxtra_count= temp[3]

		if (temp[1] == "perfxtra_sleep" )
			perfxtra_sleep= temp[3]

                if (temp[1] == "do_not_run_kdb" )
                {
                        if (temp[3] = "true" )
                                nokdb= "-k "
                }

		if (temp[1] == "space_required" )
			space= temp[3]
	}
 }
END {
	if ( space == "" )
		space= 2000000;

	if ( monitor_time_secs == "" )
		monitor_time_secs= default_time

	printf("%d perfpmr_monitor  %s %s %s %s %s %s -I %d -N %d -S %d %s %s %s %s\n", space,
	 run_powerstat,run_netstatnfsstat,run_pprof,run_svmon,run_emstat,run_hpmstat,perfxtra_init, perfxtra_count, perfxtra_sleep, nokdb, run_fcstats, run_glvm, monitor_time_secs);
} ' default_time=${MONITOR_TIME:-$default_time_monitor}  nokdb="$NO_KDB" $PERFPMRCFG
}

#-----------------------------
# Name: perfpmr_uptime
#-----------------------------
perfpmr_uptime()
{
if [ $1 != "getargs" ]; then
	echo " Uptime information $1 collection:" >> $PERFPMROUT
	echo " \c" >> $PERFPMROUT
	$BIN/uptime >> $PERFPMROUT
	return
else
	if [ -z "$uptimeagain"  ]; then
		echo "80 perfpmr_uptime before"
	else
		echo "80 perfpmr_uptime after"
		uptimeagain=1
	fi
fi
}

#-----------------------------
# Name: perfpmr_w
#-----------------------------
perfpmr_w()
{
if [ "$1" != "getargs" ]; then
	echo "\n\t\tW Command output $1 monitoring session\n\n\n" >> w.int
	$BIN/w >> w.int
	return
else
	if [ -z "$wagain"  ]; then
		echo "800 perfpmr_w before"
		> w.int
	else
		echo "800 perfpmr_w after"
		wagain=1
	fi
fi
}

#-----------------------------
# Name: get_other_cmds
#-----------------------------
get_other_cmds()
{
oc_count=0
$BIN/awk  '
BEGIN {
}
/^perfpmr.sh/ {
        while (status=getline >0)
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "other_command_to_run" && temp[3] !="")
                {
                        sub("other_command_to_run = ", "", $0);
                        print $0
                }
        }
   }
END {
} ' $PERFPMRCFG | while read other_cmd; do
        other_cmds[$oc_count]="$other_cmd"
        let oc_count=oc_count+1
done
}


#-----------------------------
# Name: run_other_cmds
#-----------------------------
run_other_cmds()
{
	arg_other_cmd=$1
	if [ "$oc_count" -gt 0 ]; then
		j=0;
		while [ $j -lt $oc_count ];  do
			if [ "$arg_other_cmd" = "show" ]; then
				echo "\t ${other_cmds[$j]}"
			else
				echo "                        PERFPMR: Executing ${other_cmds[$j]}" | $TEEOUT
				eval  ${other_cmds[$j]}
			fi
			let j=j+1
		done
	fi
}


#-----------------------------
# Name: get_tools_to_run
#-----------------------------
get_tools_to_run()
{
sc_count=0
$BIN/awk  '
BEGIN {
}
/^perfpmr.sh/ {
        while (status=getline >0)
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "perfpmr_tool" && temp[3] != "")
                {
                        sub("perfpmr_tool = ", "", $0);
                        print $0
                }
        }
   }
END {
} ' $PERFPMRCFG 

}

#-----------------------------
# Name: check_for_authority
#-----------------------------
check_for_authority()
{
	# check for root id
	$BIN/id | grep root  > /dev/null 2>&1 ||
  	{
		$BIN/lsuser -a roles $LOGNAME | $BIN/grep -q CdatClient ||
    		{
			echo "\nperfpmr.sh: Please obtain root authority and rerun this shell script\n"
    			exit 1
		}
  	}
}


#-----------------------------
# Name: get_tools_and_space
#-----------------------------
get_tools_and_space()
{
	toolcount=0
	sumspace=0
	for tool in $@; do
		if [ "$tool" = "config.sh" -a "$NO_CONFIG" != 1 ]; then
			DO_TRACE_MISCFILES_INCONFIG=1
			export DO_TRACE_MISCFILES_INCONFIG
		fi
		ptool=${tool%%.sh}; ptool=perfpmr_${ptool}
		if whence $ptool >/dev/null 2>&1; then
			cmd_to_run=`$ptool getargs $PERFPMRCFG`
			if [ $? = 0 ]; then
			  #echo "cmd_to_run=<$cmd_to_run>"
			  set $cmd_to_run
			  size[$toolcount]=$1; shift
			  cmd[$toolcount]=$@
			  shift;scmd[$toolcount]="$tool $@"
			  #echo "size=${size[$toolcount]} \c"
			  #echo $PERFPMRDIR/${cmd[$toolcount]}
				no_tool=0
			else
				no_tool=1
			fi
		else
			no_tool=0
			cmd[$toolcount]=$tool
			scmd[$toolcount]=$tool
			size[$toolcount]=500000
		fi
		if [ "$no_tool" = 0 ]; then
		  let sumspace=sumspace+${size[$toolcount]}
		  let toolcount=toolcount+1
		fi
	done

	# determine if there is sufficient disk space in the current directory
	freespace=`$BIN/df -k .|$BIN/tail -1|$BIN/awk '{print $3}'`
	let freespace=freespace/1024  # Mbytes free
	let sumspace=sumspace/1048576 # Mbytes needed
	if [ -n "$PREVIEWONLY" ]; then
	    echo "PERFPMR: perfpmr.sh Version $PERFPMRVER"
            echo "PERFPMR: tools located in: $PERFPMRDIR"
	    echo "PERFPMR: tools to be run include:"
	    tc=0
	    while (( $tc < $toolcount )); do
		echo "\t ${scmd[$tc]}"
		let tc=tc+1
	    done
	    # get other cmds	  
	    run_other_cmds show
	
	    echo "PERFPMR: disk space needed is at least :  <$sumspace> Mbytes"
	    echo "PERFPMR: free space in this directory  :  <$freespace> Mbytes"
	    exit 0
	fi

	if [ "$freespace" -lt "$sumspace" ]; then
           echo "\nperfpmr.sh: There may not be enough space in this filesystem"
           echo "perfpmr.sh: Make sure there is at least $sumspace Mbytes"
	   if [ "$override" -eq 0 ]; then
           	exit 1
	   else
		echo "Override was set. Continuing on although there is not enough space."
	   fi
	fi
}

#-----------------------------
# Name: check_lpp_reqs
#-----------------------------
check_lpp_reqs()
{
  EXIT_YORN=0
  LPPOUT=lslpp.l.out
  $BIN/lslpp -l > $LPPOUT
  bosfilesets="bos.acct bos.sysmgt.trace bos.perf.tools bos.perf.tune"
  bosnetfilesets="bos.net.tcp.server"

  for fileset in $bosfilesets $bosnetfilesets; do
        $BIN/grep $fileset $LPPOUT >/dev/null ||
                {
                EXIT_YORN=1
                echo "PERPFMR: fileset <$fileset> not installed"
                echo "PERPFMR: please install fileset <$fileset>"
                }
  done
#  vmstat_ok=0
#  for apar in IZ30898 IZ31517
#  do
#  	$SBIN/instfix -ik $apar > /dev/null 2>&1
#	if [ $? -eq 0 ]
#	then
#		vmstat_ok=1
#	fi
#  done
#  if [ $vmstat_ok -ne 0 ]
#  then
#	echo "PERFPMR: IZ30898 or IZ31517 is not installed. Unable to collect vmstat -h data"
#  fi
#
#  $SBIN/instfix -ik IZ22917 >/dev/null 2>&1
#  if [ $? -ne 0 ]
#  then
#	echo "PERFPMR: Please install APAR IZ22917:"
#	echo "                bos.pmapi.lib 6.1.2.0"
#	echo "                bos.pmapi.tools 6.1.2.0"
#	EXIT_YORN=1
#  fi
#
#  me_ok=0
#  for apar in IZ07857 IZ23965
#  do
#	$SBIN/instfix -ik $apar >/dev/null 2>&1
#	if [ $? -eq 0 ]
#	then
#		me_ok=1
#	fi
#  done
#  if [ $me_ok -eq 0 ]
#  then
#	echo "PERFPMR: Unable to collect lparstat -me"
#	echo "PERFPMR: Please install APAR IZ07857 or IZ23965"
#  fi
  $BIN/rm $LPPOUT
  # exit if missing any of the above LPPs
  if [ $EXIT_YORN = 1 ]; then
    exit 1
  fi
}

#-----------------------------
# Name: begin_perfpmr
#-----------------------------
begin_perfpmr()
{
> $PERFPMROUT
> w.int
do_timestamp "perfpmr.sh begin" | $TEEOUT
echo "    PERFPMR: hostname: `$BIN/hostname -s`" | $TEEOUT
systemid=`$SBIN/lsattr -El sys0 -a systemid -F value`
echo "    PERFPMR: systemid: $systemid" | $TEEOUT
echo "    PERFPMR: perfpmr.sh Version $PERFPMRVER  oslevel: $OSLEVEL" | $TEEOUT
echo "    PERFPMR: current directory: $PWD" | $TEEOUT            
echo "    PERFPMR: perfpmr tool directory: $PERFPMRDIR" | $TEEOUT
if [ "$PERFPMRDIR" = "$PWD" -o "PWD" = "$PERFPMRDIR/." ]; then
	echo "WARNING:   PERFPMR: You should ideally run perfpmr in directory other than where the perfpmr tools are located"
	#exit 1
fi
echo "    PERFPMR: Parameters passed to perfpmr.sh: $PERFPMRPARMS" | $TEEOUT
echo "    PERFPMR: Data collection started in foreground (renice -n -20)" | $TEEOUT
echo "    PERFPMR: Current timezone: $TZ" | $TEEOUT

# save a little info from just before session begins
echo "\n     Date and time before data collection is \c" >> $PERFPMROUT

$BIN/date >> $PERFPMROUT
perfpmr_uptime before
perfpmr_w before
}


#-----------------------------
# Name: end_perfpmr
#-----------------------------
end_perfpmr()
{
	# collect perfpmr ending status
	echo "\n     Date and time after data collection is \c" >> $PERFPMROUT
	$BIN/date >> $PERFPMROUT
	perfpmr_uptime after
	# also save 'w' command output (uptime info + user info)
	perfpmr_w after
	echo "\n    PERFPMR: Data collection complete.\n" | $TEEOUT
}


#-----------------------------
# Name: run_tools
#-----------------------------
run_tools()
{
	tc=0
	while (( $tc < $toolcount )); do
	#		echo "PERFPMR: executing < ${cmd[$tc]} >"
		do_timestamp "PERFPMR: executing ${cmd[$tc]} stanza" | $TEEOUT
		${cmd[$tc]}
		let tc=tc+1
	done
}

#-----------------------------
# Name: check_for_trace
#-----------------------------
check_for_trace()
{
	if $BIN/ps -ea | $BIN/grep -q -w 'trace'; then
                tpid=`$BIN/ps -ea | $BIN/grep -w 'trace' | $BIN/awk '{print $1}'`
                $BIN/ps -fp $tpid | $BIN/tee trace.err
                echo "ABOVE TRACE COMMAND IS CURRENTLY RUNNING. IF THIS IS UNINTENTIONAL"
                echo "THEN CTRL/C OUT OF THIS SCRIPT NOW ELSE TRACE.SH WILL STOP THIS TRACE"
                echo "sleeping for 10 seconds to allow ctrl/c from script"
                $BIN/sleep 10
   		#traceexists=true
	fi
}

#-----------------------------
# Name: disp_copyright
#-----------------------------
disp_copyright()
{
	echo " " 1>&2
	echo "(C) COPYRIGHT International Business Machines Corp., 2000,2001,2002,2003,2004-2011" 1>&2
	echo " " 1>&2
	$BIN/sleep 1
}

#-----------------------------
# Name: check_for_space
#-----------------------------
check_for_space_old_way()
{
	# determine if there is sufficient disk space in the current directory
	#ncpus=`$PERFPMRDIR/lsc -c`
	ncpus=$NCPUS
	let trace_space=ncpus*10  # 10MB * number of cpus
	iptrace_space=30                # 10MB for iptrace (rough estimate)
	gennames_space=30               # 30MB for gennames output
	extraspace=10                       # for other stuff
	let totspace=trace_space+iptrace_space+gennames_space+extraspace
	freespace=`$BIN/df -k .|$BIN/tail -1|$BIN/awk '{print $3}'`
	let freespace=freespace/1024  # Mbytes free

	if [ -n "$PREVIEWONLY" ]; then
	     echo "PERFPMR: perfpmr.sh Version $PERFPMRVER"
             echo "PERFPMR: tools located in: $PERFPMRDIR"
	     echo "PERFPMR: tools to be run include:"
		echo "\t trace.sh $default_time_trace"
		echo "\t trace_419.sh $default_time_trace_419"
		echo "\t 24x7count.sh $default_time_24x7count"
		echo "\t monitor.sh $MONITOR_TIME"
		echo "\t iptrace.sh $default_time_iptrace"
		echo "\t tcpdump.sh $default_time_tcpdump"
		echo "\t filemon.sh $default_time_filemon"
		echo "\t tprof.sh $default_time_tprof"
#		echo "\t netpmon.sh $default_time_netpmon"
		echo "\t config.sh"
	    echo "PERFPMR: disk space needed is at least :  <$totspace> Mbytes"
	    echo "PERFPMR: free space in this directory  :  <$freespace> Mbytes"
	    exit 0
	fi

	if [ "$freespace" -lt "$totspace" ]; then
        echo "\nperfpmr.sh: There may not be enough space in this filesystem"
        echo "perfpmr.sh: Make sure there is at least $total_space Mbytes"
        exit 1
	fi
}



#-----------------------------
# Name: do_old_way
#-----------------------------
do_old_way()
{
	echo "PERFPMR: running without perfpmr.cfg file"
	check_for_space_old_way
	begin_perfpmr
	perfpmr_trace $default_time_trace
	perfpmr_trace_419 $default_time_trace_419
	perfpmr_24x7count $default_time_24x7count

	if [ "$traceexists" = "true" ]; then
		perfpmr_monitor -p $MONFLAGS $MONITOR_TIME
	else
		perfpmr_monitor $MONFLAGS $MONITOR_TIME
	fi
	perfpmr_iptrace $default_time_iptrace
	perfpmr_tcpdump $default_time_tcpdump
	perfpmr_filemon $default_time_filemon
	perfpmr_tprof $default_time_tprof
#	perfpmr_netpmon $default_time_netpmon
	perfpmr_config
	end_perfpmr
}

check_segment_count()
{
	if [  "$override" -eq 1 ]; then
		return
	fi
	if [ "$NO_KDB" = "-k" ]; then
		echo "Will not check segment count since NO_KDB was set"
		return
	fi
	svmon_seg_limit=`$BIN/awk  '
	BEGIN {
	}
	/^config.sh/ {
		while (status=getline >0)
		{
			if ($0 == "")
				exit;
			split($0,temp)
			if (temp[1] == "svmon_seg_limit" )
			{
				if (temp[3] != "" )
				{
					svmon_seg_limit= temp[3]
					printf("%d\n", svmon_seg_limit);
				}
			}
        	}
 	}
	END {
	} '   $PERFPMRCFG`
	export PERFPMR_SEGMENT_LIMIT=$svmon_seg_limit

	if [ "$svmon_seg_limit" != "" ]; then
		cur_seg_count=`echo "pfhdata -scbl" | $SBIN/kdb | $BIN/awk '
		/SCB LISTS data for 256MB SCB/ {
        		found=1;
		}
		/^pfs_usedcnt/ {
        		if ( found == 1)
        		{
				counthex=$2;
				count=sprintf("%d", "0x" counthex);
				printf("%d", count);
				exit(0);
        		}
		}'`
		export PERFPMR_SEGMENT_COUNT=$cur_seg_count
	fi
}

validate_int()
{
	num=$1
	if [ -n "$num" -a "${num##*([0-9])}" = "" ]; then
		return 0
	else
		return 1
	fi
}

validate_memory()
{
trcbufsize=$(/bin/awk '/^trace.sh/ { found=1;} /kbufsize/ { if (found==1) { size=$NF;exit;}} END {printf("%d\n", size);}' $PERFPMRCFG)
#lcpu=$($PERFPMRDIR/lsc -c)
lcpu=$NCPUS
let memrequired=lcpu*trcbufsize
curcomputationalpct=$(/usr/bin/vmstat -v|/bin/awk '{print $1}')
freepages=$(/bin/vmstat -v|/bin/awk '/ free pages/ {print $1}')
filepages=$(/bin/vmstat -v|/bin/awk '/ file pages/ {print $1}')
let noncomppages=freepages+filepages
let noncompbytes=noncomppages*4096
additionalmem=100000000  # extra 100MB just in case
let totalmemneeded=additionalmem+memrequired
let neededMB=totalmemneeded/1024/1024; let availMB=noncompbytes/1024/1024
echo "PERFPMR: Memory required: $totalmemneeded bytes ($neededMB MB)   noncomputational_mem_available=$noncompbytes bytes ($availMB) MB"
#echo "memory required: $neededMB MB    noncomputational_mem_available: $availMB MB"
if [ "$totalmemneeded" -gt "$noncompbytes" ]; then
	if [ -f $PERFPMRDIR/perfpmr.memcheck ]; then
		if [ $PERFPMRDIR/perfpmr.memcheck -ot  /etc/.init.state ]; then  # system was rebooted
        		echo "PERFPMR: Not enough memory available to run perfpmr. Use -O flag to override."
        		return 1
		else
			echo "PERFPMR: Memory low but can re-use previous trace memory. Continuing ..."
			echo "`/bin/date` : need=$neededMB MB  avail=$availMB MB : Sufficient memory" > $PERFPMRDIR/perfpmr.memcheck
			return 0
		fi
	else
		echo "PERFPMR: Not enough memory available to run perfpmr. Use -O flag to override."
		return 1
	fi
else
	echo "`/bin/date` : need=$neededMB MB  avail=$availMB MB : Sufficient memory" > $PERFPMRDIR/perfpmr.memcheck
	return 0
fi
}

#-----------------------------
# Name: validate_monitor_time
#-----------------------------
validate_monitor_time()
{
    validate_int "$MONITOR_TIME"  || 
    {
	echo "<$MONITOR_TIME>: Must specify integer value for perfpmr time"
	exit 1
    }
# check total time specified for minimum amount of 60 seconds
if [ "$MONITOR_TIME" -lt 60 ]; then
 echo "    PERFPMR: Minimum time interval required is 60 seconds"
 exit 1
fi
}

#-----------------------------
# Name: run_sanity_check
#-----------------------------
run_sanity_check()
{
    $BIN/grep "config.sh data collection completed" config.sum >/dev/null || 
      {
	echo "    PERFPMR: Warning: config.sum file is not complete"
      } | $TEEOUT
    if [ ! -s trace.raw ]; then
	echo "    PERFPMR: Warning: trace.raw file missing or 0 bytes; trace may not have been run"
    fi
#premonpid=`$BIN/ps -ef|$BIN/grep perfpmr_premonitor.sh | $BIN/grep -v grep | $BIN/awk '{print $2}'`
premonpid=`$BIN/ps -ef|$BIN/grep perfpmr_premonitor.sh | $BIN/grep -v grep`
if [ "$premonpid" != "" ]; then
	echo "Stopping perfpmr_premonitor.sh"
	$BIN/ps -ef|$BIN/grep perfpmr_premonitor.sh | $BIN/grep -v grep | $BIN/awk '{print $2}' | while read premonpid; do
        	$BIN/ps -fp $premonpid | grep perfpmr_premonitor.sh && kill -30 $premonpid
	done
fi
}

		
#-----------------------------
# Name: get_monitor_time
#-----------------------------
get_monitor_time()
{
$BIN/awk  '
BEGIN {
}
/^perfpmr.sh/ {
        while (status=getline >0)
        {
                if ($0 == "")
                        exit;
                split($0,temp)
                if (temp[1] == "perfpmr_time_seconds" && temp[3] !="")
                        perfpmr_time_seconds= temp[3]
        }
   }
END {
        printf("%s\n", perfpmr_time_seconds);
} ' $PERFPMRCFG

}

post_process_perfpmr()
{
	timezone=`/usr/bin/awk '/timezone:/ { print $NF}' perfpmr.int`
	export TZ=$timezone
	$PERFPMRDIR/trace.sh -r
	$PERFPMRDIR/pprof.sh -r
	$PERFPMRDIR/iptrace.sh -r
}

do_pax_gzip()
{
        if [ "$OUTDIRS" = "" ]; then
                OUTDIRS=.
        fi
	set $OUTDIRS
	if [ $# = 1 ]; then
		# in case full path was specified, at least in the case where there's
		# just one directory to backup, we can back it up by relative path
		cd $OUTDIRS
		$BIN/find . ! -type d ! -name ${PAXGZFILE##*/} | $BIN/pax -xpax -vw | $BIN/gzip -c > $PAXGZFILE
	else
		# back it up as using the path specified in $OUTDIRS
		$BIN/find $OUTDIRS ! -type d ! -name ${PAXGZFILE##*/} | $BIN/pax -xpax -vw | $BIN/gzip -c > $PAXGZFILE
	fi
        #$BIN/pax -xpax -vw $OUTDIRS | $BIN/gzip -c > $PAXGZFILE
        echo "PERFPMR: Gzipped PAX file is in $PAXGZFILE"
}


#--------------------------------------------------------------
#                 MAIN 
#--------------------------------------------------------------

		
#$BIN/ps -ef|$BIN/grep perfpmr.sh |$BIN/grep -v "perfpmr.sh -x"|$BIN/grep -Ev "grep|$$" && {
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
export PERFPMRDIR
PERFPMROUT=perfpmr.int
TEEOUT="$BIN/tee -i -a $PERFPMROUT"
PERFPMRCFG=$PERFPMRDIR/perfpmr.cfg
PERFPMRPARMS="$*"
export traceexists=false
export LANG=C
export GETGENNAMES=1
export GETGENNAMESF=0
default_time_monitor=600
default_time_filemon=60
default_time_netpmon=60
default_time_tcpdump=10
default_time_iptrace=10
default_time_tprof=60
default_time_trace=5
default_time_comptrace=5
default_time_trace_419=60
default_time_hpmcount=5
default_time_pmucount=1
default_time_probevue=5
default_time_24x7count=3
unset PMUCOUNT_FLAG PROBEVUE_FLAG COMPONENT_STRING

AMS_SYSTEM=""
MONFLAGS=
CFGFLAGS=
NO_KDB=
NO_SNAPDATA=
override=0
preallocate_trcbuf=0  # call allocate_tracebuffers.sh if set to 1


while getopts eGNbTySOVi:kUuAXEHW:w:Zz:o:QIPDd:F:x:gcfnpsrC: flag 2>/dev/null; do
        case $flag in
	       e)     export no_vnode=1;export noinodetbl=1;;
	       G)     MONFLAGS="$MONFLAGS -F";;
	       N)     NO_SNAPDATA="-N";export NO_SNAPDATA;;
	       b)     export preallocate_tracebufs=1;;
	       C)     COMPONENT_STRING=$OPTARG;;
	       S)     VIOS_SEAS_UP=1;;
	       O)     override=1;;
               V)     disp_perfpmr_version=1;;
	       i)     PERFPMR_MONITOR_INTVLTIME=$OPTARG;export PERFPMR_MONITOR_INTVLTIME;;
               k)     NO_KDB="-k";export NO_KDB;;
               T)     NO_IPTRACE_TCPDUMP=1;;
	       U)     PMUCOUNT_FLAG=1;;
	       u)     PROBEVUE_FLAG=1;;
	       y)     NO_TWENTYFOUR_SEVEN_COUNT=1;;
	       A)     AMS_SYSTEM=1;;
	       E)     TPROF_EFLAG=1;;
	       X)     PERFXTRA_FLAG=1;;
               W)     WAITFORPROGRAM=$OPTARG;;
	       w)     WAITDELAY=$OPTARG;;
               o)     OUTDIRS=$OPTARG;;
               z)     pax_gzip=1;PAXGZFILE=$OPTARG;;
               Z)     run_and_pax_gzip=1;;
	       Q)     QUICK_CFG="-Q";;
	       P)     PREVIEWONLY=1;;
	       I)     INSTRUMENTEDTRACE="-I";;
	       D)     OLD_WAY=1;;
	       c)     NO_CONFIG=1;;
	       d)     DELAY=$OPTARG;;
               F)     PERFPMRCFG=$OPTARG;perfpmrcfgfile=1;;
               x)     exec_prog=$OPTARG;break;;
               g)     GETGENNAMES=0;;
               f)     GETGENNAMESF=1;;
               n)     MONFLAGS="$MONFLAGS -n";;
               p)     MONFLAGS="$MONFLAGS -p";;
               s)     nosvmon=1;MONFLAGS="$MONFLAGS -s";CFGFLAGS="$CFGFLAGS -m";;
               h)     MONFLAGS="$MONFLAGS -h";;
               H)     HPMCOUNT_HFLAG=1;;
	       r)     postprocess_perfpmr=1;;
                \?)    show_usage;;
        esac
done
shift OPTIND-1
if [ "$disp_perfpmr_version" = 1 ]; then
	echo "PERFPMR: perfpmr.sh Version $PERFPMRVER"
	exit 0
fi
export PERFPMRCFG 
if [ "$postprocess_perfpmr" = 1 ]; then
	post_process_perfpmr
	exit $?
fi

$BIN/ps -ef|$BIN/grep perfpmr.sh |$BIN/grep -Ev "perfpmr.sh -x|-x.*perfpmr.sh"|$BIN/grep -Ev "grep|$$" && {
	echo "There seems to be another perfpmr.sh already running"
	echo "Either wait for this to be completed or cleanup the processes and restart"
	echo "This command can be used to show the processes from perfpmr.sh:"
	echo 'proctree <pid of perfpmr.sh>' 
	exit 1
}
if [ -z "$NO_KDB" ]; then 
	echo status | /usr/sbin/kdb > kdb.err 2>&1 
	if [ $? != 0 ]; then  # kdb doesn't work
		NO_KDB="-k"
	fi
	export KDB_CHECKED=1
fi

ulimit -d unlimited
OSLEVEL=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -n 1|$BIN/awk '{print substr($2,1,3)}'`
if [ "$OSLEVEL" = "6.1" ]; then
	NCPUS=`$PERFPMRDIR/lsc61 -c`
else
	NCPUS=`$PERFPMRDIR/lsc -c`
fi

curtime=`$PERFPMRDIR/getdate`
let difftime=curtime-$PERFPMRTIME
if [ "$difftime" -gt "$TOO_OLD" -a "$override" -eq 0 ]; then
  echo "PERFPMR: Warning! This version of perfpmr is over 3 months old"|$TEEOUT
  echo "PERFPMR: You may want to check ftp site for possible newer version"|$TEEOUT
  echo "PERFPMR: sleeping for 5 seconds - will proceed with collection"
  echo "         if this command is not interrupted"
  $BIN/sleep 5
fi


if [ "$nosvmon" != 1 -a "$override" -eq 0 ]; then
	numpids=`$BIN/ps -ek | $BIN/wc -l`
	if [ "$numpids" -gt 5000 ]; then
		echo "PERFPMR.SH:  There are a large number ($numpids) of process ids on this system"
		echo "PERFPMR.SH: svmon commands may take a long time to complete."
		echo "PERFPMR.SH: sleeping 5 seconds to allow breaking out now and restarting perfpmr.sh with -s option if desired"
		echo "PERFPMR.SH: -s option will omit svmon collection"
		$BIN/sleep 5
	fi
fi

# Check for enough RAM 
if [ -z "$exec_prog" -o "$exec_prog" = "trace.sh" ]; then
  validate_memory || { if [ "$override" = 0 ]; then exit 1; fi }
fi

# Check to see how many mem segments exist to determine if to run all svmon options
check_segment_count

if [ "$AMS_SYSTEM" = 1 ]; then
	HPMCOUNT_HFLAG=1
	TPROF_EFLAG=1
	TPROF_DFLAG=1
fi
if [ -n "$pax_gzip" -a -z "$run_and_pax_gzip" ]; then
        do_pax_gzip
        exit $?
fi

validate_fs     # valid if filesystem being written to is not cio/dio or remote


#WPAR=`$SBIN/lswpar -q | $BIN/wc -l | $BIN/awk '{print $1}'`
#if [ $WPAR -gt 0 ]
#then
#	TPROF_WFLAG=1
#else
#	TPROF_WFLAG=0
#fi

if [ -n "$perfpmrcfgfile" ]; then
	if [ ! -f $PERFPMRCFG ]; then
		echo "PERFPMR: unable to read <$PERFPMRCFG>"
		exit 1
	fi
fi

if [ -n "$exec_prog" ]; then
	if [ -n "$WAITFORPROGRAM" ]; then
		wait_for_program
	fi
	if [ -n "$PREVIEWONLY" ]; then
                echo "PERFPMR: perfpmr.sh Version $PERFPMRVER" 
                echo "PERFPMR: tools located in: $PERFPMRDIR"
	    	echo "PERFPMR: command to execute is: $exec_prog $@"
		echo "PERFPMR: data collection directory is: $PWD"
		if [ "$PERFPMRDIR" = "$PWD" ]; then
			echo "   PERFPMR: must run perfpmr in directory other than where the perfpmr tools are located"
			exit 1
		fi
	else
                echo "    PERFPMR: perfpmr.sh Version $PERFPMRVER" | $TEEOUT
                echo "    PERFPMR: current directory: $PWD" | $TEEOUT
                echo "    PERFPMR: perfpmr tool directory: $PERFPMRDIR" | $TEEOUT
		if [ "$PERFPMRDIR" = "$PWD" ]; then
			echo "   PERFPMR: must run perfpmr in directory other than where the perfpmr tools are located"
			exit 1
		fi
                echo "    PERFPMR: Parameters passed to perfpmr.sh: $PERFPMRPARMS" | $TEEOUT
                echo "\n     Date and time before data collection is `$BIN/date`" >> $PERFPMROUT
                exec $PERFPMRDIR/$exec_prog $@ 2>&1| $TEEOUT
                echo "\n     Date and time after data collection is `$BIN/date`" >> $PERFPMROUT
		$BIN/cp $PERFPMRCFG  .   2>/dev/null
		#if [ ! -f reorg.sh ]; then
			$BIN/cp $PERFPMRDIR/reorg.sh  .   2>/dev/null
		#fi
	fi
	exit $?
fi



MONITOR_TIME=$1

if [ -z "$OLD_WAY" -a -f $PERFPMRCFG ]; then
	if [ "$MONITOR_TIME" = "" ]; then
		MONITOR_TIME=`get_monitor_time`
	fi
	perf_tools_to_run=`get_tools_to_run $PERFPMRCFG`
	get_other_cmds
	get_tools_and_space $perf_tools_to_run
	
else
	if [ "$MONITOR_TIME" = "" ]; then
		MONITOR_TIME=$default_time_monitor
	fi
	check_for_space_old_way
fi

validate_monitor_time $MONITOR_TIME
check_for_authority
check_lpp_reqs
check_for_trace

disp_copyright

# change shell nice value
$BIN/renice -n -20 -p $$

if [ -n "$WAITFORPROGRAM" ]; then
	wait_for_program
fi
# if delay time specified, sleep for delay time
validate_int "$DELAY" &&  $BIN/sleep $DELAY


if [ -n "$OLD_WAY" -o ! -f $PERFPMRCFG ]; then
	do_old_way
else
	begin_perfpmr
	ps -Nef > psef.begin
	run_tools
	run_other_cmds exec
	ps -Nef > psef.end
	end_perfpmr
	$BIN/cp $PERFPMRCFG  .   2>/dev/null
	#if [ ! -f reorg.sh ]; then
		$BIN/cp $PERFPMRDIR/reorg.sh  .   2>/dev/null
	#fi
fi

run_sanity_check

if [ -n "$run_and_pax_gzip"  ]; then
        do_timestamp "archiving/compressing data files"
        do_pax_gzip
else
        echo ""
        echo "PERFPMR: Data files can be archived and gzipped using:"
        echo "   perfpmr.sh -z filename [-o \"dirs\"] "
        echo "      filename  is the name of the archive file. "
        echo "         An example of a typical archive filename:"
        echo "            /tmp/salesforceticket#.perfpmr.pax.gz"
        echo "         Or /tmp/salesforceticket#.host.perfpmr.pax.gz"
        echo "      \"dirs\"      dirs is a list of directories or perfdata directory name enclosed in quotes."
        echo "       When  -o is specified, you must be in the parent directory of the data director[y\ies] specified"
	echo "          ex. perfpmr.sh -z /tmp/TS0000000.perfpmr.pax.gz -o perfdata"
	echo "       If -o not specified, all files in current directory are archived."
	echo "       For ftp upload instructions, visit:"
	#echo "       https://www-05.ibm.com/de/support/ecurep/send_ftp.html"
	echo "       https://www.ibm.com/support/pages/enhanced-customer-data-repository-ecurep-send-data-ftp"
	echo "       NOTE: Blue Diamond clients should upload to the BD servers instead."
fi

if [ -f core ]; then
	echo "IMPORTANT: there is a core file in this directory. Please exclude this from"
	echo "           the list of perfpmr data files that will be uploaded"
	/bin/ls -l core
fi

let elasec=$SECONDS-$cursec
do_timestamp "perfpmr.sh completed  :  execution_time: $elasec seconds" | $TEEOUT
