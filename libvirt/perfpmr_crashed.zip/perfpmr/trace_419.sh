#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp. 2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# trace_419.sh
#
#   Used to collect trace data with just 419 preempt hook 
#

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
LOGBUF=10000000
KERNBUF=5000000
CPUS="-C all"
unset no_pvpa
SLEEP=${1:-60}

do_pvpa_before()
{
	$PERFPMRDIR/pvpa > pvpa.before
	$PERFPMRDIR/pvpa 7 6 > pvpa.enable
}
do_pvpa_after()
{
	$PERFPMRDIR/pvpa 6 7 > pvpa.disable
	$PERFPMRDIR/pvpa > pvpa.after
}

do_trace()
{
	do_timestamp "trace_419.sh"
	echo "$BIN/trace $CPUS $includehooks $excludehooks $INGRPHOOKS $EXGRPHOOKS -L $LOGBUF -T $KERNBUF -ano trc_419.raw"
	$BIN/trace $CPUS $includehooks $excludehooks $INGRPHOOKS $EXGRPHOOKS -L $LOGBUF -T $KERNBUF -ano trc_419.raw
	$BIN/sleep $SLEEP
	$BIN/trcstop
	do_timestamp "trace_419 has been stopped"
}
do_timestamp()
{
        echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
}

includehooks="-j 419"
while getopts :Cn:L:T:j:k:J:K: flag ; do
        case $flag in
                J)     INGRPHOOKS="-J $OPTARG";;
                K)     EXGRPHOOKS="-K $OPTARG";;
                j)     includehooks="${includehooks},$OPTARG";;
                k)     excludehooks="-k $OPTARG";;
                n)     ntraces=$OPTARG;;
                C)     CPUS="";;
                L)     LOGBUF=$OPTARG;;
                T)     KERNBUF=$OPTARG;;
                \?)    show_usage
        esac
done
shift OPTIND-1
SLEEP=$@




OSLEVEL=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -n 1|$BIN/awk '{print substr($2,1,3)}'`
typeset -i TL
TL=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -n 1|$BIN/awk '{print $2}'|$BIN/awk -F "." '{print $3}'`

if [ "$OSLEVEL" = "6.1" ]; then
	LSCTOOL=lsc61
else
	LSCTOOL=lsc
fi
IMP=`$PERFPMRDIR/$LSCTOOL -m|$BIN/grep ^implementation|$BIN/awk '{print $2}'`
#MODE=`$PERFPMRDIR/$LSCTOOL -m|$BIN/grep ^version|$BIN/awk '{print $2}'`

case $IMP in
        "Power7") no_pvpa=0;;
        "Power6") no_pvpa=1;;
        "Power5") no_pvpa=1;;
        *) no_pvpa=1;;
esac
case $OSLEVEL in
        "5.3") no_pvpa=1;;
esac

if [ "$no_pvpa" = 0 ]; then
	do_pvpa_before
fi

do_trace

if [ "$no_pvpa" = 0 ]; then
	do_pvpa_after
fi
