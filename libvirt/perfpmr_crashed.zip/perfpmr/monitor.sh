#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp. 2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# monitor.sh
#
# invoke system performance monitors and collect interval and summary reports
#

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
AIXVER=`uname -v`
HOSTNAME=`$BIN/hostname -s`

show_usage()
{
 	echo  "monitor.sh: usage: monitor.sh [-f][-k][-e][-n] [-p] [-s] [-h][-I sec][-N count][-S sec][-i][-t][-F][-v][-T] [-g] time"
 	echo  "      -k used if no kdb monitor desired."
 	echo  "      -e used if no emstat or alstat desired."
 	echo  "      -n used if no netstat or nfsstat desired."
 	echo  "      -p used if no pprof desired."
 	echo  "      -s used if no svmon desired."
 	echo  "      -m used if no mpstat desired."
 	echo  "      -l used if no lparstat desired."
 	echo  "      -t used if no tstat desired."
 	echo  "      -h used if hpmstat desired."
 	echo  "      -i used if no iomon desired."
 	echo  "      -F used if no fcstat/fcstat2 output desired."
 	echo  "      -P used if no powerstat desired."
 	echo  "      -v used if no ventstat desired."
 	echo  "      -T used if no tcpstat desired."
	echo  "      -g used if glvm stats collection is desired."
 	echo  "      -I <seconds> specifies initial sleep delay before perfxtra monitoring starts"
 	echo  "      -N <count> specifies number of times to run perfxtra monitoring prgrams"
 	echo  "      -S <seconds> specifies number of seconds in between each iteration of perfxtra programs"
 	echo  "      time is total time in seconds to be measured."
 	exit 1
}

do_timestamp()
{
        echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
}

function lsps_as
{
	echo "Date/Time:  " `$BIN/date`
	echo "\n"
	echo "$SBIN/lsps -a"
	echo "-------"
	$SBIN/lsps -a

	echo "\n\n"
	echo "$SBIN/lsps -s"
	echo "-------"
	$SBIN/lsps -s
}


function vmstat_i
{
	echo "Date/Time:  " `$BIN/date`
	echo "\n"
	echo "vmstat -i"
	echo "---------"
	$BIN/vmstat -i
}

function vmstat_v
{
	echo "Date/Time:  " `$BIN/date`
	echo "\n"
	echo "vmstat -v"
	echo "---------"
	AMS=0; $BIN/lparstat -i|$BIN/grep "Memory Mode"|$BIN/grep -i Shar >/dev/null && AMS=1
	if [ "$AIXVER" = "6" ]; then
		for apar in IZ30898 IZ31517
		do
			$SBIN/instfix -ik $apar >/dev/null 2>&1
			if [ $? -ne 0 ]; then
				AMS=0
			fi
		done
	fi
	if [ $AMS -eq 1 ]; then
	  $BIN/vmstat -hv  2>&1
	else
	  $BIN/vmstat -v 2>&1
	fi
}

do_adapter_procfiles()
{
	when=$1
	echo "$when time for adapter /proc stats: `$BIN/date`"
	if [ -d /proc/sys/adapter ]; then 
          	find /proc/sys/adapter |while read file; do
            		if [ ! -d $file ]; then
              			echo "------ BEGIN  $file ------------";
              			/bin/cat $file
              			echo "------ END  $file ------------\n";
			fi
          	done
	fi
}

do_fcstat2_wwpn()
{
	#if [ -f /usr/sbin/fcstat ]; then
		#$PERFPMRDIR/fcstat_vios.sh
	#fi
	$PERFPMRDIR/fcstat2 -n
}

do_fcstat2_totals()
{
	$PERFPMRDIR/fcstat2 -AaQ
}
do_fcstat2_npiv_totals()
{
	$PERFPMRDIR/fcstat2 -NAaQ
}
do_fcstat_npiv_totals()
{
	/usr/ios/cli/ioscli fcstat -client
}

do_fcstat()
{
	if [ -f /usr/sbin/fcstat ]; then
        	echo "\n\n------------ FCSTAT  `$BIN/date`  ----------\n" 
		$PERFPMRDIR/fcstat2 -l | while read f; do
        	   #for f in `$SBIN/lsdev -Ccadapter|$BIN/grep "^fcs"|$BIN/awk '{print $1}'`; do
        	   echo "\n------------------------------------------------" 
		   $SBIN/fcstat -D $f 
        	done
	fi
}
do_getfc()
{
	do_timestamp "dofc: $when on each fc adapter"
	$PERFPMRDIR/getfc.sh -A -E
}

do_pile_out()
{
        if [ -n "$NO_KDB"  ]; then
		echo "Will not execute kdb pile command since NO_KDB was specified"
                return
        fi
	echo "pile\npgbuf -c\ni2 -c" | $SBIN/kdb
	echo "JFS2 memory usage"
	cat /proc/sys/fs/jfs2/memory_usage
}

do_kdb_vmmstats()
{
    	if [ -n "$NO_KDB"  ]; then
		echo "$0: do_kdb_vmmstats function will not be run since NO_KDB was set"
	    	return
    	fi
    	echo "dd wlm_hw_pages\n\nvmker -psize\nvmstat\nvmstat -p 0\nvmstat -p 1\nfrs *\npst *\npst 0\npst 1\npfhdata\npfhdata -lrumpss\npfhdata -tune\npfhdata -lsa\npfhdata -psm\nvmker\nvmker -psize\n\nppda *\n\ndw hcall_stats_flag\n\ndw pmap_stat 20" | $SBIN/kdb

    	$PERFPMRDIR/getmempool.sh
    	$PERFPMRDIR/getvmpool.sh
}

do_ame()
{
	filesuffix=$1
	echo "vmstat" | /usr/sbin/kdb  > amevms.$filesuffix
	echo "cmem" | /usr/sbin/kdb > amecmem.$filesuffix
	num_cmem_pools=`cat amecmem.$filesuffix | grep "on-line pools" | awk '{ printf "%d\n", "0x" $5 }' `
	CNT=0;
	while [ $CNT -le $num_cmem_pools ]; do
  		echo "cmem -p $CNT" | /usr/sbin/kdb >> amecmem.$filesuffix
  		CNT=$((CNT + 1))
	done
}

do_fc()
{
	# pick up fcstat output at end of interval
	when=$1
	do_timestamp "fcstat $when on each fc adapter"
	do_fcstat > fcstat.$when
	do_fcstat2_totals > fcstat2.totals.$when
	if [ -d /usr/ios ]; then
		#echo "fcstat WWPN output from VIOS: `$BIN/date`\n" > fcstat_wwpn.$when
		#do_fcstat_wwpn >> fcstat_wwpn.$when
		echo "fcstat WWPN output from VIOS: `$BIN/date`\n" > fcstat2_wwpn.$when
		do_fcstat2_wwpn >> fcstat2_wwpn.$when
		echo "fcstat NPIV totals from VIOS: `$BIN/date`\n" > fcstat2_npiv_totals.$when
		do_fcstat2_npiv_totals >> fcstat2_npiv_totals.$when
		echo "fcstat NPIV totals from VIOS: `$BIN/date`\n" > fcstat_cli_npiv_totals.$when
		do_fcstat_npiv_totals >> fcstat_cli_npiv_totals.$when
	fi
	do_getfc > fc.$when
	do_timestamp "fcstats completed"
}

do_eid()
{
	# get EID stats
	when=$1
	echo "$when time EID stats: `$BIN/date`"
	$PERFPMRDIR/eidmon
}

do_lsmpio()
{
	when=$1
        do_timestamp "lsmpio $when "
	{
	echo "\nlsmpio adapter $when report at `$BIN/date`"
	$BIN/lsmpio -a -r
	echo "lsmpio -f for aix 7.3"
	$BIN/lsmpio -a -r -f
	echo "\nlsmpio disk $when statistics report at `$BIN/date`"
	$BIN/lsmpio -S -d
	echo "-------------------------------------"
	} > lsmpio.$when 2>&1
}

do_ipsec()
{
        when=$1
        do_timestamp "IPSEC $when "
        {
	echo "IPSEC FILTERS AND TUNNELS\n"
	echo "Hostname: $HOSTNAME"
        echo "Time $when run: `/bin/date`"
        echo "IPSECSTAT (/usr/sbin/ipsecstat)\n-----------------"
        $SBIN/ipsecstat
        echo "\n\nACTIVE FILTERS (/usr/sbin/lsfilt -a)\n-------------------"
        $SBIN/lsfilt -a
        echo "\n\nACTIVE FILTERS WITH -O FLAG (/usr/sbin/lsfilt -aO)\n-------------------"
        $SBIN/lsfilt -aO
        echo "\n\nACTIVE TUNNELS (/usr/sbin/lstun -a)\n-------------------"
        $SBIN/lstun -a
        } > ipsec.$when 2>&1
}

#-------------------------------------------------------------------------------------
#                              MAIN
#-------------------------------------------------------------------------------------


# following moved to end of perfpmr.sh
#premonpid=`$BIN/ps -ef|$BIN/grep perfpmr_premonitor.sh | $BIN/grep -v grep | $BIN/awk '{print $2}'`
#if [ "$premonpid" != "" ]; then
#	$BIN/ps -fp $premonpid | grep perfpmr_premonitor.sh && kill -30 $premonpid
#fi
do_timestamp "monitor.sh $@"
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
export LANG=C

if [ $# -eq 0 ]; then
        show_usage
fi

if [ -n "$PERFPMR_NO_WPAR"  ]; then
	WPAR=0
else
	WPAR=`$SBIN/lswpar -q | wc -l`
fi
AME=`echo "cmem" | /usr/sbin/kdb | grep vmcm_eyec | wc -l | awk '{print $1}'`

if [ $WPAR -gt 0 ]
then
	NETSTATWPAR="-W"
else
	NETSTATWPAR=""
fi

KDBMON=1
EMSTAT=1
NET=1
PROF=1
SVMON=1
MPSTAT=1
LPARSTAT=1
HPMSTAT=0
IOMON=1
FCSTAT2=1
POWERSTAT=1
TSTAT=1
DO_247=1
VENTSTAT=1
TCPSTAT=1
perfxtra_init=0
perfxtra_count=0
perfxtra_sleep=0
unset GLVM
while getopts gTvPFfkihenpsmlI:N:S:t flag ; do
        case $flag in
		g)     GLVM=1;;
		T)     TCPSTAT=0;;
		v)     VENTSTAT=0;;
		P)     POWERSTAT=0;;
		k)     KDBMON=0;;
		t)     TSTAT=0;;
		F)     FCSTAT2=0;;
		i)     IOMON=0;;
		h)     HPMSTAT=1;;
                e)     EMSTAT=0;;
                n)     NET=0;;
                p)     PROF=0;;
                s)     SVMON=0;;
		m)     MPSTAT=0;;
		l)     LPARSTAT=0;;
		I)     perfxtra_init=$OPTARG;;
		N)     perfxtra_count=$OPTARG;;
		S)     perfxtra_sleep=$OPTARG;;
                \?)    show_usage
        esac
done
shift OPTIND-1
SLEEP=$@

# check total time specified for minimum amount of 60 seconds
if [ "$SLEEP" -lt 60 ]; then
	echo Minimum time interval required is 60 seconds
	exit 1
fi

if [ -n "$PERFPMR_MONITOR_INTVLTIME" ]; then
	INTERVAL=$PERFPMR_MONITOR_INTVLTIME
else
	INTERVAL=10   # changed from 60 to 10 on 6/5/12
fi
let COUNT=$1/$INTERVAL
let COUNT=COUNT+1    # need count+1 intervals for VMSTAT
ONESECCOUNT=$1  # number of 1-second intervals

ulimit -d unlimited

#-------------------------------------------------------------------------------------
#            Collect 'before' stats 
#-------------------------------------------------------------------------------------
do_eid Begin > eidmon.before		# get EID stats

if [ $SVMON = 1 ]; then
	echo "\n     MONITOR: Capturing initial lsps, svmon, and vmstat data"
else
	echo "\n     MONITOR: Capturing initial lsps and vmstat data"
fi

do_pile_out > pile.before	# do pile at start
do_kdb_vmmstats > vmmstats_kdb.before
lsps_as > lsps.before		# pick up lsps output at start of interval
vmstat_i > vmstati.before	# pick up vmstat -i at start of interval
vmstat_v > vmstat_v.before	# pick up vmstat -v at start of interval
if [ -f /usr/sbin/acfstat ]; then
	echo "/usr/sbin/acfstat -A\nTime before:  " `$BIN/date` > acf.out
        /usr/sbin/acfstat -A >> acf.out
fi

if [ $AME -eq 1 ]; then
	SVMONOPT="-A"
	do_ame before
fi

if [ -f /usr/bin/svmon -a "$SVMON" = 1 ]; then  #-s flag will set SVMON=0
	if [ $WPAR -gt 0 ]; then
      		$PERFPMRDIR/svmon.sh -o svmon.before -w ALL
	else
  		$PERFPMRDIR/svmon.sh -o svmon.before $SVMONOPT
    	fi
fi

do_adapter_procfiles Begin > proc_sys_adapter.int.before 2> proc_sys_adapter.err	# get /proc stats for adapters
if [ "$FCSTAT2" != 0 ]; then
	do_fc before				# get fcstat stats
fi
do_lsmpio before
if [ "$NET" = 1 ]; then
	do_ipsec before
fi


#-------------------------------------------------------------------------------------
#                       The monitoring part 
#-------------------------------------------------------------------------------------
echo "     MONITOR: Starting perf_xtra programs: initsleep=$perfxtra_init count=$perfxtra_count sleep=$perfxtra_sleep"
$PERFPMRDIR/perfxtra.sh $perfxtra_init $perfxtra_count  $perfxtra_sleep &
echo "     MONITOR: Starting system monitors for $SLEEP seconds."

if [  "$MPSTAT" = 1 ]; then
	echo "              Starting <mpstat> monitoring"
	$PERFPMRDIR/mpstat.sh $SLEEP > /dev/null &
fi
/usr/bin/sleep 1  # so that mpstat doesn't show all the rest of monitor's processes running

echo "              Starting <ps> monitoring"
$PERFPMRDIR/ps.sh $SLEEP > /dev/null &

if [  "$GLVM" = 1 ]; then
	echo "              Starting <glvm> monitoring"
	$PERFPMRDIR/glvm.ksh93 -C $SLEEP > glvm.stdout_stderr 2>&1 &
fi

# skip nfsstat and netstat if -n flag used
if [ "$NET" = 1 ]; then
 	if [ -x /usr/sbin/nfsstat ]; then
		echo "              Starting <nfs> monitoring"
  		$PERFPMRDIR/nfsstat.sh $SLEEP > /dev/null &
 	fi
	echo "              Starting <netstat> monitoring"
	$PERFPMRDIR/netstat.sh $NETSTATWPAR $SLEEP > /dev/null &
fi

if [  "$DO_247" = 1 ]; then
	echo "              Starting <24x7count> monitoring"
	$PERFPMRDIR/24x7count.sh $SLEEP > /dev/null &
fi

if [  "$KDBMON" = 1 ]; then
	echo "              Starting <kdb> monitoring"
	$PERFPMRDIR/kdb_mon.sh $SLEEP > /dev/null &
fi

if [  "$EMSTAT" = 1 ]; then
	echo "              Starting <emstat> monitoring"
	$PERFPMRDIR/emstat.sh $SLEEP > /dev/null &
fi

if [  "$HPMSTAT" = 1 ]; then
	echo "              Starting <hpmstat> monitoring"
	$PERFPMRDIR/hpmstat.sh $SLEEP > /dev/null &
fi
if [  "$TSTAT" = 1 ]; then
	echo "              Starting <tstat> monitoring"
	$PERFPMRDIR/tstat -A $INTERVAL $COUNT  > tstat.out 2>&1  &
fi

echo "              Starting <sar> monitoring"
$PERFPMRDIR/sar.sh $SLEEP > /dev/null &

echo "              Starting <iostat> monitoring"
$PERFPMRDIR/iostat.sh $SLEEP > /dev/null &

echo "              Starting <aiostat> monitoring"
#$PERFPMRDIR/aiostat.sh $SLEEP > /dev/null &

if [ "$VENTSTAT" = 1 ]; then
	echo "              Starting <ventstat> monitoring"
	$PERFPMRDIR/ventstat -A  $INTERVAL $COUNT > ventstat.out 2>&1 &
fi

if [ "$FCSTAT2" = 1 ]; then
	echo "              Starting <fcstat2> monitoring"
	$PERFPMRDIR/fcstat2 -Aat -C fcstat2.csv $INTERVAL $COUNT > fcstat2.out 2> fcstat2.err &
fi
if [ "$IOMON" = 1 ]; then
	echo "              Starting <iomon> monitoring"
	$PERFPMRDIR/iomon -i $INTERVAL -l $COUNT > iomon.out &
fi

if [ "$AIXVER" -eq 7 ]; then
	echo "              Starting <foldstat> monitoring"
	#$PERFPMRDIR/foldstat -H 10 $INTERVAL $COUNT > foldstat.out 2>&1  &
	$PERFPMRDIR/foldstat -H 10 1  $ONESECCOUNT > foldstat.out 2>&1  &
fi

$PERFPMRDIR/pmapstat $INTERVAL $COUNT > pmapstat.out 2>&1  &
$PERFPMRDIR/lvmpbufstat64 $INTERVAL $COUNT > lvmpbufstat.out 2>&1 &
if [ "$TCPSTAT" = 1 -a "$TCPSTAT_PREMONITOR" != 1 ]; then
	$PERFPMRDIR/tcpstat -U 1 $ONESECCOUNT > tcpstat.out 2>&1  &
fi
if [ "$POWERSTAT" = 1 ]; then
	echo "              Starting <powerstat> monitoring"
	$PERFPMRDIR/powerstat -M $INTERVAL $COUNT > powerstat.out 2>&1  &
fi

if [ $AME -eq 1 ]
then
        VMSOPT="-A"
        LPSOPT="-A"
fi

if [  "$LPARSTAT" = 1 ]; then
	echo "              Starting <lparstat> monitoring"
	$PERFPMRDIR/lparstat.sh $LPSOPT $SLEEP > /dev/null &
fi

if [ $WPAR -gt 0 ]
then
	echo "              Starting <vmstat> monitoring"
	$PERFPMRDIR/vmstat.sh $VMSOPT -w ALL $SLEEP > /dev/null &
else
	echo "              Starting <vmstat> monitoring"
	$PERFPMRDIR/vmstat.sh $VMSOPT $SLEEP > /dev/null &
fi

if [ "$PROF" = 1 ]; then
  	# Give some time for above processes to startup and stabilize
  	$BIN/sleep 5
	echo "              Starting <pprof> monitoring"
  	$PERFPMRDIR/pprof.sh $SLEEP > /dev/null &
fi


# wait until all child processes finish
echo "     MONITOR: Waiting for measurement period to end...."
trap 'echo MONITOR: Stopping...but data collection continues.; exit 2' 1 2 3 24
$BIN/sleep $SLEEP &
wait


#-------------------------------------------------------------------------------------
#                      Collect 'after' stats 
#-------------------------------------------------------------------------------------
if [ "$SVMON" = 1 ]; then
  	echo "\n     MONITOR: Capturing final lsps, svmon, and vmstat data"
else
  	echo "\n     MONITOR: Capturing final lsps and vmstat data"
fi

do_pile_out > pile.after	# do pile at end
do_kdb_vmmstats > vmmstats_kdb.after
lsps_as > lsps.after		# pick up lsps output at end of interval
vmstat_i > vmstati.after	# pick up vmstat -i at end of interval
vmstat_v > vmstat_v.after	# pick up vmstat -v at end of interval

if [ $AME -eq 1 ]; then
	SVMONOPT="-A"
	do_ame after
fi
if [ -f /usr/sbin/acfstat ]; then
        echo "\n\nTime after:  " `$BIN/date` >> acf.out
	/usr/sbin/acfstat -A >> acf.out
fi

if [ -f /usr/bin/svmon -a "$SVMON" = 1 ]; then 	#-s flag will set SVMON=0
    	if [ $WPAR -gt 0 ]; then
      		$PERFPMRDIR/svmon.sh  -o svmon.after -w ALL
	else
      		$PERFPMRDIR/svmon.sh  -o svmon.after $SVMONOPT
    	fi
fi

do_adapter_procfiles End > proc_sys_adapter.int.after 	2>> proc_sys_adapter.err	# get /proc stats for adapters
if [ "$FCSTAT2" != 0 ]; then
	do_fc after				# get fcstat stats
fi
do_lsmpio after
if [ "$NET" = 1 ]; then
	do_ipsec after
fi

do_eid End > eidmon.after	# get EID stats


#-------------------------------------------------------------------------------------
#                        Post Processing 
#-------------------------------------------------------------------------------------
echo "     MONITOR: Generating reports...."

# collect all reports into two grand reports

echo "Interval File for System + Application\n" > monitor.int
echo "Summary File for System + Application\n" > monitor.sum

$BIN/cat ps.int >> monitor.int
$BIN/cat ps.sum >> monitor.sum
#$BIN/rm ps.int ps.sum

echo "\f" >> monitor.int
$BIN/cat sar.int >> monitor.int
echo "\f" >> monitor.sum
$BIN/cat sar.sum >> monitor.sum
#$BIN/rm sar.int sar.sum

echo "\f" >> monitor.int
$BIN/cat iostat.int >> monitor.int
echo "\f" >> monitor.sum
$BIN/cat iostat.sum >> monitor.sum
#$BIN/rm iostat.int iostat.sum

echo "\f" >> monitor.int
cat vmstat.int >> monitor.int
echo "\f" >> monitor.sum
$BIN/cat vmstat.sum >> monitor.sum
#$BIN/rm vmstat.int vmstat.sum

echo "\nAIO data is in aiostat.int" >> monitor.int
#echo "\f" >> monitor.int
#$BIN/cat aiostat.int >> monitor.int 2>/dev/null
#$BIN/rm aiostat.int 2>/dev/null


if [ -n "$EMSTAT" ]; then
	echo "\f" >> monitor.int
	$BIN/cat emstat.int >> monitor.int
	$BIN/rm emstat.int
fi

# skip nfsstat and netstat if -n flag used
if [ $NET = 1 ]; then
 	if [ -x /usr/sbin/nfsstat ]; then
  		echo "     MONITOR: Network reports are in netstat.int and nfsstat.int"
	else
  		echo "     MONITOR: Network report is in netstat.int"
 	fi
fi
#-------------------------------------------------------------------------------------

echo "     MONITOR: Monitor reports are in monitor.int and monitor.sum"
