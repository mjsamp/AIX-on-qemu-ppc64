#!/bin/ksh
BIN=/usr/bin
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`
perfpmrcfg=${PERFPMRCFG:-$PERFPMRDIR/perfpmr.cfg}
#-----------------------------
# Name: do_timestamp
#-----------------------------
do_timestamp()
{
        if [ "$2" = "nonewline" ]; then
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
        else
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
        fi
}
if [ "$preallocate_tracebufs" != 1 ]; then
	do_timestamp "Preallocation of trace buffers was not requested"
	exit
else
	do_timestamp "Preallocating trace buffers"
fi
trcbufsize=$(/usr/bin/awk '/^trace.sh/ { found=1;} /kbufsize/ { if (found==1) { size=$NF;exit;}} END {printf("%d\n", size);}' $perfpmrcfg)
#meg=${1:-20}
#let trcbufsize=meg*1000000
lcpu=`/usr/bin/vmstat |/usr/bin/awk '/lcpu/ { print substr($3,6)}'`
let memrequired=lcpu*trcbufsize
used=$(/usr/bin/vmstat -v|/usr/bin/grep "computational pages"|awk '{print $1}')
curcomputationalpct=$(/usr/bin/vmstat -v|/usr/bin/awk '{print $1}')
freepages=$(/usr/bin/vmstat -v|/usr/bin/awk '/ free pages/ {print $1}')
filepages=$(/usr/bin/vmstat -v|/usr/bin/awk '/ file pages/ {print $1}')
let noncomppages=freepages+filepages
let noncompbytes=noncomppages*4096
additionalmem=100000000  # extra 100MB just in case
let totalmemneeded=additionalmem+memrequired
let neededMB=totalmemneeded/1024/1024; let availMB=noncompbytes/1024/1024
echo "trcbufsize=$trcbufsize lcpus=$lcpu totalmemneeded=$totalmemneeded neededMB=$neededMB"
if [ "$used" -gt 90 ]; then
        echo "Warning. Computational memory usage is over 90%"
        #echo "Press enter if you want to run trace -> \c"
        #/usr/bin/line
fi
trap "trcstop; exit" 2
i=1
let meg=trcbufsize/1000000
while [ $i -le $meg ]; do
        echo "Allocating ${i}M trace buffers ...\c"
        cursec=$SECONDS
        trace -C all -L ${i}M -T ${i}M -adfo trace.raw
        let sec=SECONDS-cursec
        echo "Allocation took $sec seconds. Issuing trcstop"
        trcstop
	if [ $i -lt $meg ]; then
        	echo "Sleeping for 1 seconds"
        	sleep 1  # gives LRU and PSMD a chance to quiet down
	fi
        let i=i+1
done
