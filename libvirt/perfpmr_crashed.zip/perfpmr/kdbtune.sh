#!/bin/ksh

unset offset variable size hexvalue decvalue do_query
show_usage()
{
	echo "$0: [-v variablename] [-s size_of_object] [-o decoffset][-O hexoffset] [-h hexvalue] [-d decvalue]"
	echo "    -v variablename      the variable or symbol name to query/modify"
	echo "    -s size_of_object    the size in bytes of the object to query/modify .. must be 1, 4, or 8"
	echo "    -o dec_offset		   the offset in decimal bytes after the variable/symbol to query/modify"
	echo "    -O hex_offset		   the offset in hex bytes after the variable/symbol to query/modify"
	echo "    -h hexvalue          the new value to set for this variable/oject but specified as a hex value"
	echo "    -d decvalue          the new value to set for this variable/oject but specified as a decimal value"
	exit 1
}

h2d()
{
	hval=$(echo $1 | /bin/tr '[a-f]' '[A-F]')
	echo "ibase=16;$hval" | /usr/bin/bc
}

d2h()
{
	echo "obase=16;$1" | /usr/bin/bc
}

while getopts :v:s:h:d:o:O: flag ; do
        case $flag in
			o) dec_offset=$OPTARG;;
			O) hex_offset=$OPTARG;;
			v) variable=$OPTARG;;
			s) size=$OPTARG;;
			h) hexvalue=$OPTARG;;
			d) decvalue=$OPTARG;;
			\?)    show_usage;;
        esac
done
	
if [ -z "$variable" ]; then
	echo "must specify variable name"
	show_usage
fi

if [ "$size" -ne 1 -a "$size" -ne 4 -a "$size" -ne 8 ]; then
	echo "size specified <$size>  must be 1, 4, or 8"
	show_usage
fi

if [ -n "$hexvalue" -a -n "$decvalue" ]; then 
	echo "only one of hexvalue or decvalue can be specified"
	show_usage
fi


if [ -z "$hexvalue" -a -z "$decvalue" ]; then
	do_query=1
else
	if [ -n "$hexvalue" ]; then
		decvalue=$(h2d $hexvalue)
	fi
	if [ -n "$decvalue" ]; then
		hexvalue=$(d2h $decvalue)
	fi
	echo "decvalue=$decvalue hexvalue=$hexvalue"
fi

if [ -n "$dec_offset" ]; then
	hex_offset=$(d2h $dec_offset)
fi

case $size in
	8) modcmd=md; dispcmd=dd;;
	4) modcmd=mw; dispcmd=dw;;
	1) modcmd=m; dispcmd=d;;
	*) echo "Invalid size $size specified. Size must be 1, 4 or 8."
	   exit 1
	   ;;
esac
	   
kdbout=kdb_out.$$


# Get current value of var
query_variable()
{
if [ -n "$hex_offset" ]; then
/usr/sbin/kdb<<-EOF > $kdbout
		$dispcmd ${variable}+$hex_offset 1
		quit
EOF
else
/usr/sbin/kdb<<-EOF > $kdbout
		$dispcmd $variable 1
		quit
EOF
fi
	/bin/grep "^$variable" $kdbout | /bin/tail -1 | read x value y
	echo "symbol: $variable    hexvalue: $value    decimalvalue: $(h2d $value)"
	/bin/rm $kdbout
}

set_variable()
{
if [ -n "$hex_offset" ]; then
/usr/sbin/kdb<<-EOF > $kdbout
	$modcmd ${variable}+$hex_offset
	$hexvalue
	.
	$dispcmd ${variable}+$hex_offset 1
	quit
EOF
else
/usr/sbin/kdb<<-EOF > $kdbout
	$modcmd ${variable}
	$hexvalue
	.
	$dispcmd ${variable} 1
	quit
EOF
fi

	/bin/grep "^$variable" $kdbout | /bin/head -1 | read x old_val z
	/bin/grep "^$variable" $kdbout | /bin/tail -1 | read x new_val z
	if [ -z "$old_val" -o -z "$new_val" ]; then
		echo "Unknown error modifying variable."
		echo "kdb output is in $kdbout :"
		#/bin/cat $kdbout
		exit 1
	fi
	old_dec=$(h2d $old_val)
	new_dec=$(h2d $new_val)
	if [ "$decvalue" -ne "$new_dec" ]; then
		echo "Error modifying variable"
		echo "Current value = $new_dec      Expected new value = $decvalue or $old_dec"
		echo "kdb output is in $kdbout :"
		/bin/cat $kdbout
	 	exit 1
	fi
	/bin/rm $kdbout
}


if [ "$do_query" -eq 1 ]; then
	query_variable 
fi


if [ "$do_query" -ne 1 ]; then
	echo "Previous setting:"
	query_variable
	echo "New setting:"
	set_variable
	query_variable 
fi
