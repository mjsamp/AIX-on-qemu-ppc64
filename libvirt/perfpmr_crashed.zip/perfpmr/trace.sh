#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp. 2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# trace.sh
#
#   Used to collect trace data and create reports from the collected data
#

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`

lockhooks=234,101,104,106,10C,10E,112,113,134,139,465,46D,46E,5D8,606,607,608,609,1044,4AF,419,11F,107,200,102,103,102F,4B0

$BIN/trcstop -? 2>&1 | $BIN/grep -- "-s" >/dev/null
if [ $? = 0 ]; then
	trcstop_sflag_exists=1
else
	trcstop_sflag_exists=0
fi

do_timestamp()
{
        if [ "$2" = "nonewline" ]; then
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
        else
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
        fi
}


show_usage()
{
	 echo "trace.sh: usage: trace.sh [-j inhooks][-k exhooks][-J ingrps][-K exgrps][-L logsz][-T kbufsz][-F][-S][-I][-i][-r][-l][-g][-N][-C] [-n n][-s n] [-f file] [-A pids][-t tids] [-P[-P{p|t}] [-c] [-E locktrclevel] time"
	 echo "     -F          force trace collection even if missing apars"
	 echo "     -S          enable lock tracing"
	 echo "     -I          collect both lock trace and regular trace"
	 echo "     -i          prompt user to start trace and stop trace"
	 echo "     -j inhooks  comma-separated list of hooks to be included"
	 echo "     -J ingrps   comma-separated list of hook groups to be included"
	 echo "     -k exhooks  comma-separated list of hooks to be excluded"
	 echo "     -K exgrps   comma-separated list of hook groups to be excluded"
	 echo "     -L logsz    is total size of log buffer and disk space used"
	 echo "     -T kbufsz   is total size of kernel buffer; defaults to logsz" 
	 echo "     -r          runs post processing (trcrpt); -j and -k flags apply"
	 echo "     -l          Loop continuously using circular trace buffer"
	 echo "     -g          do not run gennames"
	 echo "     -N          do not collect inode table"
	 echo "     -C          do not use log file per CPU option"
	 echo "     -n number   run trace.sh <number> times in separate directories"
	 echo "     -s number   delay number second between each trace collection"
	 echo "     -f file     stop trace when <file> exists"
	 echo "     -A pids     comma-separated list of process id's to trace"
	 echo "     -t tids     comma-separated list of thread id's to trace"
	 echo "     -P p|t      specify propagation of process id's or thread id's"
	 echo "     -c          dump out all component trace buffers at the end into comptrace_dir"
	 echo "     -E level    specifies the errctrl level for the proc.lock component used during lock tracing"
	 echo "     time        is total time in seconds to trace"
	 exit 2
}

do_trcstop()
{
	if [ "$trcstop_sflag_exists" = 1 ]; then
		$BIN/nice --20 $BIN/trcstop -s
		if [ $? != 0 ]; then
			echo "TRACE.SH: trcstop -s not supported for non-circ files. Retrying without -s option"
			# in case -s on this system only supports circular traces
			$BIN/nice --20 $BIN/trcstop
		else
			# in case trcstop -s returns 0 even though it wasn't supported
			# if it was supported, this second trcstop should just return right away
			$BIN/nice --20 $BIN/trcstop 2>/dev/null
		fi
	else
		$BIN/nice --20 $BIN/trcstop
	fi
}

stop_othertraces()
{
	echo "     TRACE.SH: Stopping any previously running traces"
	for i in 1 2 3 4 5 6 7; do
		$BIN/trcstop -$i 2>/dev/null
	done
	do_trcstop
}


get_inode_data()
{
    	# get inode output if needed (not present or older than .init.state)
	if [ ! -n "$noinodetbl" ]; then
		if [ ! -f trace.crash.inode -o trace.crash.inode -ot /etc/.init.state ]; then
			if [ -z "$NO_KDB"  ]; then
				do_timestamp "collecting inode data from kdb"  nonewline; cursec=$SECONDS
				echo "inode" | $SBIN/kdb  >trace.crash.inode  2>&1  # in case pstat doesn't work
				echo "i2" | $SBIN/kdb > trace.j2.inode 2>&1  # get JFS2 inode table
				let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
			fi
		fi
	fi
}

get_gensyms()
{
	# in case tprof is used to post process the trace files, get gensyms data
	do_timestamp "running gensyms"  nonewline; cursec=$SECONDS
	$BIN/gensyms > trace.syms
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	do_timestamp "gensyms completed"
}

get_gennames()
{
	# get gennames output if needed (not present or older than .init.state)
	# the reason gennames is important is that it also collects the equivalent
	# of genld -l which is useful to show if shlibs were copied into a private segment

	if [ -z "$nogennames" ]; then
		if [ ! -f gennames.out -o gennames.out -ot /etc/.init.state ]; then
			if [ "$GETGENNAMESF" = 1 ]; then
				echo "     TRACE.SH: Collecting gennames -f data"
				do_timestamp "running gennames"  nonewline; cursec=$SECONDS
				LDR_CNTRL=MAXDATA=0x80000000 $BIN/gennames -f >gennames.out  2>&1
				let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
				do_timestamp "gennames completed"
			else
				echo "     TRACE.SH: Collecting gennames data"
				do_timestamp "running gennames"  nonewline; cursec=$SECONDS
				LDR_CNTRL=MAXDATA=0x80000000 $BIN/gennames >gennames.out  2>&1
				let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
				do_timestamp "gennames completed"
			fi
		fi
	fi
}


gen_otherfiles()
{
    	ulimit -d 8388608  # set to 8GB in case we need that much for gensyms 
			   # but not unlimited just to be safe
	get_inode_data
	get_gensyms
	get_gennames
}


gen_other_quick_files()
{
	$BIN/trcnm > $TNM
	echo "     TRACE.SH: Trcnm data is in file $TNM"

	$BIN/cp /etc/trcfmt $TFMT
	echo "     TRACE.SH: /etc/trcfmt saved in file $TFMT"

	$SBIN/mount > $TRCMNT
	# capture translation of major/minor to logical volume
	$BIN/ls -al /dev > trace.maj_min2lv
}

link_trfiles()
{
	files=$@
	for file in $@; do
	#	if [ -f ../$file ]; then
			$BIN/ln -s ../$file .
	#	fi
	done
}


gen_otherfilesN()
{
	link_trfiles trace.crash.inode gennames.out trace.syms trace.maj_min2lv trace.nm trace.fmt trace.mount
}

run_trace()
{
  	if [ "$1" = "getinstrumentedtrace" ]; then
        	getlocktrace=1
  	else
        	getlocktrace=
  	fi
	if [ "$1" = "default"  -a "$dump_comptrace" = 1 ]; then
		do_memtracesuspend=1;
	fi
	if [ -n "$locktracing" -o "$getlocktrace" = 1 ]; then
		echo "\n     TRACE.SH: Enabling locktrace"
		$BIN/locktrace -S
		set_locktrace=1
		if [ "$Eflag" = 1 ]; then
			curlocktrclevel=`$SBIN/errctrl -q -c proc.lock|$BIN/tail -1|$BIN/awk -F'/' '{print $2}'|$BIN/awk '{print $1}'`
			if [ "$curlocktrclevel" != "$locktrclevel" ]; then
				echo "     TRACE.SH: Changing lock trace level from <$curlocktrclevel> to <$locktrclevel> temporarily"
				$SBIN/errctrl -c proc.lock errchecklevel=$locktrclevel
				set_locktrclevel=1
			fi
		fi
	fi
	if [ -n "$interactive" ]; then
		echo "     TRACE.SH: Starting interactive trace"
	elif [ "$ltype" = "-l" ]; then
		echo "     TRACE.SH: Starting loop trace"
	else
		echo "     TRACE.SH: Starting trace for $time seconds"
	fi

	if [ "$ltype" = "-l" ]; then
		let LOGBUF=$KERNBUF*2
	fi
	if [ "$getlocktrace" = 1 ]; then
		echo "$trace $PROPAGATE $PROCESS_LIST $THREAD_LIST $PURR  -j $lockhooks $ltype $trcnflag $CPUS -d -L $LOGBUF -T $KERNBUF -ao $TRAWL"
		do_timestamp "initializing lock trace buffers"  nonewline; cursec=$SECONDS
		$trace $PROPAGATE $PROCESS_LIST $THREAD_LIST $PURR  -j $lockhooks $ltype $trcnflag $CPUS -d -L $LOGBUF -T $KERNBUF -ao $TRAWL
	else
		echo "$trace $PROPAGATE $PROCESS_LIST $THREAD_LIST $PURR $INGROUPHOOKS $EXGROUPHOOKS $exhooks $inhooks $ltype $trcnflag $CPUS -d -L $LOGBUF -T $KERNBUF -ao $TRAW"
		do_timestamp "initializing trace buffers"  nonewline; cursec=$SECONDS
		$trace $PROPAGATE $PROCESS_LIST $THREAD_LIST $PURR $INGROUPHOOKS $EXGROUPHOOKS $exhooks $inhooks $ltype $trcnflag $CPUS -d -L $LOGBUF -T $KERNBUF -ao $TRAW
	fi
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"

	if [ -n "$interactive" ]; then
		echo "\nPress <enter> to START tracing \c"; $BIN/line
	fi

	$BIN/trcon		# start tracing
	do_timestamp "trcon completed"
	echo "     TRACE.SH: Data collection started"
	if [ -n "$interactive" -o "$ltype" = "-l" ]; then
		if [ -n "$stop_trigger" ]; then
			echo "\n     `$BIN/date`"
			echo "\tWaiting for file <$stop_trigger_file> to exist ...\c"
			while :; do
				if [ -f "$stop_trigger_file" ]; then
					echo "\n\tFile <$stop_trigger_file> exists"
					echo "     `$BIN/date`"
					break;
				fi
				$BIN/sleep 1
			done
		else
			echo "\nPress <enter> to STOP tracing ->\c"; $BIN/line
		fi
	else
		$BIN/sleep $time
	fi

	echo "     TRACE.SH: trace data collection is being stopped"
	$BIN/trcoff
	do_timestamp "trcoff completed"
	if [ "$do_memtracesuspend" = 1 ]; then
		echo "     TRACE.SH: Suspending component trace"
		$SBIN/ctctrl -c all memtracesuspend > memtrace.err 2>&1
		memtrace_suspended=1
	fi
		
	do_timestamp "trcstop"  nonewline; cursec=$SECONDS
	do_trcstop
	#$BIN/nice --20 trcstop
	let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
	echo "     TRACE.SH: Trace stopped"
	do_timestamp "trcstop completed"
	if [ -n "$locktracing" -o "$getlocktrace" = 1 ]; then
		echo "     TRACE.SH: Disabling locktrace"
		$BIN/locktrace -R
		set_locktrace=0
		if [ "$set_locktrclevel" = 1 ]; then
			echo "     TRACE.SH: Setting locktrclevel of <$locktrclevel> back to previous level of <$curlocktrclevel>"
			$SBIN/errctrl -c proc.lock errchecklevel=$curlocktrclevel
		fi
	fi
}

run_traces()
{
	if [ "$1" = "default" ]; then
		run_trace default
	else
		run_trace
	fi
	if [ -n "$instrumentedtrace" ]; then
		run_trace getinstrumentedtrace
	fi
}

do_traces()
{
	if [ ! -x /usr/bin/trace ]; then
		echo "\n     TRACE.SH: /usr/bin/trace command is not installed"
		echo   "     TRACE.SH:   This command is part of the optional bos.sysmgt.trace fileset"
		exit 1
	fi
	KERTYPE=`$SBIN/bootinfo -K`
	if [ "$KERTYPE" = 32 ]; then
		PURR=""
	else
		if  $SBIN/smtctl >/dev/null; then
			PURR="-p -r PURR"
		else
			PURR="-p"
		fi
	fi

	if [ -n "$excludehooks" ]; then
		if $BIN/lparstat -i | $BIN/grep -i "^Type.*Shared" >/dev/null; then
			exhooks="-k $excludehooks"
		else
			if [ -d /usr/ios ]; then
				exhooks="-k $excludehooks"
			else
				#exhooks="-k 492,$excludehooks"
				exhooks="-k $excludehooks"
			fi
		fi
	fi
	if [ -n "$includehooks" ]; then
		inhooks="-j $includehooks"
	fi
	if [ -n "$loopflag" ]; then
		ltype="-l"
	else
		ltype="-f"
	fi

	# run lparstat in the background while trace is running
        if $BIN/lparstat -? 2>&1 | $BIN/grep -q '\[-t\]' ; then
                TFLAG="-t"
        else
                TFLAG=""
        fi
        chk_lparstatfix && LPARSTATHFLAG="-h"
        $BIN/lparstat $TFLAG $LPARSTATHFLAG  1 > lparstat.nsp &
        lparstatpid=$!

	if [ -n "$ntraces" -a "$ntraces" -gt 0 ]; then
		tcounter=0
		if [ "$called_from_perfpmr" -eq 1 ]; then
			echo "0" > $TCOUNTFILE
		fi
		while [ "$tcounter" -lt $ntraces ]
		do
			if [ -f $TCOUNTFILE ]; then
				read tcount < $TCOUNTFILE
				let tcount=tcount+1
			else
				tcount=1
			fi
			echo $tcount > $TCOUNTFILE
			echo "Making directory trace$tcount"
			$BIN/mkdir trace$tcount
			cd trace$tcount
			echo "\n     TRACE.SH: Executing trace collection set $tcount"
			run_traces
			let tcounter=tcounter+1
			if [ -n "$sleepdelay" -a "$tcounter" -lt $ntraces ]; then
				echo "     TRACE.SH   sleeping for $sleepdelay seconds"
				$BIN/sleep $sleepdelay
			fi
			gen_otherfilesN
			cd ..
		done
	else  # default trace.sh behavior
		run_traces default
		gen_other_quick_files
	fi

	$BIN/kill -2 $lparstatpid

	# wait until trace has closed the output file
	$BIN/sleep 2
	if [ "$getlocktrace" = 1 ]; then
		echo "     TRACE.SH: Binary trace data files are in ${TRAWL}*"
	else
		echo "     TRACE.SH: Binary trace data files are in ${TRAW}*"
	fi
}

gen_other_rpt_files()
{
	echo "Creating trace.tr/trace.trc"
	$BIN/ln -s trace.tr trace.trc 
	echo "Creating curt.out"
	#$BIN/curt -i trace.trc -e -s -OPpt -o curt.out
	$BIN/curt -r PURR -m trace.nm -n trace.syms -i trace.trc -e -s -OPpt -o curt.out
	$BIN/tprof -r PURR -lskeu -r trace
	$BIN/splat -n trace.syms -da -i trace.raw.lock -o splat.out
	$BIN/filemon -n trace.syms -i trace.trc -Oall > trace.filemon
	$BIN/filemon -n trace.syms -i trace.trc -Odetailed,all > trace.filemon2
	$BIN/netpmon -n trace.syms -r PURR -i trace.trc -Oall > trace.netpmon
}

do_reports()
{
	if [ -n "$excludehooks" ]; then
		exhooks="-k $excludehooks"
	fi
	if [ -n "$includehooks" ]; then
		inhooks="-d $includehooks"
	fi
	# see if needed files are here
	if [ ! -f $TRAW ]; then
		if [ ! -f $TBIN ]; then
			echo "    TRACE.SH: $TRAW file not found..."
		exit 1
	fi
	else
		$BIN/trcrpt $CPUS -r $TRAW > $TBIN
		#rm ${TRAW}*
	fi
	if [ ! -f $TFMT ]; then
		echo "    TRACE.SH: $TFMT file not found..."
		exit 1
	fi
	if [ ! -f $TNM ]; then
		echo "    TRACE.SH: $TNM file not found..."
		exit 1
	fi
	echo "\n     TRACE.SH: Generating report...."
	msg="\n\n\n     T  R  A  C  E    I  N  T  E  R  V  A  L    O  U  T  P  U  T\n"
	echo $msg > $TRPT

	if [ -n "$Kflag" ]; then
		Ooptions="timestamp=0,exec=on,tid=on,cpuid=on,ids=0"
	else
		Ooptions="timestamp=1,exec=on,tid=on,cpuid=on"
	fi

	$BIN/trcrpt $exhooks $inhooks -t $TFMT -n $TNM -O $Ooptions $TBIN >> $TRPT
	gen_other_rpt_files
	echo "     TRACE.SH: Trace report is in file $TRPT"
}

validate_fs()
{
        $BIN/df $PWD | $BIN/tail -1 | $BIN/awk '{print $1,$NF}'  | read lv fs
        if [ "$fs" != "" ]; then
             $SBIN/mount | $BIN/fgrep -w "$fs" | $BIN/awk '{print $3,$4,$7}' | read fstype1 fstype2 options
             if echo $options | $BIN/egrep 'cio|dio' >/dev/null; then
                echo "The filesystem for $PWD is mounted with 'cio' or 'dio'"
                echo "Data collection will have additional overhead"
                echo "Delaying 5 seconds to allow ctrl/c out of perfpmr.sh"
                $BIN/sleep 5
             fi
             if echo $fstype1 $fstype2 | $BIN/egrep 'nfs|dfs|autofs' >/dev/null; then
                echo "The filesystem for $PWD is a remote filesystem"
                echo "Data collection may have additional overhead"
                echo "Delaying 5 seconds to allow ctrl/c out of perfpmr.sh"
                $BIN/sleep 5
             fi
        fi
}

check_for_fixes()
{
    aixv=`$BIN/uname -v`
    aixr=`$BIN/uname -r`
    if [ "$aixv" = 6 ]; then
        kernel_tl_level=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -1|$BIN/awk '{print $2}'|$BIN/cut -c5`
        if [ "$kernel_tl_level" = 6 ]; then
                $SBIN/instfix -ik IZ84729 >/dev/null 2>&1
                if [ $? != 0 ]; then
			$SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                	if [ $? != 0 ]; then
                          echo "TRACE.SH:  REQUIRED APAR IZ84729 or IZ85204 is not installed"
                          if [ -z "$force_trace" ]; then
				echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
				echo "OR RUN TRACE.SH with -F flag"
                                exit 0
                          fi
		       fi
                fi
        fi
        if [ "$kernel_tl_level" = 7 ]; then
                $SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                if [ $? != 0 ]; then
                        echo "TRACE.SH:  REQUIRED APAR IZ85204 is not installed"
                        if [ -z "$force_trace" ]; then
				echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
				echo "OR RUN TRACE.SH with -F flag"
                                exit 0
			fi
                fi
        fi
   fi  # uname
   if [ "$aixv" = 7 -a "$aixr" = 2 ]; then
	notinstalled=1
	kernel_tl_level=`$BIN/lslpp -qcL bos.mp64|$BIN/awk -F: '{printf("%s\n", substr($3,5,1));}'`
	if [ "$kernel_tl_level" = 0 ]; then
		$SBIN/instfix -ik IV92790 >/dev/null  2>&1
		notinstalled=$rc
	elif [ "$kernel_tl_level" = 1 ]; then
		$SBIN/instfix -ik IV95588 >/dev/null  2>&1
		notinstalled=$rc
	elif [ "$kernel_tl_level" = 2 ]; then
		$SBIN/instfix -ik IV94174 >/dev/null  2>&1
		notinstalled=$rc
	else
		notinstalled=0
	fi

	if [ "$notinstalled" != 0 ]; then
		trcnflag=""
	else
		trcnflag="-n"
	fi
   fi
}

chk_lparstatfix()
{
	$BIN/lslpp -qLc bos.acct|$BIN/grep -q "6.1.9.0"
	if [ $? -eq 0 ]; then
		$SBIN/emgr -l|$BIN/grep -q "IV53394"
		if [ $? -ne 0 ]; then
		 echo "Running lparstsat without -h option. Either upgrade to"
		 echo "AIX 6100-09-03 or install ifix for APAR IV53394 to resolve the lparstat -h issue"
		 return 1
		fi
		return 0
	fi
}

cleanup()
{
	echo "Signal received. Stopping trace"
	do_trcstop
	if [ "$set_locktrace" = 1 ]; then
		echo "disabling locktrace"
		/usr/bin/locktrace -R
	fi
	if [ "$set_locktrclevel" = 1 ]; then
		echo "     TRACE.SH: Setting locktrclevel of <$locktrclevel> back to previous level of <$curlocktrclevel>"
		$SBIN/errctrl -c proc.lock errchecklevel=$curlocktrclevel
	fi
        if [ "$memtrace_suspended" = 1 ];then
		echo "     TRACE.SH: Resuming component trace from suspended state"
                $SBIN/ctctrl -c all memtraceresume >> memtrace.err 2>&1
        fi
	exit
}

############################## MAIN  ###########################33
LOGBUF=20000000
TRAW=trace.raw
TRAWL=trace.raw.lock
TBIN=trace.tr
TRPT=trace.int
TNM=trace.nm
TFMT=trace.fmt
TCOUNTFILE=tr.count
TRCMNT=trace.mount
trace=/usr/bin/trace
CPUS="-C all"
trcnflag="-n"
unset rflag interactive includehooks excludehooks KERNBUF Kflag nogennames sleepdelay LPARSTATHFLAG TFLAG
unset EXTSHM PROPAGATE THREAD_LIST PROCESS_LIST INGROUPHOOKS EXGROUPHOOKS locktrclevel curlocktrclevel set_locktrclevel Eflag
unset force_trace dump_comptrace
if [ "$GETGENNAMES" = 0 ]; then
	nogennames=1
fi

[ $# = 0 ] && show_usage
while getopts :t:A:P:CINn:s:griK:lk:j:L:T:Sf:pFJ:cE: flag ; do
        case $flag in
		E)	locktrclevel=$OPTARG;Eflag=1;;
		c)	dump_comptrace=1;;
		J)	INGROUPHOOKS="-J $OPTARG";;
		K)	EXGROUPHOOKS="-K $OPTARG";;
		F)     force_trace=1;;
                p)     called_from_perfpmr=1;;
		t)     THREAD_LIST="-t $OPTARG";;
		A)     PROCESS_LIST="-A $OPTARG";;
		P)     PROPAGATE="-P$OPTARG";;
		f)     stop_trigger=1;
		       stop_trigger_file=$OPTARG;;
                n)     ntraces=$OPTARG;;
                s)     sleepdelay=$OPTARG;;
		S)	locktracing=1;;
                I)      instrumentedtrace=1;;
		N)     noinodetbl=1;;
                C)     CPUS="";;
                g)     nogennames=1;;
                r)     rflag=1;;
                K)     Kflag=1;;
                l)     loopflag=1;;
                i)     interactive=1;;
                j)     includehooks=$OPTARG;;
                k)     excludehooks=$OPTARG;;
                L)     LOGBUF=$OPTARG;;
                T)     KERNBUF=$OPTARG;;
                \?)    show_usage
        esac
done
shift OPTIND-1
time=$@

if [ "$called_from_perfpmr" != 1 ]; then
        validate_fs
fi

if [ -z "$KERNBUF" ]; then   # if no -T, then set it equal to -L value
	KERNBUF=$LOGBUF
fi
if [ -z "$interactive" -a -z "$time" -a -z "$rflag" -a -z "$loopflag" ]; then  # no i flag or time specified
	echo "Must specify a time value in seconds or use the -i flag"
	show_usage
fi

#----- GENERATE REPORTS IF -r OPTION SPECIFIED  AND EXIT ------------------------------------
if [ -n "$rflag" ]; then	# do post processing/generate reports
	if [ -n "$ntraces" ]; then
	   if [  "$ntraces" -gt 0 ]; then
             tcounter=0
	     while [ "$tcounter" -lt $ntraces ]; do
		let tcounter=tcounter+1
		cd trace$tcounter
  		echo "\n     TRACE.SH: Generating report for trace set $tcounter...."
		do_reports
		cd - >/dev/null
	     done
	   else
		read tcounter < $TCOUNTFILE
		cd trace$tcounter
  		echo "\n     TRACE.SH: Generating report for trace set $tcounter...."
		do_reports
		cd - >/dev/null
	   fi
	else
	   do_reports
	fi
	exit	# exit the script after reports generated
fi
#-----------------------------------------------------------------------------------

if /usr/bin/locktrace -l | grep "enabled" >/dev/null; then
	echo "WARNING: locktrace was already enabled"
fi
check_for_fixes
stop_othertraces 	# stop any sna traces etc currently running
#trap "cleanup; exit" 2
trap "cleanup" 2
do_traces
gen_other_quick_files
if [ "$DO_TRACE_MISCFILES_INCONFIG" = 1 ]; then
	echo "TRACE.SH: skipping collection of gennames/gensyms/inode data until config.sh"
else
	gen_otherfiles
fi

if [ "$dump_comptrace" = 1 ]; then
	mkdir comptrace_dir
	$SBIN/ctctrl -D -d $PWD/comptrace_dir -rc all 2> ctctrl.err
	if [ "$memtrace_suspended" = 1 ];then
		echo "     TRACE.SH: Resuming component trace from suspended state"
		$SBIN/ctctrl -c all memtraceresume >> memtrace.err 2>&1
	fi
fi

if [ -f $PERFPMRDIR/tbdiff ]; then
	$PERFPMRDIR/tbdiff > tbdiff.out
fi
