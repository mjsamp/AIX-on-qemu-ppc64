#!/bin/ksh


export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

run_xtra_stuff()
{
	{
	#$PERFPMRDIR/trace.sh -k 254,255,116,117,535,537,539,492  5
	#$PERFPMRDIR/trace.sh -I -k 254,255,116,117,535,537,539,492  5
	#$BIN/tprof -E PM_CYC -skeuzl -x $BIN/sleep 30
	#$PERFPMRDIR/filemon.sh 10
	return 0
	} 2>&1 | $BIN/tee -a perfxtra.int
}

initsleep=${1:-0}
count=${2:-0}
sleeptime=${3:-0}
n=0
xdirname=perf_xtra

$BIN/sleep $initsleep
while [ $n -lt $count ];  do
	dir=${xdirname}_${n}
	if [ ! -f $dir ]; then
		$BIN/mkdir $dir
	fi
	cd $dir
	d=`$BIN/date +%b%d_%Y_%H:%I:%S`
	echo "Perf xtra programs started at $d" |$BIN/tee  perfxtra.int
	run_xtra_stuff
	cd ..
	let n=n+1
	$BIN/sleep $sleeptime
done
