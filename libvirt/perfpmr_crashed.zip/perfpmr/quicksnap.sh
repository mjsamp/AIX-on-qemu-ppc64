#!/bin/ksh
# Name: quicksnap  Version: 1.0
# Ian MacQuarrie, 408-256-1820
# IBM Product Engineering, SanJose CA
# Script used to collect host configuration data
# External commands: odmget,lsdev,lscfg,lsattr,lsvg,lslv,lslpp
# Creation Date: 06-07-04  

# Collect host info
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

print "Data collected for host" $(hostname -s) "on" $(date)
$BIN/printf "\n"

# Collect some code levels
$BIN/lslpp -L |grep -i "sdd"
$BIN/lslpp -L |grep -i "ibm2105"
$BIN/lslpp -L |grep -i "lvm"
$BIN/lslpp -L |grep -i "df100"
$BIN/printf "\n" 

# Collect the AIX maintenance level
$SBIN/instfix -i |grep ML
$BIN/printf "\n"

# Collect info on FC adapters
print "HBA-FC     WWPN                 LOCATION"
fcs_list=`$SBIN/lsdev -Cc adapter |$BIN/grep fcs |$BIN/awk '{print $1}'`
for fcs in $fcs_list
 do
  wwpn=`$SBIN/lscfg -vl $fcs |$BIN/grep Network |$BIN/cut -c37-54`
  adap_loc=`$SBIN/lsdev -Cl $fcs |$BIN/awk '{print $3}'`
  $BIN/printf "%-10s %-20s %-10s\n" $fcs $wwpn $adap_loc
 done

# Collect into on SCSI adapters
$BIN/printf "\n"
print "HBA-SCSI   LOCATION"
scsi_list=`$SBIN/lsdev -Cc adapter |$BIN/grep scsi |$BIN/awk '{print $1}'`
for scsi in $scsi_list
 do
  adap_loc=`$SBIN/lsdev -Cl $scsi |$BIN/awk '{print $3}'`
  $BIN/printf "%-10s %-20s\n" $scsi $adap_loc
 done

# Get a list of volume groups
vg_list=`$BIN/odmget -q attribute=vgserial_id CuAt |$BIN/grep name |$BIN/cut -f2 -d\"`
for vg in $vg_list
 do
 if [ "$vg" != "rootvg" ]
 then
  $SBIN/lsvg -o |$BIN/grep $vg > /dev/null 2>&1
  rc=$? 
  if [ $rc -eq 0 ] 
   then
    pp_size=`$SBIN/lsvg $vg |$BIN/grep "PP SIZE" |$BIN/awk '{print $6}'`
    print "\n"
    $BIN/printf "VOLUME GROUP:%s  PP SIZE:%sM\n" $vg $pp_size 
    print "==================================================================="
    pvid_list=`$BIN/odmget -q "name=$vg and attribute=pv" CuAt |$BIN/grep value |$BIN/cut -f2 -d\"`
    print "PV            MAJ/MIN   SERIAL#    PVID               LOCATION PATH"
    for pvid in $pvid_list
     do
      pvid_short=`print $pvid |$BIN/cut -c1-16`
      disk_list=`$BIN/odmget -q "value=$pvid and attribute=pvid" CuAt |$BIN/grep name |$BIN/cut -f2 -d\"`
    for disk in $disk_list
     do
      $BIN/odmget -q name=$disk CuDv |$BIN/grep 2105 > /dev/null
      Type2105=$?
      parent=`$SBIN/lsdev -Cl $disk -r parent`
       if [ "$parent" = "dpo" ] # collect data for vpath devices
        then
         major=`$BIN/odmget -q value3=$disk CuDvDr |$BIN/grep value1 |$BIN/cut -f2 -d\"`
         minor=`$BIN/odmget -q value3=$disk CuDvDr |$BIN/grep value2 |$BIN/cut -f2 -d\"`
         $BIN/printf "%-12s %3x/%-17x %-10s\n"  $disk $major $minor $pvid_short                      
         hdisk_list=`$BIN/odmget -q "name=$disk and attribute=active_hdisk" CuAt|$BIN/grep value|$BIN/cut -f2 -d\"|$BIN/cut -f1 -d\/`
         for hdisk in $hdisk_list # collect data for hdisks under vpaths
         do
          serial=`$SBIN/lscfg -vl $hdisk |$BIN/grep Serial |$BIN/cut -c37-44`
          if [ $Type2105 -eq 0 ]
            then
             port_id=`$SBIN/lscfg -vl $hdisk |$BIN/grep Z1 |$BIN/cut -c37-40`
            else
             port_id="N/A"
          fi
          adap_loc=`$SBIN/lsdev -Cl hdisk6 |$BIN/awk '{ print $3 }'`
          major=`$BIN/odmget -q value3=$hdisk CuDvDr |$BIN/grep value1 |$BIN/cut -f2 -d\"`   
          minor=`$BIN/odmget -q value3=$hdisk CuDvDr |$BIN/grep value2 |$BIN/cut -f2 -d\"`   
          $BIN/printf "  %-10s %3x/%-6x %-29s %-8s %-10s\n" $hdisk $major $minor $serial $adap_loc $port_id 
         done
       else # collect data for non-vpath devices
          serial=`$SBIN/lscfg -vl $disk |$BIN/grep Serial |$BIN/cut -c37-44`
          if [ -z "$serial" ]
            then
              serial="N/A"
          fi
          if [ $Type2105 -eq 0 ]
            then
             port_id=`$SBIN/lscfg -vl $hdisk |$BIN/grep Z1 |$BIN/cut -c37-40`
            else
             port_id="N/A"
          fi
          adap_loc=`$SBIN/lsdev -Cl hdisk6 |$BIN/awk '{ print $3 }'`
          major=`$BIN/odmget -q value3=$disk CuDvDr |$BIN/grep value1 |$BIN/cut -f2 -d\"`   
          minor=`$BIN/odmget -q value3=$disk CuDvDr |$BIN/grep value2 |$BIN/cut -f2 -d\"`   
          $BIN/printf "%-12s %3x/%-6x %-10s %-18s %-6s %-10s\n" $disk $major $minor $serial $pvid_short $adap_loc $port_id
       fi
     done
    done
  # collect data for locical volumes
  vg_id=`$BIN/odmget -q "name=$vg and attribute=vgserial_id" CuAt |$BIN/grep value |$BIN/cut -f2 -d\"`
  lv_id_list=`$BIN/odmget -q "value like $vg_id.*" CuAt |$BIN/grep value |$BIN/cut -f2 -d\"`
  for lv_id in $lv_id_list
   do
    lv=`$BIN/odmget -q "attribute=lvserial_id AND value=$lv_id" CuAt |$BIN/grep name |$BIN/cut -f2 -d\"`
    mount=`$BIN/odmget -q "name=$lv and attribute=label" CuAt |$BIN/grep value |$BIN/cut -f2 -d\"`
    if [ -z "$mount" ]
      then mount="N/A"
    fi
    major=`$BIN/odmget -q value3=$lv CuDvDr |$BIN/grep value1 |$BIN/cut -f2 -d\"`    
    minor=`$BIN/odmget -q value3=$lv CuDvDr |$BIN/grep value2 |$BIN/cut -f2 -d\"`    
    pp_count=`$SBIN/lsvg -l $vg |$BIN/grep $lv |$BIN/awk '{print $4}'` 
    $BIN/printf "\n"
    $BIN/printf "LOGICAL VOLUME:%s MAJ/MIN:%x/%x MOUNT POINT:%s PPs:%s\n" $lv $major $minor $mount $pp_count
    copies=`$BIN/lslv $lv |$BIN/grep COPIES |$BIN/awk '{print $2}'`
    if [ $copies -gt 1 ]
      then
       print "*** Mirrored LV ***"
       print "partition table saved to $lv.ppmap.out"   
       /etc/lslv -m $lv > $lv.ppmap.out
    fi
    pv_list=`/etc/lslv -l $lv |$BIN/egrep "hdisk|vpath" |$BIN/awk '{print $1}'`
    for pv in $pv_list
    do   
     pp_count=`/etc/lslv -l $lv |$BIN/grep $pv |$BIN/awk '{print $2}' |$BIN/cut -f1 -d:`
     $BIN/printf "%-10s %-10s\n" $pv $pp_count
    done
   done
  else
   $BIN/printf "\n"
   print "$vg not online - can't collect data for offline volume groups."
  fi # end of if vg online
 fi # end of if not rootvg
 done
