#!/bin/ksh
vfcfile=getvfc.out
vfcdevfile=getvfc.devs
vfckdbfile=svfcva.kdb.out
hostname=`/usr/bin/hostname -s`

cleanup()
{
        /bin/rm -f $vfcfile
        /bin/rm -f $vfcdevfile
        /bin/rm -f $vfckdbfile
}

get_vfc()
{
/usr/sbin/lsdev -C|/usr/bin/grep vfchost|/usr/bin/grep Available | /usr/bin/awk '{print $1}'|while read host; do
        fcsdev=`/usr/sbin/lsattr -E -l $host -a map_port -F value`
        echo "svfcCI; svfcPrQs; svfcva $host" | /usr/sbin/kdb > $vfckdbfile
        wwpn=`/usr/bin/grep " wwpn: " svfcva.kdb.out |/usr/bin/awk '{print $NF}'`
        if [ "$wwpn" != "0" ]; then
                clientname=`/usr/bin/grep "clientPartName" $vfckdbfile|/usr/bin/awk '{print $NF}'`
                #echo "For host: $clientname   Run:  fcstat -n $wwpn $fcsdev"
                echo "$fcsdev $clientname $wwpn"
        fi
done
}
parse_fcstat()
{
/usr/bin/cat |
/usr/bin/grep -E -p "FC SCSI Traffic Stat|FC SCSI Adapter Driver Information"  | /usr/bin/awk '
/Input Requests:/ { ir=$NF }
/Output Requests:/ { or=$NF }
/Control Requests:/ { cr=$NF }
/Input Bytes:/ { ib=$NF }
/Output Bytes:/ { ob=$NF}
/No DMA Resource Count:/ { drc=$NF }
/No Adapter Elements Count:/ { aec=$NF }
/No Command Resource Count:/ { crc=$NF }
END {
printf("%10d %10d %8d %16lld %16lld %9d %9d %9d \n",  ir, or, cr, ib, ob,drc,aec,crc);
}'
}


# MAIN
get_vfc > $vfcfile
/usr/bin/awk '{print $1}' $vfcfile | /usr/bin/sort -u > $vfcdevfile
/usr/bin/printf "%5s %20s %10s %10s %8s %16s %16s %9s %9s %9s \n"  "dev" "hostname" "inreqs" "outreqs" "ctrlreqs" "inbytes" "outbytes" "DMA_errs" "Elem_errs" "Comm_errs"
while read dev; do
        out=`/usr/sbin/fcstat $dev | parse_fcstat`
        /usr/bin/printf "%5s %20s %s\n" $dev $hostname "$out"
        /usr/bin/grep -w "^$dev" getvfc.out|while read fc host wwpn; do
                out=`/usr/sbin/fcstat -n $wwpn $dev | parse_fcstat`
                /usr/bin/printf "%26s %s\n" $host  "$out"
        done
        echo
done < $vfcdevfile

cleanup
