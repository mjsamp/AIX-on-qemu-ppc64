#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: 27
#
# (C) COPYRIGHT International Business Machines Corp. 2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# iptrace.sh
#
# invoke RISC System/6000 iptrace command or generate report
#

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin


IPTRACEOUT=iptrace.raw
show_usage()
{
        echo "Usage: iptrace.sh <seconds> | iptrace.sh [-S] [-L packetlength] [-r][-I interface]"
	echo "\t-S  bring up SEA interfaces if down on a VIOS but restore them to original state after iptrace"
	echo "\t-L  specify the size of the packet length .. default is 96";
        echo "\t-r  produce report and place in $IPTRACEOUT"
        echo "\t-I  specifies interface when used in conjunction with length option which uses -B"
        echo "\ttime in seconds is how long to collect data"
        exit 1
}

if [ $# -eq 0 ]; then
        show_usage
fi

length=0
interface=""
while getopts I:rSL: flag ; do
        case $flag in
		I)	interface="-i $OPTARG";;
                r)     doreport=1;;
		S)     vios_iptrc=1;;
		L)     length=$OPTARG;;
                \?)    show_usage
        esac
done
shift OPTIND-1
sleeptime=$@

if [ "$length" = 0 ]; then
	length=""
else
	length="-B -S $length"
fi
do_timestamp()
{
        echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
}


handle_vios_mult_invoke()
{
	do_timestamp "This is a VIOS lpar"
        /usr/sbin/lsdev -C| grep "Shared Ethernet Adapter"|grep Avail|awk '{print $1}'| while read seadev; do
           num=${seadev##*ent}
           enif=en$num
           if [ "$do_run" = 1 ]; then
             ifconfig $enif | grep "<UP," >/dev/null
             if [ $? = 0 ]; then
                echo "UP" > vio.$enif
             else
                echo "DOWN" > vio.$enif
                do_timestamp "Bring up $enif SEA interface for iptrace .. does increase overhead"
                ifconfig $enif up  # bring up interface temporarily to run iptrace
                do_timestamp "SEA $enif is up"
             fi
           fi
           if [ "$do_stop" = 1 ]; then
                grep "DOWN" vio.$enif >/dev/null
                if [ $? = 0 ]; then # if wasn't up to begin with, then bring it down
                   do_timestamp "Restore SEA interface to original state of down"
                   ifconfig $enif down
                fi
           fi
        done
}

handle_vios()
{
     action=$1
     if [ "$action" = "run" ]; then
	num_seas=0
        $SBIN/lsdev -C| $BIN/grep "Shared Ethernet Adapter"|$BIN/grep Avail|$BIN/awk '{print $1}'| while read seadev 
        do
           num=${seadev##*ent}
           enif=en$num
	   vio_seaifs_name[$num_seas]=$enif
             /etc/ifconfig $enif 2>/dev/null| $BIN/grep "<UP," >/dev/null
             if [ $? = 0 ]; then
		vio_seaifs_state[$num_seas]=up;
	     else
		vio_seaifs_state[$num_seas]=down;
                do_timestamp "Bring up ${vio_seaifs_name[$num_seas]} SEA interface for iptrace .. does increase overhead"
                  ifconfig ${vio_seaifs_name[$i]} up
	     fi
	     let num_seas=num_seas+1
	done
    fi

    if [ "$action" = "stop" ]; then
	i=0
	while [ $i -lt $num_seas ]
	do
		if [ ${vio_seaifs_state[$i]} = "down" ]; then
                  do_timestamp "Restore ${vio_seaifs_name[$num_seas]} SEA interface to original state of down"
		  ifconfig ${vio_seaifs_name[$i]} down
	  	fi
		let i=i+1
	done
    fi
}

cleanup()
{
	echo "In iptrace.sh cleanup"
	$BIN/stopsrc -s iptrace
}

# see if iptrace to be taken now
if [ -z "$doreport" ]; then
   # check if iptrace executable is installed
   if [ ! -x /usr/sbin/iptrace ]; then
     echo "\n     IPTRACE: /usr/sbin/iptrace is not installed."
     echo   "     IPTRACE:  This command is part of the optional"
     echo   "                 'bos.net.tcp.server' fileset."
     exit 1
   fi

   if [ "$vios_iptrc" = 1 ]; then
   	if [ -d /usr/ios ]; then
		handle_vios run
	fi
   fi

   echo "\n     IPTRACE: Starting iptrace for $1 seconds...."
   cursec=$SECONDS
   $BIN/rm -f $IPTRACEOUT
   $BIN/startsrc -s iptrace -a "$interface $length `pwd`/$IPTRACEOUT"
   $BIN/sleep $sleeptime
   $BIN/stopsrc -s iptrace
   echo "     IPTRACE: iptrace collected."  

   let elasec=$SECONDS-$cursec
   $BIN/sleep 2  # in case iptrace hasn't fully stopped
   echo "     IPTRACE: Binary iptrace data is in file $IPTRACEOUT \c"
   echo "  :  execution_time: $elasec seconds"
   if [ "$vios_iptrc" = 1 ]; then
   	if [ -d /usr/ios ]; then
		handle_vios stop
	fi
   fi
   exit 0
else

   # see if needed files are here
   if [ ! -f $IPTRACEOUT ]; then
     echo "    IPTRACE: $IPTRACEOUT file not found..."
     exit 1
   fi

   echo "\n     IPTRACE: Generating report...."
   echo "\n\n\n  I P T R A C E  I N T E R V A L  O U T P U T   (ipreport -rsn $IPTRACEOUT)\n" > iptrace.int
   $SBIN/ipreport -rsn $IPTRACEOUT >> iptrace.int
   echo "     IPTRACE: iptrace report is in file iptrace.int"
fi
