#!/bin/ksh

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

do_bch()
{
        echo "ob=16\n$1"|$BIN/bc
}

get_kdb()
{
	echo "****************  getvmpools.sh: 'vmpool *'  ****************"
	echo "vmpool *"| $SBIN/kdb > vmpools.save
	$BIN/cat vmpools.save
	np=`$BIN/cat vmpools.save | $BIN/awk -v p=0 '{if ($0 ~ /^$/) next; if(p==1&&length($1)==2){print $0;}else{if($1=="VMP"){p=1}}}'|$BIN/wc -l`
	echo "\n****************  getvmpools.sh:  $np pools  ****************"

	p=0
	while [ $p -lt $np ]
	do
		ph=`do_bch $p`
		echo "\n****************  getvmpools.sh: vmpool $p  ****************"
		echo "vmpool $ph" | $SBIN/kdb
		let p=p+1;
	done
}

get_kdb > vmpools.out
$BIN/cat vmpools.out

exit 0
