#!/bin/ksh
# @(#)78        1.4     src/bos/usr/sbin/perf/pmr/filemon.sh, perfpmr, bos411, 9428A410j 4/14/94 10:08:01
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: 27
#
# (C) COPYRIGHT International Business Machines Corp.  2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# filemon.sh
#
# invoke RISC System/6000 filemon command and generate file system report
#
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin


show_usage()
{
	echo "Usage: filemon.sh [-T kbufsize] [-O options] [-D] time | filemon.sh [-D] -r"
 	echo "       time is total time in seconds to be traced."
	echo "\t-r   do filemon post processing only"
	echo "\t-D   remove trace files after postprocessing"

	exit 1
}
do_timestamp()
{
        if [ "$2" = "nonewline" ]; then
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1\c"
        else
                echo "`$BIN/date +"%H:%M:%S-%D"` :\t$1"
        fi
}
check_for_fixes()
{
    aixv=`$BIN/uname -v`
    if [ "$aixv" = 6 ]; then
        kernel_tl_level=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -1|$BIN/awk '{print $2}'|$BIN/cut -c5`
        if [ "$kernel_tl_level" = 6 ]; then
                $SBIN/instfix -ik IZ84729 >/dev/null 2>&1
                if [ $? != 0 ]; then
                        $SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                        if [ $? != 0 ]; then
                          echo "TRACE.SH:  REQUIRED APAR IZ84729 or IZ85204 is not installed"
                          if [ -z "$force_trace" ]; then
                                echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
                                exit 0
                          fi
                       fi
                fi
        fi
        if [ "$kernel_tl_level" = 7 ]; then
                $SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                if [ $? != 0 ]; then
                        echo "TRACE.SH:  REQUIRED APAR IZ85204 is not installed"
                        if [ -z "$force_trace" ]; then
                                echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
                                exit 0
                        fi
                fi
        fi
   fi  # uname
}



if [ $# -lt 1 ]; then
	show_usage
fi

kbufsize=10000000
#fhooks="139,134,107,10B,10D,154,15B,163,19C,1BA,1BE,1C9,221,222,228,232,2A1,2A2,45B,4B0,5D8,AB2"
fhooks="139,134,107,10B,15B,163,19C,1C9,221,222,228,232,2A1,2A2,45B,5D8,AB2"
options=detailed,all
while getopts T:O:rD flag ; do
        case $flag in
                T)     kbufsize=$OPTARG;;
		O)	options=$OPTARG;;
		r)	do_fmon_post=1;;
		D)	do_remove=1;;
                \?)    show_usage
        esac
done
shift OPTIND-1
FTIME=$@

# exit if filemon executable is not installed
if [ ! -f /usr/bin/filemon ]; then
  echo "     FILEMON: /usr/bin/filemon command is not installed"
  echo "     FILEMON:   This command is part of the optional"
  echo "                'bos.perf.tools' fileset."
  exit 1
fi

if [ -z "$do_fmon_post" ]; then
check_for_fixes
echo "\n\n\n        F  I  L  E  M  O  N    O  U  T  P  U  T    R  E  P  O  R  T\n" > filemon.sum
echo "\n\nHostname:  "  `hostname -s` >> filemon.sum
echo "\n\nTime before run:  " `date` >> filemon.sum
echo "Duration of run:  $FTIME seconds"  >> filemon.sum

echo "\n     FILEMON: Starting filesystem monitor for $FTIME seconds...."
ela_fmonsh_seconds=$SECONDS
#filemon -d -T $kbufsize -O all -uv >> filemon.sum
#filemon -d -T $kbufsize -O detailed,all -uv >> filemon.sum
#$BIN/filemon -d -T $kbufsize -O $options -uv >> filemon.sum
do_timestamp "Starting trace -C all -j $fhooks -L $kbufsize -T $kbufsize -andfo filemon_trace.raw" nonewline; cursec=$SECONDS
$BIN/trace -C all -j $fhooks -L $kbufsize -T $kbufsize -andfo filemon_trace.raw
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
trap 'kill -9 $!' 1 2 3 24
$BIN/sleep 1  # workaround issue where trace has not finished initializing
do_timestamp "trcon initiated" nonewline; cursec=$SECONDS
$BIN/trcon
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
echo "     FILEMON: tracing started"
$BIN/sleep $FTIME 
do_timestamp "trcstop initiated" nonewline; cursec=$SECONDS
$BIN/nice --20 $BIN/trcstop
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
do_timestamp "FILEMON: trcstop completed"

else

	echo "     FILEMON: Generating report...."
	filemon -v -O detailed,all -i filemon_trace.raw -n trace.syms -o filemon.sum
	echo "\c     FILEMON: Report is in filemon.sum"
	if [ -n "$do_remove" = 1 ]; then
		do_timestamp "FILEMON: filemon.sh removing trace files"
		$BIN/rm filemon_trace.raw*
	fi
	do_timestamp "filemon post processing completed"
	exit
fi

# do postprocessing afterwards
echo "     FILEMON: Generating report...."
do_timestamp "filemon report generating .. " nonewline; cursec=$SECONDS
#filemon -v -O detailed,all -i filemon_trace.raw -n trace.syms -o filemon.sum
if [ ! -f trace.syms ]; then
        ulimit -d 8388608  # set to 8GB in case we need that much for gensyms
	do_timestamp "running gensyms" nonewline; cursec=$SECONDS
        /usr/bin/gensyms > trace.syms
fi
filemon -v -O detailed,all -i filemon_trace.raw -n trace.syms > filemon.sum 2>&1
let elasec=$SECONDS-$cursec; echo "  :  execution_time: $elasec seconds"
echo "\c     FILEMON: Report is in filemon.sum"
do_timestamp "FILEMON: filemon.sh post processing completed"
if [ -n "$do_remove" = 1 ]; then
	do_timestamp "FILEMON: filemon.sh removing trace files"
	$BIN/rm filemon_trace.raw*
fi
let ela_fmonsh_seconds=$SECONDS-ela_fmonsh_seconds
do_timestamp "FILEMON: filemon.sh completed  : execution_time: $ela_fmonsh_seconds seconds"
