#!/bin/ksh
trace_logsz=20000000
trace_bufsz=20000000
trace_sleeptime=5

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

$BIN/trcstop -? 2>&1 | $BIN/grep -- "-s" >/dev/null
if [ $? = 0 ]; then
        trcstop_sflag_exists=1
else
        trcstop_sflag_exists=0
fi
if [ "$PERFPMRDIR" = "" ]; then
        PERFPMRDIR=$PWD
fi

do_trcstop()
{
  if [ "$trcstop_sflag_exists" = 1 ]; then
        echo "Stopping trace"
        $BIN/trcstop -s
        if [ $? != 0 ]; then
                echo "TRACE.SH: trcstop -s not supported. Retrying without -s option"
                # in case -s on this system only supports circular traces
                $BIN/nice --20 $BIN/trcstop
        else
                # in case trcstop -s returns 0 even though it wasn't supported
                # if it was supported, this second trcstop should just return right away
                $BIN/nice --20 $BIN/trcstop 2>/dev/null
        fi
  else
        $BIN/nice --20 $BIN/trcstop
  fi
}

do_comptrace_efc()
{
#hooks="100,102,103,200,11f,106,46d,46e,107,134,139,234,4b0,63C,1D1,4AF,3B9,3C4,497,498,63A,63B,419,492"
hooks="100,102,103,200,11f,106,46d,46e,107,134,139,234,4b0,63C,1D1,4AF,3B9,3C4,497,498,63A,63B,419"
        echo "Initializing trace buffers"
        $SBIN/ctctrl -rc efcdd,efscsidd systracedetail
        $BIN/trace -d -C all -L $trace_logsz -T $trace_bufsz -j $hooks -anfp  -o trace.raw
        echo "Starting trace for $trace_sleeptime seconds"
        $BIN/trcon
        $BIN/sleep $trace_sleeptime
        do_trcstop
        $SBIN/ctctrl -rc efcdd,efscsidd systracenormal  # reset level back to normal

}

do_comptrace_emfc()
{
hooks="100,102,103,200,11f,106,46d,46e,107,134,139,234,4b0,63C,1D1,4AF,3B9,3C4,497,498,63A,63B,419,1035,1036,1037,1038,1039,104E"
        echo "Initializing trace buffers"
        $SBIN/ctctrl -rc emfcdd,emfscsidd systracedetail
        $BIN/trace -d -C all -L $trace_logsz -T $trace_bufsz -j $hooks -anfp  -o trace.raw
        echo "Starting trace"
        $BIN/trcon
        $BIN/sleep $trace_sleeptime
        do_trcstop
        $SBIN/ctctrl -rc emfcdd,emfscsidd systracenormal  # reset level back to normal
}

do_comptrace_fc()
{
hooks="100,102,103,200,11f,106,46d,46e,107,134,139,234,4b0,63C,1D1,4AF,3B9,3C4,497,498,63A,63B,419,1035,1036,1037,1038,1039,104E"
        echo "Initializing trace buffers"
        $SBIN/ctctrl -rc efcdd,efscsidd,emfcdd,emfscsidd systracedetail
        $BIN/trace -d -C all -L $trace_logsz -T $trace_bufsz -j $hooks -anfp  -o trace.raw
        echo "Starting trace"
        $BIN/trcon
        $BIN/sleep $trace_sleeptime
        do_trcstop
        $SBIN/ctctrl -rc efcdd,efscsidd,emfcdd,emfscsidd systracenormal  # reset level back to normal
}

do_adapter_procfiles()
{
        if [ -d /proc/sys/adapter ]; then
          find /proc/sys/adapter |while read file; do
            if [ ! -d $file ]; then
              echo "------ BEGIN  $file ------------";
              /bin/cat $file
              echo "------ END  $file ------------\n";
            fi
          done
        fi
}
get_vfc()
{
mkdir svfc
cd svfc
/usr/sbin/lsdev -C|/usr/bin/grep vfchost|/usr/bin/grep Available | /usr/bin/awk '{print $1}'|while read host; do
        fcsdev=`/usr/sbin/lsattr -E -l $host -a map_port -F value`
        if [ "$fcsdev" = "" ]; then
                continue
        fi
        echo "svfcCI; svfcPrQs; svfcva $host; svfcdds $host; svfccq $host;" | $SBIN/kdb > $host.state
        /usr/ios/cli/ioscli lsmap  -npiv -vadapter $host > $host.map
done
cd -
}
do_fcstat()
{
if [ -f /usr/sbin/fcstat ]; then
        echo "\n\n------------ FCSTAT  `/bin/date`  ----------\n"
        $PERFPMRDIR/fcstat2 -l | while read f; do
        echo "\n------------------------------------------------"
                /usr/sbin/fcstat -D $f
        done
fi
}

show_usage()
{
	echo "Usage: comptrace.sh -l"
	echo "       comptrace.sh [-d|-f|-L logsz|-T bufsz|-s tracetime] -C component"
	exit 0
}

get_before_files()
{
	if [ "$collect_fc_config" = 1 ]; then
        	$PERFPMRDIR/fcstat2 -AaQ > fcstat2.totals.before
        	$PERFPMRDIR/fcstat2 -NAaQ > fcstat2.npiv_totals.before
        	do_fcstat > fcstat.before
	fi
}

get_after_files()
{
	if [ "$dump_comptrace" = 1 ]; then
		mkdir comptrace2_dir
		ctctrl -D -d $PWD/comptrace2_dir -rc all 2> ctctrl.err
	fi

	if [ "$collect_fc_config" = 1 ]; then
		do_adapter_procfiles > $PWD/proc_sys_adapter.int 2>/dev/null
		$PERFPMRDIR/fcstat2 -n > fcstat2.wwpn
		$PERFPMRDIR/fcstat2 -AaQ > fcstat2.totals.after
		$PERFPMRDIR/fcstat2 -NAaQ > fcstat2.npiv_totals.after
		do_fcstat > fcstat.after
        	if [ -z "$NO_KDB"  ]; then
			get_vfc
		fi
	fi
}

run_comptrc()
{
	comp=$1
	mkdir ${comp}_trace
	cd ${comp}_trace
	get_before_files
	do_comptrace_${comp}
	get_after_files
}
list_components()
{
	echo "Following components are currently supported: efc, emfc, fc"
	echo "efc -  trace efc drivers"
	echo "emfc -  trace emfc drivers"
	echo "fc -  trace both efc and emfc drivers"
	exit 0
}

validate_component()
{
	comp=$1
	case "$comp" in 
		"fc" ) ;;
		"efc" ) ;;
		"emfc" ) ;;
		*) echo "Invalid component name"
		   list_components
			;;
	esac
}
			 
#---------------------------------------------- MAIN ---------------

unset component dump_comptrace collect_config list_flag
while getopts :C:s:T:L:dfl flag ; do
        case $flag in
		l)	list_flag=1;;
                C)      component=$OPTARG;;
                d)      dump_comptrace=1;;
                f)      collect_fc_config=1;;
                L)      trace_logsz=$OPTARG;;
                T)      trace_bufsz=$OPTARG;;
                s)      trace_sleeptime=$OPTARG;;
                \?)    show_usage
        esac
done

if [ "$list_flag" = 1 ]; then
	list_components
fi

validate_component $component


run_comptrc $component

#if [ "$component" = "fc" ]; then
#        mkdir fc_trace
#        cd fc_trace
#	get_before_files
#        do_comptrace_fc
#elif [ "$component" = "efc" ]; then
#        mkdir efc_trace
#        cd efc_trace
#	get_before_files
#        do_comptrace_efc
#elif [ "$component" = "emfc" ]; then
#        mkdir emfc_trace
#        cd emfc_trace
#	get_before_files
#        do_comptrace_emfc
#fi
#get_after_files
