#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp.  2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# netstat.sh
#
# invoke netstat before/during/after measurement period and generate report
#
#set -x
export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
doreset=
export ENTSTAT_MODE=closed.error


NETSTATWPAR=""
NETSTATOUT=netstat.int
show_usage()
{
        echo "Usage: netstat.sh [-@] [-H][-S][-d dev, -d dev2, ...][-i sec][-s] <seconds> | netstat.sh [-@] -Z | netstat.sh -f filename"
        echo "\t-Z  	  Resets all the statistics to 0"
        echo "\t-@  	  Retrieves stats from wpars"
        echo "\t-H        Display only the Hypervisor error counters"
        echo "\t-S        Only retrieve stats for Shared Ethernet Adapters and their supporting adapters"
        echo "\t-d dev    Only retrieve stats for specified device. Multiple -d flags can be specified"
        echo "\t          Default is to retrieve stats for all ethernet adapters"
        echo "\t-i sec	  Specifies #of seconds between each sample. Default is calculated based on the"
	echo "\t           value passed in by perfpmr. This parm also is used for the netstat -i output collected for perfpmr"
        echo "\t-s 	  Collect stats at intervals and parse them and print one line summary per adapter"
        echo "\t-f file   Parses filename which should have entstat or netstat -v output. This is not for real-time stats"
        echo "\tseconds   Total duration of time before exiting this script"
        exit 1
}

zero_stats()
{
	$SBIN/lsdev -F name -S A -C -c adapter | 
	while read DEV; do
        case "$DEV" in
          ent[0-9]*) 
		       echo "\n\n\nentstat -r $DEV"
		       $SBIN/entstat -r $DEV 2>&1
             ;;
          tok[0-9]*)
		       echo "\n\n\ntokstat -r $DEV"
		       $SBIN/tokstat -r $DEV 2>&1
             ;;
          fddi[0-9]*)
		       echo "\n\n\nfddistat -r $DEV"
		       $SBIN/fddistat -r $DEV 2>&1
             ;;
          atm[0-9]*)
		       echo "\n\n\natmstat -r $DEV"
		       $SBIN/atmstat -r $DEV 2>&1
             ;;
          *)
             ;;
        esac
	done   

	if [ -d /usr/ios ]; then  # this is VIOS
		echo "Stats for Shared Ethernet Adapters (SEA)"
		$SBIN/lsdev -C|grep "Shared Ethernet Adapter"|awk '{print $1}' | while read seadev; do
			echo "seatstat -d $seadev -c"
			seastat -d $seadev  -c
		done
	fi

	echo "$SBIN/netstat -Zm -Zs -ZD"
	$SBIN/netstat -Zm 
	$SBIN/netstat -Zs
	$SBIN/netstat -ZD
}
get_vnicserver_stats()
{
	echo "\n\nVNICSERVER STATS"
	/usr/sbin/lsdev -S A -Cc adapter -F name | /usr/bin/grep vnicserver | while read dev; do
		echo "------------------------------------"
		echo "Time: `/bin/date`    VNICSERVER: $dev  vnicstat -b -d"
		/usr/sbin/vnicstat -b -d $dev
		echo "------------------------------------\n\n"
	done
}

get_stats()
{
	when=$1
	# capture the adapter statistics
	$SBIN/lsdev -F name -S A -C -c adapter | 
	while read DEV; do
        case "$DEV" in
          ent[0-9]*) 
	       echo "\n\n\nentstat -d $DEV"
	       echo       "---------------"
	       $SBIN/entstat -d $DEV 2>&1
		hbadev=`$SBIN/entstat -d $DEV | grep "Parent HBA Device" |awk '{print $NF}'`
		if [ "$hbadev" != "" ]; then
			echo "-------------- HBASTAT for $hbadev under $DEV -----------"
			$BIN/hbastat -d $hbadev 
			$BIN/hbastat -qset all  $hbadev
		fi
             ;;
          tok[0-9]*)
	       echo "\n\n\ntokstat -d $DEV"
	       echo       "---------------"
	       $SBIN/tokstat -d $DEV 2>&1
             ;;
          fddi[0-9]*)
	       echo "\n\n\nfddistat $DEV"
	       echo       "--------------"
	       $SBIN/fddistat $DEV 2>&1
             ;;
          atm[0-9]*)
	       echo "\n\n\natmstat -d $DEV"
	       echo       "---------------"
	       $SBIN/atmstat -d $DEV  2>&1
             ;;
          css[0-9]*)
             echo "\n\n\n/usr/lpp/ssp/css/estat -d $DEV"
             echo       "------------------------------"
             if [ -f /usr/lpp/ssp/css/estat ]; then
                	/usr/lpp/ssp/css/estat -d $DEV  2>&1
             else
                	echo "/usr/lpp/ssp/css/estat NOT FOUND"
             fi
             ;;
          iba[0-9]*)
             echo "\n\n\n/usr/bin/ibstat -v $DEV"
             echo       "-----------------------"
             if [ -f /usr/bin/ibstat ]; then
                	/usr/sbin/ibstat -v $DEV  2>&1
             else
                	echo "/usr/sbin/ibstat NOT FOUND"
             fi
             ;;
          *)
             ;;
        esac
	done   

	if [ -d /usr/ios ]; then  # this is VIOS
		echo "Stats for Shared Ethernet Adapters (SEA)"
		$SBIN/lsdev -C|grep "Shared Ethernet Adapter"|awk '{print $1}' | while read seadev; do
			seastat -d $seadev > seastat.$seadev.$when
		done
	fi

	for i in  in m M rn rs s D an ; do
		   echo "\n\n\nnetstat -$i" 
		   echo       "------------" 
		   $SBIN/netstat -$i 
	done

	echo "\n\n\nnetstat -ano $NETSTATWPAR" 
	echo       "------------" 
	$SBIN/netstat -ano $NETSTATWPAR 
	

	echo "\n\nnetstat -p arp" 
	$BIN/netstat -p arp 
	echo "\n\n arp -a" 
	$SBIN/arp -a

	# capture SP2 model 1 switch statistics
	if [ -f /usr/lpp/ssp/css/vdidl2 ]; then
	     echo "\n\n\nvdidl2 -i" 
	     echo       "---------" 
	     /usr/lpp/ssp/css/vdidl2 -i  
	fi

	# capture SP2 model 2 switch statistics
	if [ -f /usr/lpp/ssp/css/vdidl3 ]; then
	     echo "\n\n\nvdidl3 -i" 
	     echo       "---------" 
	     /usr/lpp/ssp/css/vdidl3 -i 
	fi

	# DLPI stats
	echo "\n\n\nnetstat -P  DLPI stats" 
	$BIN/netstat -P 
        if [ -d /usr/ios ]; then  # this is VIOS
		get_vnicserver_stats > vnicserver_stats.$when
	fi
}

get_stats_before()
{
	echo "     N  E  T  W  O  R  K    P  E  R  F    D  A  T  A\n"
	echo "Hostname:  "  `$BIN/hostname -s`
	echo "Time before run:  " `$BIN/date`
	echo "\n\n\n       N  E  T  W  O  R  K    B  E  F  O  R  E    R  U  N\n"
	get_stats before
}

get_stats_during()
{
	echo "\n\n\n    N E T S T A T   O U T P U T   D U R I N G   R U N  (netstat $INTERVAL)\n"
	netstat $INTERVAL >> $NETSTATOUT &
	NETSTATPID=$!
	trap "kill -9 $NETSTATPID" 1 2 3 24
	$BIN/sleep $runtime &
	wait $!
	kill -9 $NETSTATPID
}

get_stats_after()
{
	echo "\f\n\n\n\n       N  E  T  W  O  R  K    A  F  T  E  R    R  U  N\n"
	echo "\n\nTime after run :  " `date`
	get_stats after
}


process_stats()
{
time=$1
/bin/cat  | awk -v hyperonly="$hyperonly" -v time="$time" '
BEGIN {
        if ( hyperonly == 1 )
        {
          printf("%8s  %6s  %10s  %10s  %10s  %10s  %6s  %s\n",
                "Time","Device", "HSndFail", "HSndRcvFl", "HSndSndErr", "HRcvFail", "VLANID", "Device_Type");
        }
        else
          printf("%8s  %6s  %12s  %8s  %12s  %8s  %6s  %10s  %10s  %10s  %10s  %6s  %s\n",
                "Time","Device", "TransPkts", "TxPkSz","RcvPkts", "RxPkSz","RDrops", "HSndFail", "HSndRcvFl", "HSndSndErr", "HRcvFail", "VLANID", "Device_Type");
}
/^ETHERNET STATISTICS/ {
        dev=$3;
        gsub(/\(|\)/,"",dev);
        founddev=1;
}
/^Device Type:/ {
        devtype=substr($0,14);
        if ( devtype ~ /Virtual/ )
                virtual=1;
        else
                virtual=0;
}
/^Transmit Statistics:/ {
        if ( founddev == 1 )
        {
        getline; getline;
        txpkts=$2; rxpkts=$4;
        getline
        tbytes=$2; rbytes=$4;
        #getline; getline; getline; getline;
         getline; getline; getline;
        tpktsdrop=$3; rpktsdrop=$6;
        if ( txpkts != 0 )
                avgtxsz=tbytes/txpkts;
        else
                avgtxsz=0;
        if ( rxpkts != 0 )
                avgrxsz=rbytes/rxpkts;
        else
                avgrxsz=0;
        }
}
/Hypervisor Send Failures:/ {
        if ( founddev == 1 )
                hsf=$4;
}
/Receiver Failures:/ {
        if ( founddev == 1 )
                hsrf=$3;
}
/Send Errors:/ {
        if ( founddev == 1 )
                hsse=$3;
}
/Hypervisor Receive Failures:/ {
        if ( founddev == 1 )
                hrf=$4
}
/Port VLAN ID:/ {
        vlanid=$4;
        if ( virtual == 1 )
        {
                if ( hyperonly == 1 )
                  printf("%8s  %6s  %10s  %10s  %10s  %10s  %6s  %s\n",
                        time,dev,hsf,hsrf,hsse,hrf,vlanid, devtype);
                else
                  printf("%8s  %6s  %12s  %8d  %12s  %8d  %6s  %10s  %10s  %10s  %10s  %6s  %s\n",
                        time,dev,txpkts,avgtxsz,rxpkts,avgrxsz,rpktsdrop,hsf,hsrf,hsse,hrf,vlanid, devtype);
        }
        founddev=0; virtual=0;
}
/General Statistics:/ {
        if ( virtual != 1 )
        {
                if ( hyperonly == 1 )
                  printf("%8s  %6s  %10s  %10s  %10s  %10s  %6s  %s\n",
                        time,dev,"N/A","N/A","N/A","N/A","N/A", devtype);
                else
                  printf("%8s  %6s  %12s  %8d  %12s  %8d  %6s  %10s  %10s  %10s  %10s  %6s  %s\n",
                        time,dev,txpkts,avgtxsz,rxpkts,avgrxsz,rpktsdrop,"N/A","N/A","N/A","N/A","N/A", devtype);
                founddev=0; virtual=0;
        }
}
'
echo
}

get_interval_stats()
{
	# get list of devices (if not specified with -d option)
	if [ "$all_entdevs" = 1 ]; then
		set +A Adevs $(/usr/sbin/lsdev -S A -Cc adapter -F name | /usr/bin/grep "^ent")
		numAdevs=${#Adevs[@]}
	elif [ "$SEAonly" = 1 ]; then
		set +A Adevs $(/usr/sbin/lsdev -S A -Cc adapter  | /usr/bin/grep "^ent" | grep "Shared Ethernet Adapter"|awk '{print $1}')
		numAdevs=${#Adevs[@]}
	fi

	id=$(/usr/bin/whoami)
	if [ "$id" != "root" ]; then
		do_netstat=1;
	fi
	if [ "$do_netstat" != 1 ]; then
		# Now verify that entstat works on each of the Available adapters
		# This is done once upfront
		integer d=0 e=0 numdevs=0
		while [ $d -lt "$numAdevs" ]; do
			entstat -d ${Adevs[$d]} >/dev/null 2>&1
			if [ $? = 0 ]; then     # good device
				devs[numdevs]=${Adevs[$d]}
				numdevs=numdevs+1
			fi
			d=d+1
		done
	fi
	/bin/date
	integer i=0
	while [ $i -lt "$COUNT" ]; do
		datestamp=$(/usr/bin/date +"%H:%M:%S")
		if [ "$do_netstat" = 1 ]; then
			/usr/bin/netstat -v 2>/dev/null| process_stats $datestamp
		else
			integer d=0
			while [ $d -lt "$numdevs" ]; do
				/usr/bin/entstat -d ${devs[$d]} 2>/dev/null| process_stats $datestamp
				d=d+1
			done
		fi
		sleep $INTERVAL
		i=i+1
	done
}

#----------------------------------------------------------------
# MAIN
#----------------------------------------------------------------
interval=""
hyperonly=0;all_entdevs=1;do_interval_stats=0
do_file=0
integer numAdevs=0
while getopts sZW:i:Sd:Hf: flag ; do
        case $flag in
		s)	do_interval_stats=1;;
		i)	interval=$OPTARG;;
                Z)     	doreset=1;;
		W)     	NETSTATWPAR="-@";;
                S) 	all_entdevs=0;SEAonly=1;;
                d) 	all_entdevs=0;Adevs[$numAdevs]=$OPTARG;numAdevs=numAdevs+1;;
                H) 	hyperonly=1;;
                f) 	filename=$OPTARG;do_file=1;;
                \?)    	show_usage
        esac
done

if [ "$do_file" = 1 ]; then
        datestamp=$(/usr/bin/date +"%H:%M:%S")
        /bin/cat $filename | process_stats $datestamp
        exit 0
fi
shift OPTIND-1
runtime=$@

if [ "$doreset" =  1 ]; then	
	zero_stats
	exit 0
fi

	

# determine interval
if [ -n "$PERFPMR_MONITOR_INTVLTIME" ]; then
        INTERVAL=$PERFPMR_MONITOR_INTVLTIME  # a kill is done on pid after $runtime seconds
else
  if [ "$interval" = "" ]; then
        if [ "$runtime" -lt 601 ]; then
                INTERVAL=10
        else
                INTERVAL=60
        fi
  else
	INTERVAL=$interval
	let COUNT=runtime/INTERVAL    # how many samples to collect before exiting
  fi
fi
if  [ "$do_interval_stats"  = 1 ]; then
	get_interval_stats
	exit
fi

# Normal perfpmr stuff
# collect data before measurement interval
echo "\n     NETSTAT.SH: Collecting NETSTAT statistics before the run...."
get_stats_before > $NETSTATOUT 2>&1
if [ "$runtime" = ""  -o "$runtime" -eq 0 ]; then
	exit 	# runtime not specified means to just collect stats once
fi

# run netstat during measurement interval
echo "     NETSTAT.SH: Collecting $INTERVAL second intervals for $1 seconds."
get_stats_during >> $NETSTATOUT 2>&1

# collect data after measurement interval
echo "     NETSTAT.SH: Collecting NETSTAT statistics after the run...."
get_stats_after >> $NETSTATOUT 2>&1

echo "     NETSTAT.SH: Interval report is in file $NETSTATOUT"
