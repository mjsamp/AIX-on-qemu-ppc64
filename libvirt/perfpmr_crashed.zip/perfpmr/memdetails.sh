#!/bin/ksh

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin
bufsize=32MB


collect_data()
{
set -x
#time $BIN/svmon -Ss > $svskfile
time $BIN/svmon -S -O filtercat=kernel,maxbufsize=$bufsize  > $svskfile
$BIN/vmstat -v > $vmstatvfile
time $BIN/svmon -G > $svgfile
time $BIN/svmon -S -O maxbufsize=$bufsize > $svsfile
time $BIN/svmon -m -Pn > $svpfile
if [ -r ../svmon.before.S ]; then
        time $BIN/cp ../svmon.before.S $svslfile
else
        time $BIN/svmon -S -O pidlist=on,maxbufsize=$bufsize > $svslfile   #MATT
fi
set +x
}

pg2MB()    { pgs=$1; echo "scale=2;$pgs*4096/1024/1024"|$BIN/bc -l; }

prnt()
{
unset pages
value="$2"
value_type="$3"
if [ "$value_type" = P ]; then
	pages=$value
elif [ "$value_type" = B ]; then
	let pages=$value/4096
elif [ "$value_type" = L ]; then
	let pages=$value*4096
elif [ "$value_type" = S ]; then
	let pages=$value*4194304
fi
if [ -z "$pages" ]; then 
	printf "%-51s | %8s | %10s \n" "$1" "$2" "$3"
else
	printf "%-51s | %8d | %10.2f \n" "$1" $pages `pg2MB $pages`
fi
}



do_total()
{
tot_mem_pgs=`$BIN/grep memory $svgfile | $BIN/awk '{print $2}'`
tot_inuse_pgs=`$BIN/grep memory $svgfile | $BIN/awk '{print $3}'`
free_pgs=`$BIN/grep memory $svgfile | $BIN/awk '{print $4}'`
$BIN/grep "^L" $svgfile |$BIN/awk '{print $4,$5}'|read poolsz poolfr
if [ "$poolsz" != "-" -a "$poolsz" != "" -a -n "$poolfr" ]; then
	lgpg_pool_fr=$((poolsz-poolfr))
	lgpg_pool_fr_4Kpgs=$((lgpg_pool_fr*4096))
else
	lgpg_pool_fr=0
	lgpg_pool_fr_4Kpgs=0
fi
unset poolsz poolfr
$BIN/grep "^S" $svgfile |$BIN/awk '{print $4,$5}'|read poolsz poolfr
if [ "$poolsz" != "-" -a "$poolsz" != "" -a -n "$poolfr" ]; then
	hgpg_pool_fr=$((poolsz-poolfr))
	hgpg_pool_fr_4Kpgs=$((hgpg_pool_fr*4194304))
else
	hgpg_pool_fr=0
	hgpg_pool_fr_4Kpgs=0
fi
echo "====================================================|==========|==========="
#printf "%51s | %7s | %10s\n" "DESCRIPTION" "Pages" "Megabytes"
prnt "Memory Overview" "Pages" "Megabytes"
echo "----------------------------------------------------|----------|-----------"
prnt "Total memory in system" $tot_mem_pgs P
prnt "    Total memory in use"  $tot_inuse_pgs P 
if [ "$lgpg_pool_fr" != 0 ]; then
	prnt "    Large Pages (16MB pages) unused" $lgpg_pool_fr L
fi
if [ "$hgpg_pool_fr" != 0 ]; then
	prnt "    Huge Pages (16GB pages) unused" $hgpg_pool_fr S
fi
prnt "    Free memory"  $free_pgs P
echo "====================================================|==========|==========="
}

do_total_acct()
{
#echo "----------------------------------------------------|---------|-----------"
total_acct=$((mem_wo_vmm_segids_dec+free_pgs+total_svmon_sids_pgs))
total_acct_inuse=$((mem_wo_vmm_segids_dec+total_svmon_sids_pgs))
#prnt "Total in system" $total_acct  P
#prnt "Total in-use" $total_acct_inuse  P
}

#light weight memory trace
do_lmt_mem()
{
lightweight_trace_mem_hex=`echo mtrc | $SBIN/kdb | $BIN/grep mt_total_memory | $BIN/awk '{print $2}'`
lightweight_trace_mem_bytes=`echo "ibase=16;$lightweight_trace_mem_hex" | $BIN/bc`
lmt_pgs=$((lightweight_trace_mem_bytes/4096))
prnt "    Light Weight Trace memory"  $lmt_pgs  P
}


#lvm memory
do_lvm_mem()
{
totpbufs=0
for vg in `$SBIN/lsvg -o`; do
	pbufcnt=`$SBIN/lvmo -v $vg -o total_vg_pbufs|$BIN/awk '{print $NF}'`
	totpbufs=$((totpbufs+pbufcnt))
done
	
#num_powerdisks=`/etc/lspv | $BIN/grep hdiskpower | $BIN/wc -l`    # need to check on a system with a hdiskpower disk and no VG on it
#if [ $num_powerdisks = 0 ]; then
#	num_disks=`/etc/lspv | $BIN/grep -v None|$BIN/wc -l`
#else
#	num_disks=$num_powerdisks
#fi
chk_memory_affinity=`$SBIN/vmo -F -a | $BIN/grep memory_affinity | $BIN/awk '{print $3}'`
if [ "$kerneltype" = 64 ]; then
	pbufsz=464
else
	pbufsz=236
fi
if [ "$chk_memory_affinity" = 0 ]; then 
#	lvm_memory=$((pbufsz*512*num_disks))
	lvm_memory=$((pbufsz*totpbufs))
else # multiply by max srads
#     	lvm_memory=$((pbufsz*512*16*num_disks))
     	lvm_memory=$((pbufsz*16*totpbufs))
fi
lvm_pgs=$((lvm_memory/4096))
prnt "    LVM Memory"          $lvm_pgs  P
}

do_xm_heap()
{
echo "xm -qu" | $SBIN/kdb > $kdbxmfile

totalxmheap=0
$BIN/awk 'BEGIN { } /^----------/ { 
           while (status=getline>0) {
		a="0x"$1;printf("%d %s\n",a, $4)
           }
       }' $kdbxmfile | while read size name; do
		if [ $size != 0 ]; then
			prnt "        $name" $size B
			let totalxmheap=totalxmheap+size
		fi
	done
tot_xmheap_pgs=$((totalxmheap/4096))
}

do_kernelheap()
{
$BIN/grep "kernel heap" $svsfile  > $svsfile.kheap
kheap_mem_pgs=`do_svmon_sids $svsfile.kheap`
#kheap_mem_pgs=`grep "kernel heap" $svsfile |$BIN/awk 'BEGIN {s=0}{s=s+$7}END {print s}'`
#echo "====================================================|=========|==========="
prnt "    Total Kernel Heap memory       "  $kheap_mem_pgs  P
#echo "----------------------------------------------------|---------|-----------"
	do_jfs2_mem
tot_xmheap_pgs=0
if [ -n "$do_detailed_kheap" ]; then
	do_xm_heap
fi
misc_kheap=$((kheap_mem_pgs-tot_jfs2_mem_pgs-tot_xmheap_pgs))
if [ "$get_jfs2_mem_usage" -ne 0 ]; then
  prnt "        misc kernel heap"  $misc_kheap  P
else
  prnt "        misc kernel heap *"  $misc_kheap  P
  prnt "        * includes metadata_cache"
fi
#echo "====================================================|=========|==========="
#echo "----------------------------------------------------|---------|-----------"
}

do_jfs2_mem()
{
echo "pile" | $SBIN/kdb | $BIN/grep "^0x" > $pileout 
tot=0; bp_pgs=0; ic_pgs=0; rest_pgs=0
while read ad nm pg; do
        pgs=`$BIN/printf "%d" $pg`
        let tot=tot+pgs
        if [ "$nm" = "j2VCBufferPool" ]; then
                let bp_pgs=bp_pgs+pgs
        elif [ "$nm" = "iCache" ]; then
                let ic_pgs=ic_pgs+pgs
        elif [ "$nm" = "txLockPile" ]; then
                txLockPile=$pgs
		let tot=tot-pgs	# ignore txLockPile for now 
	elif [ "$nm" = "bmXBufPile" ]; then
		let tot=tot-pgs    # this is already part of metadata_size
        else
                let rest_pgs=rest_pgs+pgs
        fi
done < $pileout
metasz=`$BIN/cat /proc/sys/fs/jfs2/memory_usage|$BIN/grep "metadata cache"|$BIN/awk '{print $NF}'`
if [ "$metasz" != "" ]; then
  get_jfs2_mem_usage=1
else
  get_jfs2_mem_usage=0
  metasz=0
fi
tot_jfs2_mem_bytes=$((metasz+tot*4096))
tot_jfs2_mem_pgs=$((tot+metasz/4096))
prnt "        JFS2 total non-file memory"         $tot_jfs2_mem_pgs  P
prnt "            metadata_cache" $metasz B
prnt "            inode_cache" $ic_pgs P
prnt "            fs bufstructs"  $bp_pgs  P
prnt "            misc jfs2"  $rest_pgs P
}

do_files()
{
$BIN/grep "file pages" $vmstatvfile | read total_file_pages junk1 junk2
$BIN/grep "client pages" $vmstatvfile | read client_file_pages junk1 junk2
let pers_file_pages=total_file_pages-client_file_pages
prnt "    Total file memory"  $total_file_pages P
prnt "        Total clnt (JFS2, NFS,...) file memory"  $client_file_pages P
prnt "        Total pers (JFS) memory"  $pers_file_pages P
do_text
}

do_text()
{
global_clntpgs=`$BIN/grep "^in use" $svgfile |$BIN/awk '{print $5}'`
global_perspgs=`$BIN/grep "^in use" $svgfile |$BIN/awk '{print $4}'`
# text pages in svmon -Sl will show as unused clnt segment if process exited
# text pages in svmon -Sl will show as code if process still exists
# for 64K text, the clnt segment is left in memory as a normal clnt segment
# while the code segment is shown as 'work code' and disappears when the last
# process using it has exited
$BIN/grep "clnt code" $svslfile > clntcode.out  #MATT
$BIN/grep "pers code" $svslfile > perscode.out  #MATT
$BIN/grep "work code" $svslfile > workcode.out  #MATT
clnttext_proc_pgs=`do_svmon_sids clntcode.out`  #MATT
perstext_proc_pgs=`do_svmon_sids perscode.out`  #MATT
worktext_proc_pgs=`do_svmon_sids workcode.out`  #MATT
let totaltext_proc_pgs=clnttext_proc_pgs+perstext_proc_pgs+worktext_proc_pgs  #MATT
let clnttextpgs=global_clntpgs-client_file_pages
let perstextpgs=global_perspgs-pers_file_pages
let totaltextpgs=clnttextpgs+perstextpgs+worktext_proc_pgs
prnt "    Total text memory" $totaltextpgs P
prnt "        Total clnt text memory"  $clnttextpgs  P
prnt "        Total pers text memory"  $perstextpgs  P
prnt "        Total 64K  text memory"  $worktext_proc_pgs  P
}




do_svmon_sids()
{
svsfile_sids=$1
svmon_sids_mem=0
$BIN/grep -Ev 'Vsid|rmap' $svsfile_sids|$BIN/awk '{print substr($0,53,2),substr($0,56,6)}'|while read sz pg; do
        case "$sz" in
                'sm') pgs=$pg;;  # mix of 4k and 64K
                's') pgs=$pg;;  # small pages or 4K
                'm') let pgs=pg*16;;  # medium pages or 64K
                'L') let pgs=pg*4096;; # large pages or 16MB
                'S') let pgs=pg*4194304;;  # huge pages or 16GB
                *)      pgs=0;;    # don't know 
        esac
        let svmon_sids_mem=svmon_sids_mem+pgs
done
if [ "$svmon_sids_mem" = "" ]; then
	echo "0"
else
	echo $svmon_sids_mem
fi
}

do_detailed_system_segs()
{
$BIN/grep "work" $svskfile | $BIN/cut -c25-52 > $svskfiledesc
$BIN/sort -u $svskfiledesc > $svskfiledesc.uniq
ident_ksegpgs=0
while read desc; do
	if [ "$desc" = "" ]; then
		continue
	fi
	$BIN/grep  -w "$desc" $svskfile > $svskfiledesc.x
	ssegpgs=`do_svmon_sids $svskfiledesc.x`
	let ident_ksegpgs=ident_ksegpgs+ssegpgs
	prnt "        $desc"   $ssegpgs P
done < $svskfiledesc.uniq
let ksids_wo_desc=total_svmon_sids_kernel_mem-ident_ksegpgs
prnt "        miscellaneous kernel segs" $ksids_wo_desc P
#prnt "        --------------------------------" " " " "
#prnt "        Total kernel segments w/ description" $tssegpgs P
#prnt "        Total kernel segments w/o description" $ksids_wo_desc  P
}


do_svmon_sids_all()
{
prnt "Segment Overview" "Pages" "Megabytes"
echo "----------------------------------------------------|---------|-----------"
total_svmon_sids_pgs=`do_svmon_sids $svsfile`
prnt "Total segment id mempgs" $total_svmon_sids_pgs P
total_svmon_sids_kernel_mem=`do_svmon_sids $svskfile`
$BIN/grep "fork tree" $svsfile > $svsfile.forktree
forktree_pgs=`do_svmon_sids $svsfile.forktree`
prnt "    Total fork tree segment pages" $forktree_pgs P
prnt "    Total kernel segment id mempgs" $total_svmon_sids_kernel_mem  P
}



do_unaccounted()
{
tot_mem_not_acct_pgs=$((tot_mem_pgs-free_pgs-total_svmon_sids_pgs-lgpg_pool_fr_4Kpgs-hgpg_pool_fr_4Kpgs-mem_wo_vmm_segids_dec))
echo
prnt "Unaccounted memory (no sids nor wlm_hw_pages)" $tot_mem_not_acct_pgs P
}

do_nosids()
{
mem_wo_vmm_segids_hex=`echo "dd wlm_hw_pages 1" | $SBIN/kdb | $BIN/grep wlm_hw_pages+ | $BIN/awk '{print $2}'`
mem_wo_vmm_segids_dec=`echo "ibase=16;$mem_wo_vmm_segids_hex" | $BIN/bc`
echo
prnt "Total kernel mem w/ no segment id (wlm_hw_pages)"  $mem_wo_vmm_segids_dec   P
}

do_detailed_nosids()
{
echo "rmap *" | $SBIN/kdb > $rmapfile
echo "iplcb -mem" | $SBIN/kdb > $iplcbfile
total_nosids_bytes=0
#$BIN/grep "^vmrmap" $MEMFILEDIR/rmap.kdb.out | $BIN/awk '{print $7, $8}' | while read a b
#for item in RMALLOC PVT PVLIST "s/w PFT"
# can't use PVT and PVLIST values accurately here due to reuse, so do the hardway
for item in RMALLOC CRMALLOC
do
#	if [ "$b" = "" ]; then
#		item="$a"
#	else
#        	item="$a $b"
#	fi
	#bytes_hex=`grep "^vmrmap.*$item" $rmapfile | $BIN/awk '{print $5}'`
	bytes_hex=`grep "^[0-9].  .* $item" $rmapfile | $BIN/awk '{print $4}'`

        if [ "$bytes_hex" != "" ]; then
		bytes_dec=`$BIN/printf "%d" "0x${bytes_hex}"`
	else
		bytes_dec=0
	fi
	prnt "    $item" $bytes_dec  B
	let total_nosids_bytes=total_nosids_bytes+bytes_dec
done

if [ "$kerneltype" = 64 ]; then
	sizeof_swpft_entry=96
	sizeof_pvt_entry=8
else
	sizeof_swpft_entry=60	
	sizeof_pvt_entry=8	
fi
number_of_frames=`$BIN/grep "memory pages" $vmstatvfile | $BIN/awk '{print $1}'`
let swpft_bytes=sizeof_swpft_entry*number_of_frames
prnt "    SW_PFT" $swpft_bytes B
let pvt_bytes=sizeof_pvt_entry*number_of_frames
prnt "    PVT" $pvt_bytes B

# get PVLIST size
hashbits_hex=`echo "vmker -seg"|$SBIN/kdb|$BIN/grep "^hashbits"|$BIN/awk '{print $NF}'`
hashbits=`$BIN/printf "%d" "0x${hashbits_hex}"`
pvlist_bytes=`echo "8*8*2^$hashbits" | $BIN/bc`
prnt "    PVLIST" $pvlist_bytes  B

let total_nosids_bytes=total_nosids_bytes+swpft_bytes+pvt_bytes+pvlist_bytes


for item in RTAS_HEAP
do
	bytes_hex=`$BIN/grep "$item" $iplcbfile | $BIN/awk '{print $3}'`
	bytes_dec=`$BIN/printf "%d" "0x${bytes_hex}"`
	prnt "    $item" $bytes_dec B
	let total_nosids_bytes=total_nosids_bytes+bytes_dec
done

prnt "    -----------------------------" "" ""
prnt "    Total"  $total_nosids_bytes  B
}

do_detailed()
{
echo "\n==========================================================================="
prnt "Detailed Memory Components" "Pages" "Megabytes"
echo "----------------------------------------------------|----------|-----------"
do_lmt_mem
do_lvm_mem
do_kernelheap
do_files
do_users
echo "==========================================================================="
}

do_users()
{

#$BIN/ps -Xe -o user | $BIN/grep "[A-Z,a-z,0-9]" | $BIN/sort -u  > $all_user_file  
#$BIN/ps -Xe -o user | $BIN/awk '{if(NR>1)print}' | $BIN/grep "[A-Z,a-z,0-9]" | $BIN/sort -u  > $all_user_file
$BIN/ps -Xe -o user= | $BIN/grep "[A-Z,a-z,0-9]" | $BIN/sort -u  > $all_user_file  
uniq_users=`$BIN/wc -l $all_user_file|$BIN/awk '{print $1}'`

if [ "$uniq_users" -gt $user_threshold ]; then
	do_detailed_users=0
	$BIN/egrep 'shmat|mmap|shared memory' $svpfile | $BIN/sort -k f1 -u > $svufile.shm.all_uniq
	total_allusers_shared_pgs=`do_svmon_sids $svufile.shm.all_uniq`
	$BIN/egrep -v 'shmat|mmap|shared memory|clnt|pers|shared library text' $svpfile |$BIN/sort -k f1 -u >$svufile.EXC.priv
	total_allusers_priv_pgs=`do_svmon_sids $svufile.EXC.priv`
	$BIN/egrep 'shared library text' $svpfile|$BIN/sort -k f1 -u > $svufile.shtext
	total_allusers_shtxt_pgs=`do_svmon_sids $svufile.shtext`

else

prnt "    User memory" ""  ""
total_allusers_priv_pgs=0
total_allusers_shtxt_exc_pgs=0
> $svufile.shm.all
> $svufile.shtext
# EXC=exclusive, SHA=shared
while read user; do
	{
	set -x
	time $BIN/svmon -m -U $user > ${svufile}.$user  
	set +x
	} 2>> $memdetailserr

	for type in clnt pers work; do
	  $BIN/grep -p"\...." EXCLUSIVE ${svufile}.$user |$BIN/grep $type > $svufile.EXC.$type
	  let user_exc_${type}_pgs=`do_svmon_sids $svufile.EXC.$type`
	  $BIN/grep -p"\...." SHARED ${svufile}.$user |$BIN/grep $type > $svufile.SHA.$type
	  let user_sha_${type}_pgs=`do_svmon_sids $svufile.SHA.$type`
	done

	$BIN/egrep 'shmat|mmap|shared memory' ${svufile}.EXC.work > ${svufile}.EXC.shm
	$BIN/egrep 'shmat|mmap|shared memory' ${svufile}.SHA.work > ${svufile}.SHA.shm
	$BIN/cat ${svufile}.EXC.shm ${svufile}.SHA.shm >> ${svufile}.shm.all
	$BIN/egrep 'stack|private|data|heap|working storage' $svufile.EXC.work > ${svufile}.EXC.priv   #MATT
	#egrep 'working storage' $svufile.EXC.work > ${svufile}.EXC.workstor #MATT
	$BIN/egrep 'shared library text' ${svufile}.EXC.work > ${svufile}.shtext.priv
	$BIN/egrep 'shared library text' ${svufile}.SHA.work > ${svufile}.shtext.sha
	$BIN/cat ${svufile}.shtext.sha >> $svufile.shtext
	user_exc_shtxt_pgs=`do_svmon_sids $svufile.shtext.priv`
	let total_allusers_shtxt_exc_pgs=total_allusers_shtxt_exc_pgs+user_exc_shtxt_pgs
	user_sha_shtxt_pgs=`do_svmon_sids $svufile.shtext.sha`
        user_sha_shm_pgs=`do_svmon_sids $svufile.SHA.shm`
        user_exc_shm_pgs=`do_svmon_sids $svufile.EXC.shm`
	user_exc_priv_pgs=`do_svmon_sids $svufile.EXC.priv`
	#user_exc_wstor_pgs=`do_svmon_sids $svufile.EXC.workstor` #MATT
	let total_allusers_priv_pgs=total_allusers_priv_pgs+user_exc_priv_pgs

	let user_tot_clnt_pgs=user_exc_clnt_pgs+user_sha_clnt_pgs
	let user_tot_pers_pgs=user_exc_pers_pgs+user_sha_pers_pgs
	let user_tot_file_pgs=user_tot_clnt_pgs+user_tot_pers_pgs
	let user_tot_file_exc_pgs=user_exc_clnt_pgs+user_exc_pers_pgs
	let user_tot_file_sha_pgs=user_sha_clnt_pgs+user_sha_pers_pgs


	prnt "     USER: $user"
	prnt "       total process private memory" $user_exc_priv_pgs P
	if  echo "$user" |$BIN/grep oracle >/dev/null ; then
		shm_name="[SGA]" # shared global area
	elif  echo "$user" |$BIN/grep db2 >/dev/null ; then
		shm_name="[AGSM]" #application group shared memory
	fi
	prnt "       total shared memory $shm_name" $((user_sha_shm_pgs+user_exc_shm_pgs)) P
	prnt "       working (shared w/ other users)" $user_sha_work_pgs P
	prnt "       working (exclusive to user)" $user_exc_work_pgs  P
	prnt "          shared memory (exclusive to user)" $user_exc_shm_pgs P
	prnt "          shared memory (shared w/ other users)" $user_sha_shm_pgs P
	prnt "       shlib text (shared w/ other users)" $user_sha_shtxt_pgs P
	prnt "       shlib text (exclusive to user)" $user_exc_shtxt_pgs P
	prnt "       file pages" $user_tot_file_pgs P
	prnt "          file pages (exclusive to user)" $user_tot_file_exc_pgs P
	prnt "          file pages (shared w/ other users)" $user_tot_file_sha_pgs P
done < $all_user_file
$BIN/sort -k f1 -u $svufile.shtext > $svufile.shtext.uniq
total_allusers_shtxt_pgs=`do_svmon_sids $svufile.shtext.uniq`
let total_allusers_shtxt_pgs=total_allusers_shtxt_pgs+total_allusers_shtxt_exc_pgs
fi
}

do_summary()
{
echo "\n\n"
echo "==========================================================================="
if [ "$do_detailed_users" = 1 ]; then
	#$BIN/awk '{print $1}' $svufile.shm.all |$BIN/sort -u > $svufile.shm.all_uniq.sids
	#> $svufile.shm.all_uniq
	#while read sid; do
	#	$BIN/grep -w "$sid .*work" $svufile.shm.all >> $svufile.shm.all_uniq
	#done < $svufile.shm.all_uniq.sids
	$BIN/sort -k f1 -u $svufile.shm.all > $svufile.shm.all_uniq
	total_allusers_shared_pgs=`do_svmon_sids $svufile.shm.all_uniq`
fi
ident_kmem=$((ident_ksegpgs+mem_wo_vmm_segids_dec))
total_iden_inuse=$((ident_kmem+totaltextpgs+total_file_pages+total_allusers_shared_pgs+total_allusers_priv_pgs+forktree_pgs+lgpg_pool_fr_4Kpgs+hgpg_pool_fr_4Kpgs+total_allusers_shtxt_pgs))
prnt "Memory accounting summary" "4K Pages" "Megabytes"
echo "----------------------------------------------------|----------|-----------"
prnt "Total memory in system" $tot_mem_pgs P
prnt "  Total memory in use"  $tot_inuse_pgs P 
prnt "     Kernel identified memory (segids,wlm_hw_pages)"  $ident_kmem P
prnt "     Kernel un-identified memory "   $ksids_wo_desc P
prnt "     Fork tree pages" $forktree_pgs P
prnt "     Large Page Pool free pages" $lgpg_pool_fr L
prnt "     Huge Page Pool free pages" $hgpg_pool_fr  S
prnt "     User private memory"  $total_allusers_priv_pgs P
$BIN/grep "private load data"  $svsfile > privloaddata.all
$BIN/grep "private load data"  $svskfile > privloaddata_kern.all
total_kernel_priv_load_pgs=`do_svmon_sids privloaddata_kern.all`
total_priv_load_pgs=`do_svmon_sids privloaddata.all`
let total_user_priv_load_pgs=total_priv_load_pgs-total_kernel_priv_load_pgs
prnt "         Kern private load memory" $total_kernel_priv_load_pgs P
prnt "         User private load memory" $total_user_priv_load_pgs P
prnt "     User shared memory"  $total_allusers_shared_pgs P
prnt "     User shared library text memory" $total_allusers_shtxt_pgs P
#prnt "     Text memory" $totaltextpgs  P   #MATT
let text_not_in_use=totaltextpgs-totaltext_proc_pgs  #MATT
prnt "     Text/Executable code memory in use" $totaltext_proc_pgs P  #MATT
prnt "     Text/Executable code memory not in use" $text_not_in_use P  #MATT
prnt "     File memory"  $total_file_pages P
user_unident=$((tot_inuse_pgs-total_iden_inuse-ksids_wo_desc)) 
prnt "     User un-identifed memory "  $user_unident P
prnt "     ----------------------" " "  " "
prnt "     Total accounted in-use" $((total_iden_inuse+ksids_wo_desc+user_unident)) P
prnt "  Free memory"  $free_pgs P
prnt "  ----------------------" ""  ""
prnt "  Total identified (total ident.+free)" $((total_iden_inuse+free_pgs)) P
prnt "  Total unidentified (kernel+user w/ segids)" $((ksids_wo_desc+user_unident)) P
prnt "  ----------------------" ""  ""
prnt "  Total accounted" $((total_iden_inuse+free_pgs+ksids_wo_desc+user_unident)) P

tot_mem_not_acct_pgs=$((tot_mem_pgs-free_pgs-total_svmon_sids_pgs-lgpg_pool_fr_4Kpgs-hgpg_pool_fr_4Kpgs-mem_wo_vmm_segids_dec))
prnt "  Total unaccounted" $tot_mem_not_acct_pgs P

echo "\nUnidentifed user could be: "
echo " - shared memory segments currently not attached by processes"
echo " - shared libraries currently not used by any processes"
echo " - miscellaneous"
echo "==========================================================================="
}
do_kdb_xm()
{
echo "\n\nKERNEL HEAP USAGE  (xm -u)" > kdb_xm_u.out
echo     "-------------------------------\n" >> kdb_xm_u.out
echo "xm -u" | $SBIN/kdb >> kdb_xm_u.out

echo "\n\nKERNEL HEAP USAGE  (xm -L3 -u)" > kdb_xm_L3u.out
echo     "-------------------------------\n" >> kdb_xm_L3u.out
echo "xm -L3 -u" | $SBIN/kdb >> kdb_xm_L3u.out
}
do_xmu_summary()
{
PERFPMRDIR=`whence $0`
PERFPMRDIR=`$BIN/ls -l $PERFPMRDIR |$BIN/awk '{print $NF}'`
PERFPMRDIR=`$BIN/dirname $PERFPMRDIR`

if [ -f $PERFPMRDIR/kheap ]; then
echo "\n==========================================================================="
echo "          KERNEL HEAP TOP 10 ALLOCATIONS AND COUNTS"
echo "==========================================================================="
$PERFPMRDIR/kheap kdb_xm_u.out 
echo "\n==========================================================================="
fi
}

do_cleanup()
{
	$BIN/rm ${svufile}.EXC.* ${svufile}.SHA.* 
	$BIN/rm $svufile.shm.all_uniq $svufile.shm.all_uniq.sids $svufile.shm.all $all_user_file
	$BIN/rm $svskfiledesc $svskfiledesc.x; $BIN/rm $svskfiledesc.uniq
	$BIN/rm $svufile $svgfile $svsfile $svskfile  $vmstatvfile
	$BIN/rm $rmapfile $iplcbfile $pileout
	$BIN/rm $svsfile.forktree $svsfile.kheap
	$BIN/rm $svpfile $svufile.shtext
}
do_cleanup_min()
{
	$BIN/rm ${svufile}.EXC.* ${svufile}.SHA.*  $svufile.shtext
	$BIN/rm $svufile.shm.all_uniq $svufile.shm.all $svufile.shtext*
}

do_ldatacallers()
{
	# doing the lke -s can take a long time 
	(
	grep "^F" ldata3.txt |sort -u | while read addr; do
			echo "lke -s $addr"
	done
	) 2>/dev/null |   /usr/sbin/kdb >  ldata4.txt
	awk '/lke/ {printf("%s ", $4);;getline;getline;getline;printf("%s\n", $NF);}' ldata4.txt > ldata5.txt
	awk '
	/!echo/ { xmaddr=$3;size=$4; printf("xmaddr: %s  size_bytes: %d  \n",xmaddr,size);}
	/ldata_create+/ {getline; printf("\tstack1: %s \n", $0);
					 getline; printf("\tstack2: %s \n", $0);}' ldata2.txt > ldata6.txt
	echo "\n\nSIZES AND NAMES" > ldata7.txt
	while read line; do
		case $line in
			*stack[1-9]": F"*)
				a=$(echo $line | awk '{print substr($2,1,16)}')
				sym=$(/usr/bin/grep $a ldata5.txt|awk '{print $2}')
				echo "\t$line  $sym";;
			*'xmaddr'*)
				echo "$line";;
			*)
				echo "\t$line";;
		esac
	done < ldata6.txt >> ldata7.txt
}

do_otherkernelsegs()
{
	echo "ldata" | /usr/sbin/kdb | awk '
		/sp_subpool_size/{
			s=sprintf("%d", "0x" $NF);}
		/sp_allocbits/{
			printf("%s  %d\n",$NF,s);}
		' > ldata1.txt

	(
	/bin/cat ldata1.txt |while read addr size
	do
			echo "!echo $addr $size"
			echo "xm $addr"
	done
	) 2>/dev/null |   /usr/sbin/kdb >  ldata2.txt

	awk '
	/ldata_create+/{
		getline;
			c=substr($0,18,1);
			if ( c == "F" )
			{
				addr=substr($0,18,16);
				printf("%s\n", addr);
			}
		getline;
			c=substr($0,18,1);
			if ( c == "F" )
			{
				addr=substr($0,18,16);
				printf("%s\n", addr);
			}
	}' ldata2.txt > ldata3.txt

	if [ "$Lflag" = 1 ]; then
		do_ldatacallers
	fi
	/bin/grep "other kernel segments" svmon_S.out |
		 /bin/awk '{if ($8 > 0) print $1}'|while read sid;
			   do
				   echo "scb 2 $sid"
			   done  > scb.sids
	/bin/cat scb.sids | /usr/sbin/kdb > kdb.scb.out
}

#MEMFILEDIR=/tmp
MEMFILEDIR=$PWD
svufile=$MEMFILEDIR/svmon_U.out
svgfile=$MEMFILEDIR/svmon_G.out
svsfile=$MEMFILEDIR/svmon_S.out
svskfile=$MEMFILEDIR/svmon_Ss.out
svslfile=$MEMFILEDIR/svmon_Sl.out #MATT
svskfiledesc=$MEMFILEDIR/svmon_ksids.desc
svpfile=$MEMFILEDIR/svmon_P.out
vmstatvfile=$MEMFILEDIR/vmstat.v.out
rmapfile=$MEMFILEDIR/rmap.kdb.out
iplcbfile=$MEMFILEDIR/iplcb.kdb.out
pileout=$MEMFILEDIR/pile.kdb.out
kdbxmfile=$MEMFILEDIR/xm.kdb.out
all_user_file=$MEMFILEDIR/all_users.out
memdetailserr=$MEMFILEDIR/memdetails.err
kerneltype=`$SBIN/bootinfo -K`
PROG=$0
user_threshold=20   # if more unique user id's running than this, then don't do detailed user stats
unset no_xmu do_detailed_kheap

show_usage()
{
	echo "Usage: $PROG [-x][-m][-u usercount][-L]"
	echo "-x  show more details of kernel heap allocations"
	echo "-m  do not collect kernel heap information"
	echo "-L  get ldata allocator information"
	echo "-u  usercount   do not show details of each user if unique user ids is > usercount "
	exit 0
}

do_detailed_users=1;unset Lflag
while getopts mxu:L flag ; do
        case $flag in
		m)  no_xmu=1;;
		x)  do_detailed_kheap=1;;
		u)  user_threshold=$OPTARG;;
		L)  Lflag=1;;
		\?) show_usage
        esac
done

echo "==========================================================================="
echo "Node: `$BIN/hostname -s`           Date: `$BIN/date`"
echo "==========================================================================="

if [  "$KDB_CHECKED" != 1 ]; then
        echo status | /usr/sbin/kdb >/dev/null 2>&1
        if [ $? != 0 ]; then  # kdb doesn't work
		echo "kdb failed"
		exit
        fi
fi
collect_data  2> $memdetailserr
if [ "$no_xmu" != 1 ]; then
 do_kdb_xm
fi
do_total
do_svmon_sids_all
do_detailed_system_segs
do_nosids
do_detailed_nosids
do_total_acct
do_unaccounted
do_detailed
do_summary
if [ "$no_xmu" != 1 ]; then
	do_xmu_summary
fi
do_otherkernelsegs
#do_cleanup
#do_cleanup_min
