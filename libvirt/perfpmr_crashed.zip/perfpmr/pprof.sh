#!/bin/ksh
#
# COMPONENT_NAME: perfpmr
#
# FUNCTIONS: none
#
# ORIGINS: IBM
#
# (C) COPYRIGHT International Business Machines Corp.  2000
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# pprof.sh
#
#   Used to collect trace data and create reports for pprof
#

export LANG=C
BIN=/usr/bin
SBIN=/usr/sbin

show_usage()
{
        echo "Usage: pprof.sh.sh [-L <logbuf size in bytes>] <time> | pprof.sh -r"
	echo "\t-L   size of trace log buffer in bytes"
        echo "\t-r   request pprof reports be produced"
        echo "\ttime is total time in seconds to trace"
 	echo "          trace log size is size of memory buffer in bytes"
 	echo "            (default is 4097152 bytes) "
        exit 1
}
check_for_fixes()
{
    aixv=`$BIN/uname -v`
    if [ "$aixv" = 6 ]; then
        kernel_tl_level=`$BIN/lslpp -l bos.mp64|$BIN/grep bos.mp64|$BIN/head -1|$BIN/awk '{print $2}'|$BIN/cut -c5`
        if [ "$kernel_tl_level" = 6 ]; then
                $SBIN/instfix -ik IZ84729 >/dev/null 2>&1
                if [ $? != 0 ]; then
                        $SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                        if [ $? != 0 ]; then
                          echo "TRACE.SH:  REQUIRED APAR IZ84729 or IZ85204 is not installed"
                          if [ -z "$force_trace" ]; then
                                echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
                                exit 0
                          fi
                       fi
                fi
        fi
        if [ "$kernel_tl_level" = 7 ]; then
                $SBIN/instfix -ik IZ85204 >/dev/null 2>&1
                if [ $? != 0 ]; then
                        echo "TRACE.SH:  REQUIRED APAR IZ85204 is not installed"
                        if [ -z "$force_trace" ]; then
                                echo "TRACE MAY BE RUN BY MODIFYING perfpmr.cfg AND SETTING force_trace = true"
                                exit 0
                        fi
                fi
        fi
   fi  # uname
}


if [ $# -eq 0 ]; then
        show_usage
fi

LOG=4097152
while getopts rL: flag ; do
        case $flag in
		L)     LOG=$OPTARG;;
                r)     doreport=1;;
                \?)    show_usage
        esac
done
shift OPTIND-1
sleeptime=$@

# see if trace to be taken now
if [ -z "$doreport" ]; then
  check_for_fixes
  #
  # data collection
  #
  if [ ! -x /usr/bin/trace ]; then
    echo "\n     PPROF.SH: /usr/bin/trace command is not installed"
    echo   "     PPROF.SH:   This command is part of the optional"
    echo   "              bos.sysmgt.trace fileset"
    exit 1
  fi
  echo "\n     PPROF.SH: Starting trace for $sleeptime seconds"
  $BIN/trace -C all -d -L $LOG -T $LOG -afo pprof.trace.raw -j 001,002,003,005,006,135,106,10C,134,139,465,467,00A

  $BIN/trcon
  echo "     PPROF.SH: Data collection started"
  $BIN/sleep $sleeptime
  echo "     PPROF.SH: Data collection stopped"
  $BIN/nice --20 $BIN/trcstop
  echo "     PPROF.SH: Trace stopped"

  # wait until trace has closed the output file
    $BIN/sleep 1
#  $BIN/ps -Nfu root | $BIN/grep ' trace ' | $BIN/grep -v grep > /dev/null
#  while [ $? = 0 ]; do
#    $BIN/sleep 1
#    $BIN/ps -Nfu root | $BIN/grep ' trace ' | $BIN/grep -v grep > /dev/null
#    done
  echo "     PPROF.SH: Binary trace data is in file pprof.trace.raw"

  exit 0
fi

#
# data reduction
#
if [ -f pprof.trace.raw ]; then
  echo "    PPROF.SH: pprof.trace.raw file being converted to pprof.tr"
  $BIN/trcrpt -C all -r pprof.trace.raw > pprof.trc
fi

echo "\n     PPROF.SH: Generating pprof reports with:  pprof -I pprof.tr"
$BIN/pprof -i pprof.trc
##end of shell##
