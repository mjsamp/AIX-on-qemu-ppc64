#!/bin/ksh
vnic_server()
{
        echo "VNIC SERVER STATS:"
        #slist=$(/usr/sbin/lsdev -Fname -S A -Cc adapter  | /usr/bin/grep "^vnicserver")
        printf "%13s  %6s  %10s  %9s  %21s  %8s  %8s  %10s  %10s  %10s  %10s\n" "NAME" "DEV" "MEM_BYTES"  "STATE" "CLNTHOST" "CLNTDEV" "CLNTOS" "CMDS_SENT"  "CMDS_RCVD"  "CMD_RSPERR"  "INTR_CNT"
        echo "vnicserver" | /usr/sbin/kdb | awk '
                /@DEV/ { start=1; }
                /vnicserver/ { if ( start == 1 ) printf("%s  %s  %s  %s\n", $2, $4, $6, $8); }' > vnicserver.namelist
        /usr/bin/cat vnicserver.namelist | while read dev name vf state; do
                echo "vnicserver dev $dev"
        done | /usr/sbin/kdb | awk '
        /b_mark.*=/ { begin=1;}
        /eyec .*=/ { ineyc=1;}
        /state .*=/ { if (ineyc==1) { state=$NF;ineyc=0;} }
        / dds .*=/ { indds=1;}
        / name .*=/ { if ( indds==1) vnname=$NF;}
        / vf_name .*=/ { if ( indds==1) {vf_name=$NF;indds=0;} }
        /total_mapped/ { if ( begin == 1 ) mapped = sprintf("%d", "0x" $NF);}
        /tx_threads_cnt/ { if ( begin == 1) txthrd = $NF;}
        /rx_threads_cnt/ { if ( begin == 1) rxthrd = $NF;}
        /cmd_received_cnt/ { if ( begin == 1) cmd_rcvd = $NF;}
        /cmd_sent_cnt/ { if ( begin == 1) cmd_sent = $NF; }
        /cmd_resp_err_cnt/ { if ( begin == 1) cmd_rsperr = $NF; }
        /interrupts_cnt/ { if ( begin == 1) intr_cnt = $NF;}
        /dev_name.*=/ { if ( begin == 1) cdev_name=$NF;}
        /part_name.*=/ { if ( begin == 1) cpartname=$NF;}
        /part_os.*=/ { if ( begin==1) cpartos=$NF;}
        /e_mark.*=/ { begin=0;
        printf("%13s  %6s  %10d  %9s  %21s  %8s  %8s  %10d  %10d  %10d  %10d\n",
        vnname, vf_name, mapped,  state, cpartname, cdev_name, cpartos, cmd_sent, cmd_rcvd, cmd_rsperr, intr_cnt);} '
}
get_vnicclient_stats()
{
        name=$1
        echo "vnic setacs $name; vnic dev" | /usr/sbin/kdb | awk -v name="$name" '
                / dds .*=/ { indds=1;}
                /total mapd mem/ { mapped = $NF;}
                /total_xmallocd / { xmal = $NF;}
                /# tx queues/ { txque = $NF; }
                /# tx elements/ { txelm = $NF; }
                /# rxc queues/ { rxcque = $NF;}
                /# rxba elems/ { rxbaelm = $NF;}
                /# rxC elems/ { rxCelm = $NF; }
                /Server Data/ { in_sdata=1; }
                /LP:/ { if ( in_sdata==1) { slpar=substr($1,4);} }
                /VS:/ { if ( in_sdata==1) { ssvr=substr($1,4);} }
                /BD:/ { if ( in_sdata==1) { sdev=substr($1,4);} }
                END {
                        printf("%6s  %12d  %8d  %6d  %6d  %6d  %6d  %6d  %18s  %13s  %8s\n",
                        name,mapped,xmal,txque,txelm,rxcque, rxbaelm, rxCelm,slpar,ssvr,sdev);
                }'
}
vnic_client()
{
        echo "VNIC CLIENT STATS:"
        elist=$(/usr/sbin/lsdev -S A -Cc adapter  | /usr/bin/grep "Virtual NIC Client Adapter" | /usr/bin/awk '{print $1}')
        printf "%6s  %12s  %8s  %6s  %6s  %6s  %6s  %6s  %18s  %13s  %8s\n" "NAME" "MEM_BYTES"  "XM_BYTES" "TX_QS" "TX_ELM" "RXC_QS" "RXBAEL" "RXCELM" "SRVR_LPARNAME" "SRVR_SRVRNAME" "SRVR_DEV"
        for name in $elist; do
                get_vnicclient_stats $name
        done
}
if [ -n "$NO_KDB" ]; then
	echo "NO_KDB was specified so cannot retrieve data"
	exit
fi
	
if [ -d /usr/ios ]; then # vios
        vnic_server
else
        vnic_client
fi
